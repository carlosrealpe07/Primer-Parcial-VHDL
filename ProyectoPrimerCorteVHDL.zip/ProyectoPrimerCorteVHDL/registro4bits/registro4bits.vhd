library ieee;
use ieee.std_logic_1164.all;



	entity registro4bits is

		port
		(
			clk : in std_logic;
			rst : in std_logic;
			d   : in std_logic_vector(3 downto 0);
			q   : out std_logic_vector(3 downto 0)
		);
		
	end registro4bits;



	architecture arch_registro4bits of registro4bits is

	begin

		process(clk, rst)
		
		begin
		
			if (rst = '0') then
				q <= (others => '0');
			elsif (clk'event and clk = '1') then
				q <= d;
			end if;
		end process;
		
	end arch_registro4bits;