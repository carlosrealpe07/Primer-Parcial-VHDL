library ieee;
use ieee.std_logic_1164.all;



entity divisor is

	port
	
	(
		clk_50mhz : in std_logic;
		rst       : in std_logic; 
		clk_1hz   : out std_logic
	);
	
end divisor;



architecture arch_div of divisor is

	signal conteo : integer range 0 to 25000000 := 0;
	signal estado : std_logic := '0';
	
begin

	process(clk_50mhz, rst)
	
	begin
	
		if (rst = '0') then
			conteo <= 0;
			estado <= '0';
		elsif (clk_50mhz'event and clk_50mhz = '1') then
			if (conteo >= 24999999) then
				estado <= not estado;
				conteo <= 0;
			else
				conteo <= conteo + 1;
			end if;
		end if;
		
	end process;
	
	clk_1hz <= estado;
	
end arch_div;