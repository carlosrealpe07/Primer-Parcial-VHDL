library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;



entity Contador is

	port
	
	(
		clk    : in std_logic;
		reset  : in std_logic;
		enable : in std_logic;
		count  : out std_logic_vector(7 downto 0) 
	);
	
end Contador;



architecture arch_contador of Contador is

	signal uni : unsigned(3 downto 0) := "0000";
	signal dec : unsigned(3 downto 0) := "0000";
	
begin

	process(clk, reset)
	
	begin
	
		if (reset = '0') then
			uni <= "0000";
			dec <= "0000";
		elsif (clk'event and clk = '1') then
			if (enable = '1') then
				if (uni = 9) then
					uni <= "0000";
					if (dec = 9) then
						dec <= "0000"; -- limite 99
					else
						dec <= dec + 1;
					end if;
				else
					uni <= uni + 1;
				end if;
			end if;
		end if;
		
	end process;

	count <= std_logic_vector(dec) & std_logic_vector(uni);

end arch_contador;