library ieee;
use ieee.std_logic_1164.all;



entity deco7seg_4bits is

	port
	
	(
		a : in std_logic_vector(3 downto 0);
		d : out std_logic_vector(6 downto 0)
	);
	
end deco7seg_4bits;



architecture arch_deco7seg_4bits of deco7seg_4bits is

begin

	process(a)
	begin
		case a is
			when "0000" => d <= "0000001"; -- 0
			when "0001" => d <= "1001111"; -- 1
			when "0010" => d <= "0010010"; -- 2
			when "0011" => d <= "0000110"; -- 3
			when "0100" => d <= "1001100"; -- 4
			when "0101" => d <= "0100100"; -- 5
			when "0110" => d <= "0100000"; -- 6
			when "0111" => d <= "0001111"; -- 7
			when "1000" => d <= "0000000"; -- 8
			when "1001" => d <= "0000100"; -- 9
			when "1010" => d <= "0001000"; -- a
			when "1011" => d <= "1111010"; -- r
			when "1100" => d <= "0100001"; -- g
			when "1101" => d <= "1111110"; -- guion
			when "1110" => d <= "1111111"; -- nada
			when "1111" => d <= "1111111"; -- nada
			when others => d <= "1111111";
		end case;
		
	end process;

end arch_deco7seg_4bits;