-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/22/2026 14:30:33"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	SystemBeta IS
    PORT (
	clk_50mhz : IN std_logic;
	rst : IN std_logic;
	btn_r : IN std_logic;
	btn_v : IN std_logic;
	btn_a : IN std_logic;
	sel_vel : IN std_logic_vector(1 DOWNTO 0);
	sw_tamano : IN std_logic;
	sw_menu : IN std_logic_vector(2 DOWNTO 0);
	sel_memoria : IN std_logic_vector(1 DOWNTO 0);
	modo_cons : IN std_logic;
	leds_salida : BUFFER std_logic_vector(7 DOWNTO 0);
	led_frec : BUFFER std_logic;
	hex3 : BUFFER std_logic_vector(6 DOWNTO 0);
	hex2 : BUFFER std_logic_vector(6 DOWNTO 0);
	hex1 : BUFFER std_logic_vector(6 DOWNTO 0);
	hex0 : BUFFER std_logic_vector(6 DOWNTO 0)
	);
END SystemBeta;

-- Design Ports Information
-- leds_salida[0]	=>  Location: PIN_J1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[1]	=>  Location: PIN_J2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[2]	=>  Location: PIN_J3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[3]	=>  Location: PIN_H1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[4]	=>  Location: PIN_F2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[5]	=>  Location: PIN_E1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[6]	=>  Location: PIN_C1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_salida[7]	=>  Location: PIN_C2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led_frec	=>  Location: PIN_B1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[0]	=>  Location: PIN_G15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[1]	=>  Location: PIN_D19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[2]	=>  Location: PIN_C19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[3]	=>  Location: PIN_B19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[4]	=>  Location: PIN_A19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[5]	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[6]	=>  Location: PIN_B18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[0]	=>  Location: PIN_F14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[1]	=>  Location: PIN_B17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[2]	=>  Location: PIN_A17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[3]	=>  Location: PIN_E15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[4]	=>  Location: PIN_B16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[5]	=>  Location: PIN_A16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[6]	=>  Location: PIN_D15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[0]	=>  Location: PIN_A15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[1]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[2]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[3]	=>  Location: PIN_A14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[4]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[5]	=>  Location: PIN_B13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[6]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[0]	=>  Location: PIN_F13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[1]	=>  Location: PIN_F12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[2]	=>  Location: PIN_G12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[3]	=>  Location: PIN_H13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[4]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[5]	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[6]	=>  Location: PIN_E11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- modo_cons	=>  Location: PIN_D2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel_memoria[1]	=>  Location: PIN_E4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel_memoria[0]	=>  Location: PIN_E3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_menu[0]	=>  Location: PIN_G5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_menu[2]	=>  Location: PIN_H7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_menu[1]	=>  Location: PIN_J7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel_vel[0]	=>  Location: PIN_H5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel_vel[1]	=>  Location: PIN_H6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_tamano	=>  Location: PIN_G4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_r	=>  Location: PIN_H2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_a	=>  Location: PIN_F1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_v	=>  Location: PIN_G3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_50mhz	=>  Location: PIN_G21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_J6,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF SystemBeta IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_50mhz : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_btn_r : std_logic;
SIGNAL ww_btn_v : std_logic;
SIGNAL ww_btn_a : std_logic;
SIGNAL ww_sel_vel : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_sw_tamano : std_logic;
SIGNAL ww_sw_menu : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_sel_memoria : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_modo_cons : std_logic;
SIGNAL ww_leds_salida : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_led_frec : std_logic;
SIGNAL ww_hex3 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_hex2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_hex1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_hex0 : std_logic_vector(6 DOWNTO 0);
SIGNAL \clk_50mhz~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \leds_salida[0]~output_o\ : std_logic;
SIGNAL \leds_salida[1]~output_o\ : std_logic;
SIGNAL \leds_salida[2]~output_o\ : std_logic;
SIGNAL \leds_salida[3]~output_o\ : std_logic;
SIGNAL \leds_salida[4]~output_o\ : std_logic;
SIGNAL \leds_salida[5]~output_o\ : std_logic;
SIGNAL \leds_salida[6]~output_o\ : std_logic;
SIGNAL \leds_salida[7]~output_o\ : std_logic;
SIGNAL \led_frec~output_o\ : std_logic;
SIGNAL \hex3[0]~output_o\ : std_logic;
SIGNAL \hex3[1]~output_o\ : std_logic;
SIGNAL \hex3[2]~output_o\ : std_logic;
SIGNAL \hex3[3]~output_o\ : std_logic;
SIGNAL \hex3[4]~output_o\ : std_logic;
SIGNAL \hex3[5]~output_o\ : std_logic;
SIGNAL \hex3[6]~output_o\ : std_logic;
SIGNAL \hex2[0]~output_o\ : std_logic;
SIGNAL \hex2[1]~output_o\ : std_logic;
SIGNAL \hex2[2]~output_o\ : std_logic;
SIGNAL \hex2[3]~output_o\ : std_logic;
SIGNAL \hex2[4]~output_o\ : std_logic;
SIGNAL \hex2[5]~output_o\ : std_logic;
SIGNAL \hex2[6]~output_o\ : std_logic;
SIGNAL \hex1[0]~output_o\ : std_logic;
SIGNAL \hex1[1]~output_o\ : std_logic;
SIGNAL \hex1[2]~output_o\ : std_logic;
SIGNAL \hex1[3]~output_o\ : std_logic;
SIGNAL \hex1[4]~output_o\ : std_logic;
SIGNAL \hex1[5]~output_o\ : std_logic;
SIGNAL \hex1[6]~output_o\ : std_logic;
SIGNAL \hex0[0]~output_o\ : std_logic;
SIGNAL \hex0[1]~output_o\ : std_logic;
SIGNAL \hex0[2]~output_o\ : std_logic;
SIGNAL \hex0[3]~output_o\ : std_logic;
SIGNAL \hex0[4]~output_o\ : std_logic;
SIGNAL \hex0[5]~output_o\ : std_logic;
SIGNAL \hex0[6]~output_o\ : std_logic;
SIGNAL \modo_cons~input_o\ : std_logic;
SIGNAL \clk_50mhz~input_o\ : std_logic;
SIGNAL \clk_50mhz~inputclkctrl_outclk\ : std_logic;
SIGNAL \sw_tamano~input_o\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \btn_r~input_o\ : std_logic;
SIGNAL \sinc_r|d_sync1~0_combout\ : std_logic;
SIGNAL \sinc_r|d_sync1~q\ : std_logic;
SIGNAL \sinc_r|d_sync2~q\ : std_logic;
SIGNAL \btn_v~input_o\ : std_logic;
SIGNAL \sinc_v|d_sync1~0_combout\ : std_logic;
SIGNAL \sinc_v|d_sync1~q\ : std_logic;
SIGNAL \sinc_v|d_sync2~q\ : std_logic;
SIGNAL \comb~6_combout\ : std_logic;
SIGNAL \btn_a~input_o\ : std_logic;
SIGNAL \sinc_a|d_sync1~0_combout\ : std_logic;
SIGNAL \sinc_a|d_sync1~q\ : std_logic;
SIGNAL \sinc_a|d_sync2~feeder_combout\ : std_logic;
SIGNAL \sinc_a|d_sync2~q\ : std_logic;
SIGNAL \comb~7_combout\ : std_logic;
SIGNAL \pulso_cualquiera~combout\ : std_logic;
SIGNAL \sw_menu[2]~input_o\ : std_logic;
SIGNAL \sw_menu[1]~input_o\ : std_logic;
SIGNAL \sw_menu[0]~input_o\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \trampa~0_combout\ : std_logic;
SIGNAL \sinc_r|q~combout\ : std_logic;
SIGNAL \Equal1~0_combout\ : std_logic;
SIGNAL \hab_conteo~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][12]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][12]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][12]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][12]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][12]~q\ : std_logic;
SIGNAL \sel_memoria[1]~input_o\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][12]~q\ : std_logic;
SIGNAL \sel_memoria[0]~input_o\ : std_logic;
SIGNAL \u_mem_rf4|Mux2~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|Mux2~1_combout\ : std_logic;
SIGNAL \u_dir_rf3|leds_temp~0_combout\ : std_logic;
SIGNAL \leds_salida~0_combout\ : std_logic;
SIGNAL \u_dir_rf3|leds_temp~1_combout\ : std_logic;
SIGNAL \leds_salida~1_combout\ : std_logic;
SIGNAL \leds_salida~2_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Equal0~8_combout\ : std_logic;
SIGNAL \cod_color[0]~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][13]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][13]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][13]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][13]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][13]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][13]~q\ : std_logic;
SIGNAL \u_mem_rf4|salida_color[0]~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|salida_color[0]~1_combout\ : std_logic;
SIGNAL \cod_color[1]~1_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][14]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][14]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][14]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][14]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][14]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][14]~q\ : std_logic;
SIGNAL \u_mem_rf4|salida_color[1]~2_combout\ : std_logic;
SIGNAL \u_mem_rf4|salida_color[1]~3_combout\ : std_logic;
SIGNAL \leds_salida~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Equal0~9_combout\ : std_logic;
SIGNAL \u_dir_rf3|leds_temp[6]~5_combout\ : std_logic;
SIGNAL \leds_salida~4_combout\ : std_logic;
SIGNAL \cod_color[1]~2_combout\ : std_logic;
SIGNAL \leds_salida~5_combout\ : std_logic;
SIGNAL \sel_vel[1]~input_o\ : std_logic;
SIGNAL \u_div_var|conteo[0]~26_combout\ : std_logic;
SIGNAL \u_div_var|conteo[0]~27\ : std_logic;
SIGNAL \u_div_var|conteo[1]~28_combout\ : std_logic;
SIGNAL \u_div_var|conteo[1]~29\ : std_logic;
SIGNAL \u_div_var|conteo[2]~30_combout\ : std_logic;
SIGNAL \u_div_var|conteo[2]~31\ : std_logic;
SIGNAL \u_div_var|conteo[3]~32_combout\ : std_logic;
SIGNAL \u_div_var|conteo[3]~33\ : std_logic;
SIGNAL \u_div_var|conteo[4]~34_combout\ : std_logic;
SIGNAL \u_div_var|conteo[4]~35\ : std_logic;
SIGNAL \u_div_var|conteo[5]~36_combout\ : std_logic;
SIGNAL \u_div_var|conteo[5]~37\ : std_logic;
SIGNAL \u_div_var|conteo[6]~38_combout\ : std_logic;
SIGNAL \u_div_var|conteo[6]~39\ : std_logic;
SIGNAL \u_div_var|conteo[7]~40_combout\ : std_logic;
SIGNAL \u_div_var|conteo[7]~41\ : std_logic;
SIGNAL \u_div_var|conteo[8]~42_combout\ : std_logic;
SIGNAL \u_div_var|conteo[8]~43\ : std_logic;
SIGNAL \u_div_var|conteo[9]~44_combout\ : std_logic;
SIGNAL \u_div_var|conteo[9]~45\ : std_logic;
SIGNAL \u_div_var|conteo[10]~46_combout\ : std_logic;
SIGNAL \u_div_var|conteo[10]~47\ : std_logic;
SIGNAL \u_div_var|conteo[11]~48_combout\ : std_logic;
SIGNAL \u_div_var|conteo[11]~49\ : std_logic;
SIGNAL \u_div_var|conteo[12]~50_combout\ : std_logic;
SIGNAL \u_div_var|conteo[12]~51\ : std_logic;
SIGNAL \u_div_var|conteo[13]~52_combout\ : std_logic;
SIGNAL \u_div_var|conteo[13]~53\ : std_logic;
SIGNAL \u_div_var|conteo[14]~54_combout\ : std_logic;
SIGNAL \u_div_var|conteo[14]~55\ : std_logic;
SIGNAL \u_div_var|conteo[15]~56_combout\ : std_logic;
SIGNAL \u_div_var|conteo[15]~57\ : std_logic;
SIGNAL \u_div_var|conteo[16]~58_combout\ : std_logic;
SIGNAL \u_div_var|conteo[16]~59\ : std_logic;
SIGNAL \u_div_var|conteo[17]~60_combout\ : std_logic;
SIGNAL \u_div_var|conteo[17]~61\ : std_logic;
SIGNAL \u_div_var|conteo[18]~62_combout\ : std_logic;
SIGNAL \u_div_var|conteo[18]~63\ : std_logic;
SIGNAL \u_div_var|conteo[19]~64_combout\ : std_logic;
SIGNAL \u_div_var|conteo[19]~65\ : std_logic;
SIGNAL \u_div_var|conteo[20]~66_combout\ : std_logic;
SIGNAL \u_div_var|conteo[20]~67\ : std_logic;
SIGNAL \u_div_var|conteo[21]~68_combout\ : std_logic;
SIGNAL \u_div_var|conteo[21]~69\ : std_logic;
SIGNAL \u_div_var|conteo[22]~70_combout\ : std_logic;
SIGNAL \u_div_var|conteo[22]~71\ : std_logic;
SIGNAL \u_div_var|conteo[23]~72_combout\ : std_logic;
SIGNAL \u_div_var|conteo[23]~73\ : std_logic;
SIGNAL \u_div_var|conteo[24]~74_combout\ : std_logic;
SIGNAL \sel_vel[0]~input_o\ : std_logic;
SIGNAL \u_div_var|conteo[24]~75\ : std_logic;
SIGNAL \u_div_var|conteo[25]~76_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~10_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~11_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~30_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~7_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~33_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~12_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~31_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~15_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~27_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~28_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Equal11~0_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~13_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~14_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~17_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~18_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~19_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~16_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~23_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~24_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~25_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~20_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~21_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~22_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~26_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~29_combout\ : std_logic;
SIGNAL \u_div_var|LessThan0~32_combout\ : std_logic;
SIGNAL \u_div_var|estado~0_combout\ : std_logic;
SIGNAL \u_div_var|estado~q\ : std_logic;
SIGNAL \led_frec~0_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[0]~25_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[0]~26\ : std_logic;
SIGNAL \u_div_rtc|conteo[1]~27_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[1]~28\ : std_logic;
SIGNAL \u_div_rtc|conteo[2]~29_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[2]~30\ : std_logic;
SIGNAL \u_div_rtc|conteo[3]~31_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[3]~32\ : std_logic;
SIGNAL \u_div_rtc|conteo[4]~33_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[4]~34\ : std_logic;
SIGNAL \u_div_rtc|conteo[5]~35_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[5]~36\ : std_logic;
SIGNAL \u_div_rtc|conteo[6]~37_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[6]~38\ : std_logic;
SIGNAL \u_div_rtc|conteo[7]~39_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[7]~40\ : std_logic;
SIGNAL \u_div_rtc|conteo[8]~41_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[8]~42\ : std_logic;
SIGNAL \u_div_rtc|conteo[9]~43_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[9]~44\ : std_logic;
SIGNAL \u_div_rtc|conteo[10]~45_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[10]~46\ : std_logic;
SIGNAL \u_div_rtc|conteo[11]~47_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[11]~48\ : std_logic;
SIGNAL \u_div_rtc|conteo[12]~49_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[12]~50\ : std_logic;
SIGNAL \u_div_rtc|conteo[13]~51_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[13]~52\ : std_logic;
SIGNAL \u_div_rtc|conteo[14]~53_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[14]~54\ : std_logic;
SIGNAL \u_div_rtc|conteo[15]~55_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[15]~56\ : std_logic;
SIGNAL \u_div_rtc|conteo[16]~57_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[16]~58\ : std_logic;
SIGNAL \u_div_rtc|conteo[17]~59_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[17]~60\ : std_logic;
SIGNAL \u_div_rtc|conteo[18]~61_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[18]~62\ : std_logic;
SIGNAL \u_div_rtc|conteo[19]~63_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[19]~64\ : std_logic;
SIGNAL \u_div_rtc|conteo[20]~65_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[20]~66\ : std_logic;
SIGNAL \u_div_rtc|conteo[21]~67_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[21]~68\ : std_logic;
SIGNAL \u_div_rtc|conteo[22]~69_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[22]~70\ : std_logic;
SIGNAL \u_div_rtc|conteo[23]~71_combout\ : std_logic;
SIGNAL \u_div_rtc|conteo[23]~72\ : std_logic;
SIGNAL \u_div_rtc|conteo[24]~73_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~6_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~7_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~3_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~0_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~1_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~2_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~4_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~5_combout\ : std_logic;
SIGNAL \u_div_rtc|LessThan0~8_combout\ : std_logic;
SIGNAL \u_div_rtc|estado~0_combout\ : std_logic;
SIGNAL \u_div_rtc|estado~q\ : std_logic;
SIGNAL \u_gestor_rf5|paso1~feeder_combout\ : std_logic;
SIGNAL \u_gestor_rf5|paso1~q\ : std_logic;
SIGNAL \u_gestor_rf5|paso2~q\ : std_logic;
SIGNAL \u_gestor_rf5|process_2~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|timer[0]~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|timer[1]~2_combout\ : std_logic;
SIGNAL \bus_hex3[0]~0_combout\ : std_logic;
SIGNAL \bus_hex1[2]~0_combout\ : std_logic;
SIGNAL \bus_hex3[0]~1_combout\ : std_logic;
SIGNAL \bus_hex3[0]~2_combout\ : std_logic;
SIGNAL \u_gestor_rf5|color_activo[1]~1_combout\ : std_logic;
SIGNAL \bus_hex2[3]~0_combout\ : std_logic;
SIGNAL \bus_hex3[1]~3_combout\ : std_logic;
SIGNAL \bus_hex3[1]~4_combout\ : std_logic;
SIGNAL \bus_hex3[2]~5_combout\ : std_logic;
SIGNAL \bus_hex3[2]~6_combout\ : std_logic;
SIGNAL \bus_hex1[2]~1_combout\ : std_logic;
SIGNAL \bus_hex3[3]~7_combout\ : std_logic;
SIGNAL \d3|Mux6~0_combout\ : std_logic;
SIGNAL \d3|Mux5~0_combout\ : std_logic;
SIGNAL \d3|Mux4~0_combout\ : std_logic;
SIGNAL \d3|Mux3~0_combout\ : std_logic;
SIGNAL \d3|Mux2~0_combout\ : std_logic;
SIGNAL \d3|Mux1~0_combout\ : std_logic;
SIGNAL \d3|Mux0~0_combout\ : std_logic;
SIGNAL \bus_hex2[1]~9_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_uni~1_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Add3~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_uni~2_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_dec[1]~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Add2~1_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_dec[3]~5_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Equal7~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_dec[3]~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_dec[0]~2_combout\ : std_logic;
SIGNAL \u_gestor_rf5|process_2~2_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_cen[3]~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_cen[0]~1_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_cen[2]~4_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_cen[2]~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_cen[3]~5_combout\ : std_logic;
SIGNAL \u_gestor_rf5|process_2~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_uni~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Add3~1_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_uni~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Equal6~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_dec[3]~1_combout\ : std_logic;
SIGNAL \u_gestor_rf5|Add2~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_dec[2]~4_combout\ : std_logic;
SIGNAL \u_gestor_rf5|process_2~1_combout\ : std_logic;
SIGNAL \u_gestor_rf5|process_2~4_combout\ : std_logic;
SIGNAL \u_gestor_rf5|t_cen[1]~2_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][9]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][9]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][9]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][9]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][9]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][9]~q\ : std_logic;
SIGNAL \bus_hex2[1]~6_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][9]~q\ : std_logic;
SIGNAL \bus_hex2[1]~7_combout\ : std_logic;
SIGNAL \bus_hex2[1]~8_combout\ : std_logic;
SIGNAL \bus_hex2[1]~10_combout\ : std_logic;
SIGNAL \bus_hex2[2]~11_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][10]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][10]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][10]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][10]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][10]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][10]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][10]~q\ : std_logic;
SIGNAL \bus_hex2[2]~12_combout\ : std_logic;
SIGNAL \bus_hex2[2]~13_combout\ : std_logic;
SIGNAL \bus_hex2[0]~2_combout\ : std_logic;
SIGNAL \bus_hex2[2]~14_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][8]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][8]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][8]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][8]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][8]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][8]~q\ : std_logic;
SIGNAL \bus_hex2[0]~3_combout\ : std_logic;
SIGNAL \bus_hex2[0]~4_combout\ : std_logic;
SIGNAL \bus_hex2[0]~1_combout\ : std_logic;
SIGNAL \bus_hex2[0]~5_combout\ : std_logic;
SIGNAL \bus_hex2[3]~15_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][11]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][11]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][11]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][11]~q\ : std_logic;
SIGNAL \bus_hex2[3]~16_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][11]~q\ : std_logic;
SIGNAL \bus_hex2[3]~17_combout\ : std_logic;
SIGNAL \bus_hex2[3]~18_combout\ : std_logic;
SIGNAL \d2|Mux6~0_combout\ : std_logic;
SIGNAL \d2|Mux5~0_combout\ : std_logic;
SIGNAL \d2|Mux4~0_combout\ : std_logic;
SIGNAL \d2|Mux3~0_combout\ : std_logic;
SIGNAL \d2|Mux2~0_combout\ : std_logic;
SIGNAL \d2|Mux1~0_combout\ : std_logic;
SIGNAL \d2|Mux0~0_combout\ : std_logic;
SIGNAL \c_azul|dec[0]~6_combout\ : std_logic;
SIGNAL \c_azul|uni[0]~3_combout\ : std_logic;
SIGNAL \comb~8_combout\ : std_logic;
SIGNAL \c_azul|uni[2]~1_combout\ : std_logic;
SIGNAL \c_azul|uni~0_combout\ : std_logic;
SIGNAL \c_azul|uni~2_combout\ : std_logic;
SIGNAL \c_azul|Equal0~0_combout\ : std_logic;
SIGNAL \c_azul|dec[3]~5_combout\ : std_logic;
SIGNAL \c_azul|dec~4_combout\ : std_logic;
SIGNAL \c_azul|dec~2_combout\ : std_logic;
SIGNAL \c_azul|dec[2]~3_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][6]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][6]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][6]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][6]~q\ : std_logic;
SIGNAL \bus_hex1[2]~24_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][6]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][6]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][6]~q\ : std_logic;
SIGNAL \bus_hex1[2]~25_combout\ : std_logic;
SIGNAL \c_total|dec[0]~4_combout\ : std_logic;
SIGNAL \c_total|uni[0]~3_combout\ : std_logic;
SIGNAL \c_total|uni[2]~1_combout\ : std_logic;
SIGNAL \c_total|uni~2_combout\ : std_logic;
SIGNAL \c_total|uni~0_combout\ : std_logic;
SIGNAL \c_total|Equal0~0_combout\ : std_logic;
SIGNAL \c_total|dec[3]~0_combout\ : std_logic;
SIGNAL \c_total|dec~3_combout\ : std_logic;
SIGNAL \c_total|dec~1_combout\ : std_logic;
SIGNAL \c_total|dec[2]~2_combout\ : std_logic;
SIGNAL \bus_hex1[2]~13_combout\ : std_logic;
SIGNAL \bus_hex1[2]~19_combout\ : std_logic;
SIGNAL \bus_hex1[2]~20_combout\ : std_logic;
SIGNAL \bus_hex1[2]~21_combout\ : std_logic;
SIGNAL \c_rojo|dec[0]~6_combout\ : std_logic;
SIGNAL \c_rojo|uni[0]~3_combout\ : std_logic;
SIGNAL \comb~10_combout\ : std_logic;
SIGNAL \c_rojo|uni[2]~1_combout\ : std_logic;
SIGNAL \c_rojo|uni~2_combout\ : std_logic;
SIGNAL \c_rojo|uni~0_combout\ : std_logic;
SIGNAL \c_rojo|Equal0~0_combout\ : std_logic;
SIGNAL \c_rojo|dec[3]~5_combout\ : std_logic;
SIGNAL \c_rojo|dec~4_combout\ : std_logic;
SIGNAL \c_rojo|dec~2_combout\ : std_logic;
SIGNAL \c_rojo|dec[2]~3_combout\ : std_logic;
SIGNAL \bus_hex1[2]~18_combout\ : std_logic;
SIGNAL \bus_hex1[2]~22_combout\ : std_logic;
SIGNAL \bus_hex1[2]~12_combout\ : std_logic;
SIGNAL \bus_hex1[2]~14_combout\ : std_logic;
SIGNAL \c_verde|dec[0]~6_combout\ : std_logic;
SIGNAL \c_verde|uni[0]~3_combout\ : std_logic;
SIGNAL \comb~9_combout\ : std_logic;
SIGNAL \c_verde|uni[2]~1_combout\ : std_logic;
SIGNAL \c_verde|uni~0_combout\ : std_logic;
SIGNAL \c_verde|uni~2_combout\ : std_logic;
SIGNAL \c_verde|Equal0~0_combout\ : std_logic;
SIGNAL \c_verde|dec[3]~5_combout\ : std_logic;
SIGNAL \c_verde|dec~4_combout\ : std_logic;
SIGNAL \c_verde|dec~2_combout\ : std_logic;
SIGNAL \c_verde|dec[2]~3_combout\ : std_logic;
SIGNAL \bus_hex1[2]~16_combout\ : std_logic;
SIGNAL \bus_hex1[2]~15_combout\ : std_logic;
SIGNAL \bus_hex1[2]~17_combout\ : std_logic;
SIGNAL \bus_hex1[2]~23_combout\ : std_logic;
SIGNAL \bus_hex1[2]~26_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~5_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~6_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~3_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~4_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~7_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~0_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~1_combout\ : std_logic;
SIGNAL \bus_hex1[2]~8_combout\ : std_logic;
SIGNAL \u_gestor_rf5|hex1[1]~2_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][5]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][5]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][5]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][5]~q\ : std_logic;
SIGNAL \u_mem_rf4|Mux9~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][5]~q\ : std_logic;
SIGNAL \u_mem_rf4|Mux9~1_combout\ : std_logic;
SIGNAL \bus_hex1[1]~11_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][4]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][4]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][4]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][4]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][4]~q\ : std_logic;
SIGNAL \u_mem_rf4|Mux10~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][4]~q\ : std_logic;
SIGNAL \u_mem_rf4|Mux10~1_combout\ : std_logic;
SIGNAL \bus_hex1[0]~7_combout\ : std_logic;
SIGNAL \bus_hex1[0]~9_combout\ : std_logic;
SIGNAL \bus_hex1[0]~2_combout\ : std_logic;
SIGNAL \bus_hex1[0]~3_combout\ : std_logic;
SIGNAL \bus_hex1[0]~4_combout\ : std_logic;
SIGNAL \bus_hex1[0]~5_combout\ : std_logic;
SIGNAL \bus_hex1[0]~6_combout\ : std_logic;
SIGNAL \bus_hex1[0]~10_combout\ : std_logic;
SIGNAL \bus_hex1[3]~27_combout\ : std_logic;
SIGNAL \bus_hex1[3]~28_combout\ : std_logic;
SIGNAL \bus_hex1[3]~29_combout\ : std_logic;
SIGNAL \bus_hex1[3]~30_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][7]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][7]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][7]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][7]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][7]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][7]~q\ : std_logic;
SIGNAL \bus_hex1[3]~31_combout\ : std_logic;
SIGNAL \bus_hex1[3]~32_combout\ : std_logic;
SIGNAL \bus_hex1[3]~33_combout\ : std_logic;
SIGNAL \d1|Mux6~0_combout\ : std_logic;
SIGNAL \d1|Mux5~0_combout\ : std_logic;
SIGNAL \d1|Mux4~0_combout\ : std_logic;
SIGNAL \d1|Mux3~0_combout\ : std_logic;
SIGNAL \d1|Mux2~0_combout\ : std_logic;
SIGNAL \d1|Mux1~0_combout\ : std_logic;
SIGNAL \d1|Mux0~0_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][2]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][2]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][2]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][2]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][2]~q\ : std_logic;
SIGNAL \bus_hex0[2]~18_combout\ : std_logic;
SIGNAL \bus_hex0[2]~19_combout\ : std_logic;
SIGNAL \bus_hex0[2]~15_combout\ : std_logic;
SIGNAL \bus_hex0[2]~14_combout\ : std_logic;
SIGNAL \bus_hex0[2]~16_combout\ : std_logic;
SIGNAL \bus_hex0[2]~17_combout\ : std_logic;
SIGNAL \bus_hex0[2]~20_combout\ : std_logic;
SIGNAL \bus_hex0[3]~21_combout\ : std_logic;
SIGNAL \bus_hex0[3]~22_combout\ : std_logic;
SIGNAL \bus_hex0[3]~23_combout\ : std_logic;
SIGNAL \bus_hex0[3]~24_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][3]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][3]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][3]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][3]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][3]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][3]~q\ : std_logic;
SIGNAL \bus_hex0[3]~25_combout\ : std_logic;
SIGNAL \bus_hex0[3]~26_combout\ : std_logic;
SIGNAL \bus_hex0[3]~27_combout\ : std_logic;
SIGNAL \bus_hex0[1]~7_combout\ : std_logic;
SIGNAL \bus_hex0[1]~8_combout\ : std_logic;
SIGNAL \bus_hex0[1]~9_combout\ : std_logic;
SIGNAL \bus_hex0[1]~10_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][1]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][1]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][1]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][1]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][1]~q\ : std_logic;
SIGNAL \bus_hex0[1]~11_combout\ : std_logic;
SIGNAL \bus_hex0[1]~12_combout\ : std_logic;
SIGNAL \bus_hex0[1]~13_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[0][0]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[1][0]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][0]~feeder_combout\ : std_logic;
SIGNAL \u_mem_rf4|registros[2][0]~q\ : std_logic;
SIGNAL \u_mem_rf4|registros[3][0]~q\ : std_logic;
SIGNAL \bus_hex0[0]~4_combout\ : std_logic;
SIGNAL \bus_hex0[0]~5_combout\ : std_logic;
SIGNAL \bus_hex0[0]~0_combout\ : std_logic;
SIGNAL \bus_hex0[0]~1_combout\ : std_logic;
SIGNAL \bus_hex0[0]~2_combout\ : std_logic;
SIGNAL \bus_hex0[0]~3_combout\ : std_logic;
SIGNAL \bus_hex0[0]~6_combout\ : std_logic;
SIGNAL \d0|Mux6~0_combout\ : std_logic;
SIGNAL \d0|Mux5~0_combout\ : std_logic;
SIGNAL \d0|Mux4~0_combout\ : std_logic;
SIGNAL \d0|Mux3~0_combout\ : std_logic;
SIGNAL \d0|Mux2~0_combout\ : std_logic;
SIGNAL \d0|Mux1~0_combout\ : std_logic;
SIGNAL \d0|Mux0~0_combout\ : std_logic;
SIGNAL \c_verde|uni\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \c_verde|dec\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \c_azul|uni\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \c_azul|dec\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \c_total|uni\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \c_total|dec\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_gestor_rf5|t_dec\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_dir_rf3|leds_temp\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \u_gestor_rf5|t_uni\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \c_rojo|uni\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_gestor_rf5|color_activo\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_div_rtc|conteo\ : std_logic_vector(24 DOWNTO 0);
SIGNAL \c_rojo|dec\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_gestor_rf5|t_cen\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_div_var|conteo\ : std_logic_vector(25 DOWNTO 0);
SIGNAL \u_gestor_rf5|timer\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \u_div_rtc|ALT_INV_LessThan0~8_combout\ : std_logic;
SIGNAL \u_div_var|ALT_INV_LessThan0~32_combout\ : std_logic;
SIGNAL \d0|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \d1|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \d2|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \d3|ALT_INV_Mux6~0_combout\ : std_logic;

BEGIN

ww_clk_50mhz <= clk_50mhz;
ww_rst <= rst;
ww_btn_r <= btn_r;
ww_btn_v <= btn_v;
ww_btn_a <= btn_a;
ww_sel_vel <= sel_vel;
ww_sw_tamano <= sw_tamano;
ww_sw_menu <= sw_menu;
ww_sel_memoria <= sel_memoria;
ww_modo_cons <= modo_cons;
leds_salida <= ww_leds_salida;
led_frec <= ww_led_frec;
hex3 <= ww_hex3;
hex2 <= ww_hex2;
hex1 <= ww_hex1;
hex0 <= ww_hex0;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk_50mhz~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk_50mhz~input_o\);
\u_div_rtc|ALT_INV_LessThan0~8_combout\ <= NOT \u_div_rtc|LessThan0~8_combout\;
\u_div_var|ALT_INV_LessThan0~32_combout\ <= NOT \u_div_var|LessThan0~32_combout\;
\d0|ALT_INV_Mux6~0_combout\ <= NOT \d0|Mux6~0_combout\;
\d1|ALT_INV_Mux6~0_combout\ <= NOT \d1|Mux6~0_combout\;
\d2|ALT_INV_Mux6~0_combout\ <= NOT \d2|Mux6~0_combout\;
\d3|ALT_INV_Mux6~0_combout\ <= NOT \d3|Mux6~0_combout\;

-- Location: IOOBUF_X0_Y20_N9
\leds_salida[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \leds_salida~0_combout\,
	devoe => ww_devoe,
	o => \leds_salida[0]~output_o\);

-- Location: IOOBUF_X0_Y20_N2
\leds_salida[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \leds_salida~1_combout\,
	devoe => ww_devoe,
	o => \leds_salida[1]~output_o\);

-- Location: IOOBUF_X0_Y21_N23
\leds_salida[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \leds_salida[2]~output_o\);

-- Location: IOOBUF_X0_Y21_N16
\leds_salida[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \leds_salida~2_combout\,
	devoe => ww_devoe,
	o => \leds_salida[3]~output_o\);

-- Location: IOOBUF_X0_Y24_N23
\leds_salida[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \leds_salida[4]~output_o\);

-- Location: IOOBUF_X0_Y24_N16
\leds_salida[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \leds_salida~3_combout\,
	devoe => ww_devoe,
	o => \leds_salida[5]~output_o\);

-- Location: IOOBUF_X0_Y26_N23
\leds_salida[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \leds_salida~4_combout\,
	devoe => ww_devoe,
	o => \leds_salida[6]~output_o\);

-- Location: IOOBUF_X0_Y26_N16
\leds_salida[7]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \leds_salida~5_combout\,
	devoe => ww_devoe,
	o => \leds_salida[7]~output_o\);

-- Location: IOOBUF_X0_Y27_N16
\led_frec~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \led_frec~0_combout\,
	devoe => ww_devoe,
	o => \led_frec~output_o\);

-- Location: IOOBUF_X39_Y29_N30
\hex3[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \hex3[0]~output_o\);

-- Location: IOOBUF_X37_Y29_N30
\hex3[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \hex3[1]~output_o\);

-- Location: IOOBUF_X37_Y29_N23
\hex3[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \hex3[2]~output_o\);

-- Location: IOOBUF_X32_Y29_N2
\hex3[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \hex3[3]~output_o\);

-- Location: IOOBUF_X32_Y29_N9
\hex3[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \hex3[4]~output_o\);

-- Location: IOOBUF_X39_Y29_N16
\hex3[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \hex3[5]~output_o\);

-- Location: IOOBUF_X32_Y29_N23
\hex3[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d3|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \hex3[6]~output_o\);

-- Location: IOOBUF_X37_Y29_N2
\hex2[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \hex2[0]~output_o\);

-- Location: IOOBUF_X30_Y29_N23
\hex2[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \hex2[1]~output_o\);

-- Location: IOOBUF_X30_Y29_N16
\hex2[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \hex2[2]~output_o\);

-- Location: IOOBUF_X30_Y29_N2
\hex2[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \hex2[3]~output_o\);

-- Location: IOOBUF_X28_Y29_N2
\hex2[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \hex2[4]~output_o\);

-- Location: IOOBUF_X30_Y29_N30
\hex2[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \hex2[5]~output_o\);

-- Location: IOOBUF_X32_Y29_N30
\hex2[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d2|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \hex2[6]~output_o\);

-- Location: IOOBUF_X26_Y29_N23
\hex1[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \hex1[0]~output_o\);

-- Location: IOOBUF_X28_Y29_N16
\hex1[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \hex1[1]~output_o\);

-- Location: IOOBUF_X23_Y29_N30
\hex1[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \hex1[2]~output_o\);

-- Location: IOOBUF_X23_Y29_N23
\hex1[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \hex1[3]~output_o\);

-- Location: IOOBUF_X23_Y29_N2
\hex1[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \hex1[4]~output_o\);

-- Location: IOOBUF_X21_Y29_N9
\hex1[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \hex1[5]~output_o\);

-- Location: IOOBUF_X21_Y29_N2
\hex1[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d1|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \hex1[6]~output_o\);

-- Location: IOOBUF_X26_Y29_N16
\hex0[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \hex0[0]~output_o\);

-- Location: IOOBUF_X28_Y29_N23
\hex0[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \hex0[1]~output_o\);

-- Location: IOOBUF_X26_Y29_N9
\hex0[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \hex0[2]~output_o\);

-- Location: IOOBUF_X28_Y29_N30
\hex0[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \hex0[3]~output_o\);

-- Location: IOOBUF_X26_Y29_N2
\hex0[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \hex0[4]~output_o\);

-- Location: IOOBUF_X21_Y29_N30
\hex0[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \hex0[5]~output_o\);

-- Location: IOOBUF_X21_Y29_N23
\hex0[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \d0|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \hex0[6]~output_o\);

-- Location: IOIBUF_X0_Y25_N1
\modo_cons~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_modo_cons,
	o => \modo_cons~input_o\);

-- Location: IOIBUF_X41_Y15_N1
\clk_50mhz~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_50mhz,
	o => \clk_50mhz~input_o\);

-- Location: CLKCTRL_G9
\clk_50mhz~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk_50mhz~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk_50mhz~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y23_N8
\sw_tamano~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_tamano,
	o => \sw_tamano~input_o\);

-- Location: IOIBUF_X0_Y24_N1
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: IOIBUF_X0_Y21_N8
\btn_r~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_r,
	o => \btn_r~input_o\);

-- Location: LCCOMB_X3_Y23_N2
\sinc_r|d_sync1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \sinc_r|d_sync1~0_combout\ = !\btn_r~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \btn_r~input_o\,
	combout => \sinc_r|d_sync1~0_combout\);

-- Location: FF_X3_Y23_N9
\sinc_r|d_sync1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \sinc_r|d_sync1~0_combout\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sinc_r|d_sync1~q\);

-- Location: FF_X3_Y23_N27
\sinc_r|d_sync2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \sinc_r|d_sync1~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sinc_r|d_sync2~q\);

-- Location: IOIBUF_X0_Y23_N15
\btn_v~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_v,
	o => \btn_v~input_o\);

-- Location: LCCOMB_X3_Y23_N22
\sinc_v|d_sync1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \sinc_v|d_sync1~0_combout\ = !\btn_v~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \btn_v~input_o\,
	combout => \sinc_v|d_sync1~0_combout\);

-- Location: FF_X3_Y23_N23
\sinc_v|d_sync1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \sinc_v|d_sync1~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sinc_v|d_sync1~q\);

-- Location: FF_X3_Y23_N3
\sinc_v|d_sync2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \sinc_v|d_sync1~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sinc_v|d_sync2~q\);

-- Location: LCCOMB_X3_Y23_N26
\comb~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \comb~6_combout\ = (\sinc_v|d_sync1~q\ & !\sinc_v|d_sync2~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sinc_v|d_sync1~q\,
	datad => \sinc_v|d_sync2~q\,
	combout => \comb~6_combout\);

-- Location: IOIBUF_X0_Y23_N1
\btn_a~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_a,
	o => \btn_a~input_o\);

-- Location: LCCOMB_X3_Y23_N20
\sinc_a|d_sync1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \sinc_a|d_sync1~0_combout\ = !\btn_a~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \btn_a~input_o\,
	combout => \sinc_a|d_sync1~0_combout\);

-- Location: FF_X3_Y23_N21
\sinc_a|d_sync1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \sinc_a|d_sync1~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sinc_a|d_sync1~q\);

-- Location: LCCOMB_X3_Y23_N28
\sinc_a|d_sync2~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \sinc_a|d_sync2~feeder_combout\ = \sinc_a|d_sync1~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \sinc_a|d_sync1~q\,
	combout => \sinc_a|d_sync2~feeder_combout\);

-- Location: FF_X3_Y23_N29
\sinc_a|d_sync2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \sinc_a|d_sync2~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sinc_a|d_sync2~q\);

-- Location: LCCOMB_X3_Y23_N12
\comb~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \comb~7_combout\ = (!\sinc_a|d_sync2~q\ & \sinc_a|d_sync1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sinc_a|d_sync2~q\,
	datad => \sinc_a|d_sync1~q\,
	combout => \comb~7_combout\);

-- Location: LCCOMB_X3_Y23_N6
pulso_cualquiera : cycloneiii_lcell_comb
-- Equation(s):
-- \pulso_cualquiera~combout\ = (\comb~6_combout\) # ((\comb~7_combout\) # ((\sinc_r|d_sync1~q\ & !\sinc_r|d_sync2~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sinc_r|d_sync1~q\,
	datab => \sinc_r|d_sync2~q\,
	datac => \comb~6_combout\,
	datad => \comb~7_combout\,
	combout => \pulso_cualquiera~combout\);

-- Location: IOIBUF_X0_Y25_N15
\sw_menu[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_menu(2),
	o => \sw_menu[2]~input_o\);

-- Location: IOIBUF_X0_Y22_N15
\sw_menu[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_menu(1),
	o => \sw_menu[1]~input_o\);

-- Location: IOIBUF_X0_Y27_N22
\sw_menu[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_menu(0),
	o => \sw_menu[0]~input_o\);

-- Location: LCCOMB_X5_Y23_N6
\Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (\sw_menu[1]~input_o\ & !\sw_menu[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datac => \sw_menu[0]~input_o\,
	combout => \Equal0~0_combout\);

-- Location: LCCOMB_X2_Y23_N14
\trampa~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trampa~0_combout\ = (\btn_v~input_o\ & (!\btn_a~input_o\ & !\btn_r~input_o\)) # (!\btn_v~input_o\ & ((!\btn_r~input_o\) # (!\btn_a~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000101110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_v~input_o\,
	datab => \btn_a~input_o\,
	datad => \btn_r~input_o\,
	combout => \trampa~0_combout\);

-- Location: LCCOMB_X3_Y23_N16
\sinc_r|q\ : cycloneiii_lcell_comb
-- Equation(s):
-- \sinc_r|q~combout\ = (\sinc_r|d_sync1~q\ & !\sinc_r|d_sync2~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sinc_r|d_sync1~q\,
	datad => \sinc_r|d_sync2~q\,
	combout => \sinc_r|q~combout\);

-- Location: LCCOMB_X3_Y23_N0
\Equal1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal1~0_combout\ = (\trampa~0_combout\) # ((!\comb~7_combout\ & (!\comb~6_combout\ & !\sinc_r|q~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \comb~7_combout\,
	datab => \trampa~0_combout\,
	datac => \comb~6_combout\,
	datad => \sinc_r|q~combout\,
	combout => \Equal1~0_combout\);

-- Location: LCCOMB_X3_Y23_N30
\hab_conteo~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hab_conteo~0_combout\ = (\pulso_cualquiera~combout\ & (!\Equal1~0_combout\ & ((!\Equal0~0_combout\) # (!\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pulso_cualquiera~combout\,
	datab => \sw_menu[2]~input_o\,
	datac => \Equal0~0_combout\,
	datad => \Equal1~0_combout\,
	combout => \hab_conteo~0_combout\);

-- Location: FF_X1_Y23_N11
\u_mem_rf4|registros[0][12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \sw_tamano~input_o\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][12]~q\);

-- Location: LCCOMB_X1_Y23_N0
\u_mem_rf4|registros[1][12]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][12]~feeder_combout\ = \u_mem_rf4|registros[0][12]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][12]~q\,
	combout => \u_mem_rf4|registros[1][12]~feeder_combout\);

-- Location: FF_X1_Y23_N1
\u_mem_rf4|registros[1][12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][12]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][12]~q\);

-- Location: LCCOMB_X1_Y23_N22
\u_mem_rf4|registros[2][12]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][12]~feeder_combout\ = \u_mem_rf4|registros[1][12]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][12]~q\,
	combout => \u_mem_rf4|registros[2][12]~feeder_combout\);

-- Location: FF_X1_Y23_N23
\u_mem_rf4|registros[2][12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][12]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][12]~q\);

-- Location: IOIBUF_X0_Y26_N1
\sel_memoria[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel_memoria(1),
	o => \sel_memoria[1]~input_o\);

-- Location: FF_X1_Y23_N3
\u_mem_rf4|registros[3][12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][12]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][12]~q\);

-- Location: IOIBUF_X0_Y26_N8
\sel_memoria[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel_memoria(0),
	o => \sel_memoria[0]~input_o\);

-- Location: LCCOMB_X1_Y23_N16
\u_mem_rf4|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|Mux2~0_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\) # (\u_mem_rf4|registros[1][12]~q\)))) # (!\sel_memoria[0]~input_o\ & (\u_mem_rf4|registros[0][12]~q\ & (!\sel_memoria[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[0][12]~q\,
	datab => \sel_memoria[0]~input_o\,
	datac => \sel_memoria[1]~input_o\,
	datad => \u_mem_rf4|registros[1][12]~q\,
	combout => \u_mem_rf4|Mux2~0_combout\);

-- Location: LCCOMB_X1_Y23_N2
\u_mem_rf4|Mux2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|Mux2~1_combout\ = (\sel_memoria[1]~input_o\ & ((\u_mem_rf4|Mux2~0_combout\ & ((\u_mem_rf4|registros[3][12]~q\))) # (!\u_mem_rf4|Mux2~0_combout\ & (\u_mem_rf4|registros[2][12]~q\)))) # (!\sel_memoria[1]~input_o\ & 
-- (((\u_mem_rf4|Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][12]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[3][12]~q\,
	datad => \u_mem_rf4|Mux2~0_combout\,
	combout => \u_mem_rf4|Mux2~1_combout\);

-- Location: LCCOMB_X1_Y23_N12
\u_dir_rf3|leds_temp~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_dir_rf3|leds_temp~0_combout\ = (!\sw_tamano~input_o\ & !\Equal1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sw_tamano~input_o\,
	datac => \Equal1~0_combout\,
	combout => \u_dir_rf3|leds_temp~0_combout\);

-- Location: FF_X1_Y23_N13
\u_dir_rf3|leds_temp[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_dir_rf3|leds_temp~0_combout\,
	clrn => \rst~input_o\,
	ena => \pulso_cualquiera~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_dir_rf3|leds_temp\(0));

-- Location: LCCOMB_X1_Y23_N28
\leds_salida~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \leds_salida~0_combout\ = (\modo_cons~input_o\ & (!\u_mem_rf4|Mux2~1_combout\)) # (!\modo_cons~input_o\ & ((\u_dir_rf3|leds_temp\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \u_mem_rf4|Mux2~1_combout\,
	datad => \u_dir_rf3|leds_temp\(0),
	combout => \leds_salida~0_combout\);

-- Location: LCCOMB_X1_Y23_N14
\u_dir_rf3|leds_temp~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_dir_rf3|leds_temp~1_combout\ = (\sw_tamano~input_o\ & !\Equal1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sw_tamano~input_o\,
	datac => \Equal1~0_combout\,
	combout => \u_dir_rf3|leds_temp~1_combout\);

-- Location: FF_X1_Y23_N15
\u_dir_rf3|leds_temp[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_dir_rf3|leds_temp~1_combout\,
	clrn => \rst~input_o\,
	ena => \pulso_cualquiera~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_dir_rf3|leds_temp\(1));

-- Location: LCCOMB_X1_Y23_N20
\leds_salida~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \leds_salida~1_combout\ = (\modo_cons~input_o\ & ((\u_mem_rf4|Mux2~1_combout\))) # (!\modo_cons~input_o\ & (\u_dir_rf3|leds_temp\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datac => \u_dir_rf3|leds_temp\(1),
	datad => \u_mem_rf4|Mux2~1_combout\,
	combout => \leds_salida~1_combout\);

-- Location: FF_X1_Y23_N27
\u_dir_rf3|leds_temp[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \Equal1~0_combout\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \pulso_cualquiera~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_dir_rf3|leds_temp\(3));

-- Location: LCCOMB_X1_Y23_N26
\leds_salida~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \leds_salida~2_combout\ = (\u_dir_rf3|leds_temp\(3) & !\modo_cons~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_dir_rf3|leds_temp\(3),
	datad => \modo_cons~input_o\,
	combout => \leds_salida~2_combout\);

-- Location: LCCOMB_X2_Y23_N22
\u_gestor_rf5|Equal0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Equal0~8_combout\ = (\sinc_r|q~combout\ & ((\btn_v~input_o\ & ((\btn_a~input_o\) # (\btn_r~input_o\))) # (!\btn_v~input_o\ & (\btn_a~input_o\ & \btn_r~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_v~input_o\,
	datab => \btn_a~input_o\,
	datac => \sinc_r|q~combout\,
	datad => \btn_r~input_o\,
	combout => \u_gestor_rf5|Equal0~8_combout\);

-- Location: FF_X2_Y23_N23
\u_dir_rf3|leds_temp[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|Equal0~8_combout\,
	clrn => \rst~input_o\,
	ena => \pulso_cualquiera~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_dir_rf3|leds_temp\(5));

-- Location: LCCOMB_X2_Y23_N16
\cod_color[0]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cod_color[0]~0_combout\ = (!\trampa~0_combout\ & ((\sinc_r|q~combout\) # ((\comb~7_combout\ & !\comb~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \comb~7_combout\,
	datab => \sinc_r|q~combout\,
	datac => \trampa~0_combout\,
	datad => \comb~6_combout\,
	combout => \cod_color[0]~0_combout\);

-- Location: FF_X2_Y23_N17
\u_mem_rf4|registros[0][13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \cod_color[0]~0_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][13]~q\);

-- Location: LCCOMB_X2_Y23_N12
\u_mem_rf4|registros[1][13]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][13]~feeder_combout\ = \u_mem_rf4|registros[0][13]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][13]~q\,
	combout => \u_mem_rf4|registros[1][13]~feeder_combout\);

-- Location: FF_X2_Y23_N13
\u_mem_rf4|registros[1][13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][13]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][13]~q\);

-- Location: LCCOMB_X2_Y23_N26
\u_mem_rf4|registros[2][13]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][13]~feeder_combout\ = \u_mem_rf4|registros[1][13]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][13]~q\,
	combout => \u_mem_rf4|registros[2][13]~feeder_combout\);

-- Location: FF_X2_Y23_N27
\u_mem_rf4|registros[2][13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][13]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][13]~q\);

-- Location: FF_X2_Y23_N21
\u_mem_rf4|registros[3][13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][13]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][13]~q\);

-- Location: LCCOMB_X2_Y23_N28
\u_mem_rf4|salida_color[0]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|salida_color[0]~0_combout\ = (\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[1][13]~q\) # ((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & (((!\sel_memoria[1]~input_o\ & \u_mem_rf4|registros[0][13]~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[1][13]~q\,
	datab => \sel_memoria[0]~input_o\,
	datac => \sel_memoria[1]~input_o\,
	datad => \u_mem_rf4|registros[0][13]~q\,
	combout => \u_mem_rf4|salida_color[0]~0_combout\);

-- Location: LCCOMB_X2_Y23_N20
\u_mem_rf4|salida_color[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|salida_color[0]~1_combout\ = (\sel_memoria[1]~input_o\ & ((\u_mem_rf4|salida_color[0]~0_combout\ & ((\u_mem_rf4|registros[3][13]~q\))) # (!\u_mem_rf4|salida_color[0]~0_combout\ & (\u_mem_rf4|registros[2][13]~q\)))) # (!\sel_memoria[1]~input_o\ 
-- & (((\u_mem_rf4|salida_color[0]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][13]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[3][13]~q\,
	datad => \u_mem_rf4|salida_color[0]~0_combout\,
	combout => \u_mem_rf4|salida_color[0]~1_combout\);

-- Location: LCCOMB_X3_Y23_N10
\cod_color[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cod_color[1]~1_combout\ = (!\trampa~0_combout\ & (!\sinc_r|q~combout\ & ((\comb~7_combout\) # (\comb~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \trampa~0_combout\,
	datab => \comb~7_combout\,
	datac => \comb~6_combout\,
	datad => \sinc_r|q~combout\,
	combout => \cod_color[1]~1_combout\);

-- Location: FF_X3_Y23_N11
\u_mem_rf4|registros[0][14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \cod_color[1]~1_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][14]~q\);

-- Location: LCCOMB_X2_Y23_N10
\u_mem_rf4|registros[1][14]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][14]~feeder_combout\ = \u_mem_rf4|registros[0][14]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_mem_rf4|registros[0][14]~q\,
	combout => \u_mem_rf4|registros[1][14]~feeder_combout\);

-- Location: FF_X2_Y23_N11
\u_mem_rf4|registros[1][14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][14]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][14]~q\);

-- Location: LCCOMB_X2_Y23_N8
\u_mem_rf4|registros[2][14]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][14]~feeder_combout\ = \u_mem_rf4|registros[1][14]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][14]~q\,
	combout => \u_mem_rf4|registros[2][14]~feeder_combout\);

-- Location: FF_X2_Y23_N9
\u_mem_rf4|registros[2][14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][14]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][14]~q\);

-- Location: FF_X2_Y23_N25
\u_mem_rf4|registros[3][14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][14]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][14]~q\);

-- Location: LCCOMB_X2_Y23_N18
\u_mem_rf4|salida_color[1]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|salida_color[1]~2_combout\ = (\sel_memoria[1]~input_o\ & (((\u_mem_rf4|registros[2][14]~q\) # (\sel_memoria[0]~input_o\)))) # (!\sel_memoria[1]~input_o\ & (\u_mem_rf4|registros[0][14]~q\ & ((!\sel_memoria[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[0][14]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[2][14]~q\,
	datad => \sel_memoria[0]~input_o\,
	combout => \u_mem_rf4|salida_color[1]~2_combout\);

-- Location: LCCOMB_X2_Y23_N24
\u_mem_rf4|salida_color[1]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|salida_color[1]~3_combout\ = (\sel_memoria[0]~input_o\ & ((\u_mem_rf4|salida_color[1]~2_combout\ & ((\u_mem_rf4|registros[3][14]~q\))) # (!\u_mem_rf4|salida_color[1]~2_combout\ & (\u_mem_rf4|registros[1][14]~q\)))) # (!\sel_memoria[0]~input_o\ 
-- & (((\u_mem_rf4|salida_color[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[1][14]~q\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[3][14]~q\,
	datad => \u_mem_rf4|salida_color[1]~2_combout\,
	combout => \u_mem_rf4|salida_color[1]~3_combout\);

-- Location: LCCOMB_X2_Y23_N0
\leds_salida~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \leds_salida~3_combout\ = (\modo_cons~input_o\ & (((\u_mem_rf4|salida_color[0]~1_combout\ & !\u_mem_rf4|salida_color[1]~3_combout\)))) # (!\modo_cons~input_o\ & (\u_dir_rf3|leds_temp\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_dir_rf3|leds_temp\(5),
	datab => \u_mem_rf4|salida_color[0]~1_combout\,
	datac => \modo_cons~input_o\,
	datad => \u_mem_rf4|salida_color[1]~3_combout\,
	combout => \leds_salida~3_combout\);

-- Location: LCCOMB_X3_Y23_N8
\u_gestor_rf5|Equal0~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Equal0~9_combout\ = (\trampa~0_combout\) # (((!\sinc_r|d_sync2~q\ & \sinc_r|d_sync1~q\)) # (!\comb~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \trampa~0_combout\,
	datab => \sinc_r|d_sync2~q\,
	datac => \sinc_r|d_sync1~q\,
	datad => \comb~6_combout\,
	combout => \u_gestor_rf5|Equal0~9_combout\);

-- Location: LCCOMB_X2_Y23_N6
\u_dir_rf3|leds_temp[6]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_dir_rf3|leds_temp[6]~5_combout\ = !\u_gestor_rf5|Equal0~9_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_gestor_rf5|Equal0~9_combout\,
	combout => \u_dir_rf3|leds_temp[6]~5_combout\);

-- Location: FF_X2_Y23_N7
\u_dir_rf3|leds_temp[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_dir_rf3|leds_temp[6]~5_combout\,
	clrn => \rst~input_o\,
	ena => \pulso_cualquiera~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_dir_rf3|leds_temp\(6));

-- Location: LCCOMB_X2_Y23_N2
\leds_salida~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \leds_salida~4_combout\ = (\modo_cons~input_o\ & (((!\u_mem_rf4|salida_color[0]~1_combout\ & \u_mem_rf4|salida_color[1]~3_combout\)))) # (!\modo_cons~input_o\ & (\u_dir_rf3|leds_temp\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_dir_rf3|leds_temp\(6),
	datab => \u_mem_rf4|salida_color[0]~1_combout\,
	datac => \modo_cons~input_o\,
	datad => \u_mem_rf4|salida_color[1]~3_combout\,
	combout => \leds_salida~4_combout\);

-- Location: LCCOMB_X2_Y23_N30
\cod_color[1]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cod_color[1]~2_combout\ = (\comb~7_combout\ & (!\sinc_r|q~combout\ & (!\trampa~0_combout\ & !\comb~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \comb~7_combout\,
	datab => \sinc_r|q~combout\,
	datac => \trampa~0_combout\,
	datad => \comb~6_combout\,
	combout => \cod_color[1]~2_combout\);

-- Location: FF_X2_Y23_N31
\u_dir_rf3|leds_temp[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \cod_color[1]~2_combout\,
	clrn => \rst~input_o\,
	ena => \pulso_cualquiera~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_dir_rf3|leds_temp\(7));

-- Location: LCCOMB_X2_Y23_N4
\leds_salida~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \leds_salida~5_combout\ = (\modo_cons~input_o\ & (((\u_mem_rf4|salida_color[0]~1_combout\ & \u_mem_rf4|salida_color[1]~3_combout\)))) # (!\modo_cons~input_o\ & (\u_dir_rf3|leds_temp\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_dir_rf3|leds_temp\(7),
	datab => \u_mem_rf4|salida_color[0]~1_combout\,
	datac => \modo_cons~input_o\,
	datad => \u_mem_rf4|salida_color[1]~3_combout\,
	combout => \leds_salida~5_combout\);

-- Location: IOIBUF_X0_Y25_N22
\sel_vel[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel_vel(1),
	o => \sel_vel[1]~input_o\);

-- Location: LCCOMB_X7_Y24_N6
\u_div_var|conteo[0]~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[0]~26_combout\ = \u_div_var|conteo\(0) $ (VCC)
-- \u_div_var|conteo[0]~27\ = CARRY(\u_div_var|conteo\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(0),
	datad => VCC,
	combout => \u_div_var|conteo[0]~26_combout\,
	cout => \u_div_var|conteo[0]~27\);

-- Location: FF_X7_Y24_N7
\u_div_var|conteo[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[0]~26_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(0));

-- Location: LCCOMB_X7_Y24_N8
\u_div_var|conteo[1]~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[1]~28_combout\ = (\u_div_var|conteo\(1) & (!\u_div_var|conteo[0]~27\)) # (!\u_div_var|conteo\(1) & ((\u_div_var|conteo[0]~27\) # (GND)))
-- \u_div_var|conteo[1]~29\ = CARRY((!\u_div_var|conteo[0]~27\) # (!\u_div_var|conteo\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(1),
	datad => VCC,
	cin => \u_div_var|conteo[0]~27\,
	combout => \u_div_var|conteo[1]~28_combout\,
	cout => \u_div_var|conteo[1]~29\);

-- Location: FF_X7_Y24_N9
\u_div_var|conteo[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[1]~28_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(1));

-- Location: LCCOMB_X7_Y24_N10
\u_div_var|conteo[2]~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[2]~30_combout\ = (\u_div_var|conteo\(2) & (\u_div_var|conteo[1]~29\ $ (GND))) # (!\u_div_var|conteo\(2) & (!\u_div_var|conteo[1]~29\ & VCC))
-- \u_div_var|conteo[2]~31\ = CARRY((\u_div_var|conteo\(2) & !\u_div_var|conteo[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(2),
	datad => VCC,
	cin => \u_div_var|conteo[1]~29\,
	combout => \u_div_var|conteo[2]~30_combout\,
	cout => \u_div_var|conteo[2]~31\);

-- Location: FF_X7_Y24_N11
\u_div_var|conteo[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[2]~30_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(2));

-- Location: LCCOMB_X7_Y24_N12
\u_div_var|conteo[3]~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[3]~32_combout\ = (\u_div_var|conteo\(3) & (!\u_div_var|conteo[2]~31\)) # (!\u_div_var|conteo\(3) & ((\u_div_var|conteo[2]~31\) # (GND)))
-- \u_div_var|conteo[3]~33\ = CARRY((!\u_div_var|conteo[2]~31\) # (!\u_div_var|conteo\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(3),
	datad => VCC,
	cin => \u_div_var|conteo[2]~31\,
	combout => \u_div_var|conteo[3]~32_combout\,
	cout => \u_div_var|conteo[3]~33\);

-- Location: FF_X7_Y24_N13
\u_div_var|conteo[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[3]~32_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(3));

-- Location: LCCOMB_X7_Y24_N14
\u_div_var|conteo[4]~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[4]~34_combout\ = (\u_div_var|conteo\(4) & (\u_div_var|conteo[3]~33\ $ (GND))) # (!\u_div_var|conteo\(4) & (!\u_div_var|conteo[3]~33\ & VCC))
-- \u_div_var|conteo[4]~35\ = CARRY((\u_div_var|conteo\(4) & !\u_div_var|conteo[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(4),
	datad => VCC,
	cin => \u_div_var|conteo[3]~33\,
	combout => \u_div_var|conteo[4]~34_combout\,
	cout => \u_div_var|conteo[4]~35\);

-- Location: FF_X7_Y24_N15
\u_div_var|conteo[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[4]~34_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(4));

-- Location: LCCOMB_X7_Y24_N16
\u_div_var|conteo[5]~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[5]~36_combout\ = (\u_div_var|conteo\(5) & (!\u_div_var|conteo[4]~35\)) # (!\u_div_var|conteo\(5) & ((\u_div_var|conteo[4]~35\) # (GND)))
-- \u_div_var|conteo[5]~37\ = CARRY((!\u_div_var|conteo[4]~35\) # (!\u_div_var|conteo\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(5),
	datad => VCC,
	cin => \u_div_var|conteo[4]~35\,
	combout => \u_div_var|conteo[5]~36_combout\,
	cout => \u_div_var|conteo[5]~37\);

-- Location: FF_X7_Y24_N17
\u_div_var|conteo[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[5]~36_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(5));

-- Location: LCCOMB_X7_Y24_N18
\u_div_var|conteo[6]~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[6]~38_combout\ = (\u_div_var|conteo\(6) & (\u_div_var|conteo[5]~37\ $ (GND))) # (!\u_div_var|conteo\(6) & (!\u_div_var|conteo[5]~37\ & VCC))
-- \u_div_var|conteo[6]~39\ = CARRY((\u_div_var|conteo\(6) & !\u_div_var|conteo[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(6),
	datad => VCC,
	cin => \u_div_var|conteo[5]~37\,
	combout => \u_div_var|conteo[6]~38_combout\,
	cout => \u_div_var|conteo[6]~39\);

-- Location: FF_X7_Y24_N19
\u_div_var|conteo[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[6]~38_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(6));

-- Location: LCCOMB_X7_Y24_N20
\u_div_var|conteo[7]~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[7]~40_combout\ = (\u_div_var|conteo\(7) & (!\u_div_var|conteo[6]~39\)) # (!\u_div_var|conteo\(7) & ((\u_div_var|conteo[6]~39\) # (GND)))
-- \u_div_var|conteo[7]~41\ = CARRY((!\u_div_var|conteo[6]~39\) # (!\u_div_var|conteo\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(7),
	datad => VCC,
	cin => \u_div_var|conteo[6]~39\,
	combout => \u_div_var|conteo[7]~40_combout\,
	cout => \u_div_var|conteo[7]~41\);

-- Location: FF_X7_Y24_N21
\u_div_var|conteo[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[7]~40_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(7));

-- Location: LCCOMB_X7_Y24_N22
\u_div_var|conteo[8]~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[8]~42_combout\ = (\u_div_var|conteo\(8) & (\u_div_var|conteo[7]~41\ $ (GND))) # (!\u_div_var|conteo\(8) & (!\u_div_var|conteo[7]~41\ & VCC))
-- \u_div_var|conteo[8]~43\ = CARRY((\u_div_var|conteo\(8) & !\u_div_var|conteo[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(8),
	datad => VCC,
	cin => \u_div_var|conteo[7]~41\,
	combout => \u_div_var|conteo[8]~42_combout\,
	cout => \u_div_var|conteo[8]~43\);

-- Location: FF_X7_Y24_N23
\u_div_var|conteo[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[8]~42_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(8));

-- Location: LCCOMB_X7_Y24_N24
\u_div_var|conteo[9]~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[9]~44_combout\ = (\u_div_var|conteo\(9) & (!\u_div_var|conteo[8]~43\)) # (!\u_div_var|conteo\(9) & ((\u_div_var|conteo[8]~43\) # (GND)))
-- \u_div_var|conteo[9]~45\ = CARRY((!\u_div_var|conteo[8]~43\) # (!\u_div_var|conteo\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(9),
	datad => VCC,
	cin => \u_div_var|conteo[8]~43\,
	combout => \u_div_var|conteo[9]~44_combout\,
	cout => \u_div_var|conteo[9]~45\);

-- Location: FF_X7_Y24_N25
\u_div_var|conteo[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[9]~44_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(9));

-- Location: LCCOMB_X7_Y24_N26
\u_div_var|conteo[10]~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[10]~46_combout\ = (\u_div_var|conteo\(10) & (\u_div_var|conteo[9]~45\ $ (GND))) # (!\u_div_var|conteo\(10) & (!\u_div_var|conteo[9]~45\ & VCC))
-- \u_div_var|conteo[10]~47\ = CARRY((\u_div_var|conteo\(10) & !\u_div_var|conteo[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(10),
	datad => VCC,
	cin => \u_div_var|conteo[9]~45\,
	combout => \u_div_var|conteo[10]~46_combout\,
	cout => \u_div_var|conteo[10]~47\);

-- Location: FF_X7_Y24_N27
\u_div_var|conteo[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[10]~46_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(10));

-- Location: LCCOMB_X7_Y24_N28
\u_div_var|conteo[11]~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[11]~48_combout\ = (\u_div_var|conteo\(11) & (!\u_div_var|conteo[10]~47\)) # (!\u_div_var|conteo\(11) & ((\u_div_var|conteo[10]~47\) # (GND)))
-- \u_div_var|conteo[11]~49\ = CARRY((!\u_div_var|conteo[10]~47\) # (!\u_div_var|conteo\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(11),
	datad => VCC,
	cin => \u_div_var|conteo[10]~47\,
	combout => \u_div_var|conteo[11]~48_combout\,
	cout => \u_div_var|conteo[11]~49\);

-- Location: FF_X7_Y24_N29
\u_div_var|conteo[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[11]~48_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(11));

-- Location: LCCOMB_X7_Y24_N30
\u_div_var|conteo[12]~50\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[12]~50_combout\ = (\u_div_var|conteo\(12) & (\u_div_var|conteo[11]~49\ $ (GND))) # (!\u_div_var|conteo\(12) & (!\u_div_var|conteo[11]~49\ & VCC))
-- \u_div_var|conteo[12]~51\ = CARRY((\u_div_var|conteo\(12) & !\u_div_var|conteo[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(12),
	datad => VCC,
	cin => \u_div_var|conteo[11]~49\,
	combout => \u_div_var|conteo[12]~50_combout\,
	cout => \u_div_var|conteo[12]~51\);

-- Location: FF_X7_Y24_N31
\u_div_var|conteo[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[12]~50_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(12));

-- Location: LCCOMB_X7_Y23_N0
\u_div_var|conteo[13]~52\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[13]~52_combout\ = (\u_div_var|conteo\(13) & (!\u_div_var|conteo[12]~51\)) # (!\u_div_var|conteo\(13) & ((\u_div_var|conteo[12]~51\) # (GND)))
-- \u_div_var|conteo[13]~53\ = CARRY((!\u_div_var|conteo[12]~51\) # (!\u_div_var|conteo\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(13),
	datad => VCC,
	cin => \u_div_var|conteo[12]~51\,
	combout => \u_div_var|conteo[13]~52_combout\,
	cout => \u_div_var|conteo[13]~53\);

-- Location: FF_X7_Y23_N1
\u_div_var|conteo[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[13]~52_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(13));

-- Location: LCCOMB_X7_Y23_N2
\u_div_var|conteo[14]~54\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[14]~54_combout\ = (\u_div_var|conteo\(14) & (\u_div_var|conteo[13]~53\ $ (GND))) # (!\u_div_var|conteo\(14) & (!\u_div_var|conteo[13]~53\ & VCC))
-- \u_div_var|conteo[14]~55\ = CARRY((\u_div_var|conteo\(14) & !\u_div_var|conteo[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(14),
	datad => VCC,
	cin => \u_div_var|conteo[13]~53\,
	combout => \u_div_var|conteo[14]~54_combout\,
	cout => \u_div_var|conteo[14]~55\);

-- Location: FF_X6_Y24_N1
\u_div_var|conteo[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_div_var|conteo[14]~54_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(14));

-- Location: LCCOMB_X7_Y23_N4
\u_div_var|conteo[15]~56\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[15]~56_combout\ = (\u_div_var|conteo\(15) & (!\u_div_var|conteo[14]~55\)) # (!\u_div_var|conteo\(15) & ((\u_div_var|conteo[14]~55\) # (GND)))
-- \u_div_var|conteo[15]~57\ = CARRY((!\u_div_var|conteo[14]~55\) # (!\u_div_var|conteo\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(15),
	datad => VCC,
	cin => \u_div_var|conteo[14]~55\,
	combout => \u_div_var|conteo[15]~56_combout\,
	cout => \u_div_var|conteo[15]~57\);

-- Location: FF_X6_Y24_N11
\u_div_var|conteo[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_div_var|conteo[15]~56_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(15));

-- Location: LCCOMB_X7_Y23_N6
\u_div_var|conteo[16]~58\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[16]~58_combout\ = (\u_div_var|conteo\(16) & (\u_div_var|conteo[15]~57\ $ (GND))) # (!\u_div_var|conteo\(16) & (!\u_div_var|conteo[15]~57\ & VCC))
-- \u_div_var|conteo[16]~59\ = CARRY((\u_div_var|conteo\(16) & !\u_div_var|conteo[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(16),
	datad => VCC,
	cin => \u_div_var|conteo[15]~57\,
	combout => \u_div_var|conteo[16]~58_combout\,
	cout => \u_div_var|conteo[16]~59\);

-- Location: FF_X6_Y24_N21
\u_div_var|conteo[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_div_var|conteo[16]~58_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(16));

-- Location: LCCOMB_X7_Y23_N8
\u_div_var|conteo[17]~60\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[17]~60_combout\ = (\u_div_var|conteo\(17) & (!\u_div_var|conteo[16]~59\)) # (!\u_div_var|conteo\(17) & ((\u_div_var|conteo[16]~59\) # (GND)))
-- \u_div_var|conteo[17]~61\ = CARRY((!\u_div_var|conteo[16]~59\) # (!\u_div_var|conteo\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(17),
	datad => VCC,
	cin => \u_div_var|conteo[16]~59\,
	combout => \u_div_var|conteo[17]~60_combout\,
	cout => \u_div_var|conteo[17]~61\);

-- Location: FF_X7_Y23_N9
\u_div_var|conteo[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[17]~60_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(17));

-- Location: LCCOMB_X7_Y23_N10
\u_div_var|conteo[18]~62\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[18]~62_combout\ = (\u_div_var|conteo\(18) & (\u_div_var|conteo[17]~61\ $ (GND))) # (!\u_div_var|conteo\(18) & (!\u_div_var|conteo[17]~61\ & VCC))
-- \u_div_var|conteo[18]~63\ = CARRY((\u_div_var|conteo\(18) & !\u_div_var|conteo[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(18),
	datad => VCC,
	cin => \u_div_var|conteo[17]~61\,
	combout => \u_div_var|conteo[18]~62_combout\,
	cout => \u_div_var|conteo[18]~63\);

-- Location: FF_X7_Y23_N11
\u_div_var|conteo[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[18]~62_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(18));

-- Location: LCCOMB_X7_Y23_N12
\u_div_var|conteo[19]~64\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[19]~64_combout\ = (\u_div_var|conteo\(19) & (!\u_div_var|conteo[18]~63\)) # (!\u_div_var|conteo\(19) & ((\u_div_var|conteo[18]~63\) # (GND)))
-- \u_div_var|conteo[19]~65\ = CARRY((!\u_div_var|conteo[18]~63\) # (!\u_div_var|conteo\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(19),
	datad => VCC,
	cin => \u_div_var|conteo[18]~63\,
	combout => \u_div_var|conteo[19]~64_combout\,
	cout => \u_div_var|conteo[19]~65\);

-- Location: FF_X7_Y23_N13
\u_div_var|conteo[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[19]~64_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(19));

-- Location: LCCOMB_X7_Y23_N14
\u_div_var|conteo[20]~66\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[20]~66_combout\ = (\u_div_var|conteo\(20) & (\u_div_var|conteo[19]~65\ $ (GND))) # (!\u_div_var|conteo\(20) & (!\u_div_var|conteo[19]~65\ & VCC))
-- \u_div_var|conteo[20]~67\ = CARRY((\u_div_var|conteo\(20) & !\u_div_var|conteo[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(20),
	datad => VCC,
	cin => \u_div_var|conteo[19]~65\,
	combout => \u_div_var|conteo[20]~66_combout\,
	cout => \u_div_var|conteo[20]~67\);

-- Location: FF_X7_Y23_N15
\u_div_var|conteo[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[20]~66_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(20));

-- Location: LCCOMB_X7_Y23_N16
\u_div_var|conteo[21]~68\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[21]~68_combout\ = (\u_div_var|conteo\(21) & (!\u_div_var|conteo[20]~67\)) # (!\u_div_var|conteo\(21) & ((\u_div_var|conteo[20]~67\) # (GND)))
-- \u_div_var|conteo[21]~69\ = CARRY((!\u_div_var|conteo[20]~67\) # (!\u_div_var|conteo\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(21),
	datad => VCC,
	cin => \u_div_var|conteo[20]~67\,
	combout => \u_div_var|conteo[21]~68_combout\,
	cout => \u_div_var|conteo[21]~69\);

-- Location: FF_X7_Y23_N17
\u_div_var|conteo[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[21]~68_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(21));

-- Location: LCCOMB_X7_Y23_N18
\u_div_var|conteo[22]~70\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[22]~70_combout\ = (\u_div_var|conteo\(22) & (\u_div_var|conteo[21]~69\ $ (GND))) # (!\u_div_var|conteo\(22) & (!\u_div_var|conteo[21]~69\ & VCC))
-- \u_div_var|conteo[22]~71\ = CARRY((\u_div_var|conteo\(22) & !\u_div_var|conteo[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(22),
	datad => VCC,
	cin => \u_div_var|conteo[21]~69\,
	combout => \u_div_var|conteo[22]~70_combout\,
	cout => \u_div_var|conteo[22]~71\);

-- Location: FF_X7_Y23_N19
\u_div_var|conteo[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[22]~70_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(22));

-- Location: LCCOMB_X7_Y23_N20
\u_div_var|conteo[23]~72\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[23]~72_combout\ = (\u_div_var|conteo\(23) & (!\u_div_var|conteo[22]~71\)) # (!\u_div_var|conteo\(23) & ((\u_div_var|conteo[22]~71\) # (GND)))
-- \u_div_var|conteo[23]~73\ = CARRY((!\u_div_var|conteo[22]~71\) # (!\u_div_var|conteo\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(23),
	datad => VCC,
	cin => \u_div_var|conteo[22]~71\,
	combout => \u_div_var|conteo[23]~72_combout\,
	cout => \u_div_var|conteo[23]~73\);

-- Location: FF_X7_Y23_N21
\u_div_var|conteo[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[23]~72_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(23));

-- Location: LCCOMB_X7_Y23_N22
\u_div_var|conteo[24]~74\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[24]~74_combout\ = (\u_div_var|conteo\(24) & (\u_div_var|conteo[23]~73\ $ (GND))) # (!\u_div_var|conteo\(24) & (!\u_div_var|conteo[23]~73\ & VCC))
-- \u_div_var|conteo[24]~75\ = CARRY((\u_div_var|conteo\(24) & !\u_div_var|conteo[23]~73\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(24),
	datad => VCC,
	cin => \u_div_var|conteo[23]~73\,
	combout => \u_div_var|conteo[24]~74_combout\,
	cout => \u_div_var|conteo[24]~75\);

-- Location: FF_X7_Y23_N23
\u_div_var|conteo[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[24]~74_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(24));

-- Location: IOIBUF_X0_Y27_N1
\sel_vel[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel_vel(0),
	o => \sel_vel[0]~input_o\);

-- Location: LCCOMB_X7_Y23_N24
\u_div_var|conteo[25]~76\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|conteo[25]~76_combout\ = \u_div_var|conteo[24]~75\ $ (\u_div_var|conteo\(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u_div_var|conteo\(25),
	cin => \u_div_var|conteo[24]~75\,
	combout => \u_div_var|conteo[25]~76_combout\);

-- Location: FF_X7_Y23_N25
\u_div_var|conteo[25]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|conteo[25]~76_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_var|ALT_INV_LessThan0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|conteo\(25));

-- Location: LCCOMB_X6_Y23_N2
\u_div_var|LessThan0~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~10_combout\ = (!\sel_vel[1]~input_o\ & (!\u_div_var|conteo\(25) & ((!\sel_vel[0]~input_o\) # (!\u_div_var|conteo\(24)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \u_div_var|conteo\(24),
	datac => \sel_vel[0]~input_o\,
	datad => \u_div_var|conteo\(25),
	combout => \u_div_var|LessThan0~10_combout\);

-- Location: LCCOMB_X6_Y23_N0
\u_div_var|LessThan0~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~11_combout\ = (\sel_vel[0]~input_o\ & (!\u_div_var|conteo\(25) & (\sel_vel[1]~input_o\ $ (\u_div_var|conteo\(24))))) # (!\sel_vel[0]~input_o\ & (!\u_div_var|conteo\(24) & (\sel_vel[1]~input_o\ $ (\u_div_var|conteo\(25)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000101100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \u_div_var|conteo\(24),
	datac => \sel_vel[0]~input_o\,
	datad => \u_div_var|conteo\(25),
	combout => \u_div_var|LessThan0~11_combout\);

-- Location: LCCOMB_X6_Y23_N6
\u_div_var|LessThan0~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~30_combout\ = (\sel_vel[0]~input_o\ & (((!\u_div_var|conteo\(23) & !\u_div_var|conteo\(22))))) # (!\sel_vel[0]~input_o\ & (((!\sel_vel[1]~input_o\ & !\u_div_var|conteo\(22))) # (!\u_div_var|conteo\(23))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \sel_vel[0]~input_o\,
	datac => \u_div_var|conteo\(23),
	datad => \u_div_var|conteo\(22),
	combout => \u_div_var|LessThan0~30_combout\);

-- Location: LCCOMB_X7_Y23_N28
\u_div_var|LessThan0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~7_combout\ = (\sel_vel[1]~input_o\ & (((\u_div_var|conteo\(17) & \u_div_var|conteo\(18))))) # (!\sel_vel[1]~input_o\ & ((\u_div_var|conteo\(18)) # ((!\sel_vel[0]~input_o\ & \u_div_var|conteo\(17)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[0]~input_o\,
	datab => \sel_vel[1]~input_o\,
	datac => \u_div_var|conteo\(17),
	datad => \u_div_var|conteo\(18),
	combout => \u_div_var|LessThan0~7_combout\);

-- Location: LCCOMB_X7_Y23_N26
\u_div_var|LessThan0~33\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~33_combout\ = (\u_div_var|conteo\(19) & (\u_div_var|conteo\(21) & \u_div_var|LessThan0~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(19),
	datab => \u_div_var|conteo\(21),
	datad => \u_div_var|LessThan0~7_combout\,
	combout => \u_div_var|LessThan0~33_combout\);

-- Location: LCCOMB_X7_Y23_N30
\u_div_var|LessThan0~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~12_combout\ = (\sel_vel[0]~input_o\ & (\u_div_var|conteo\(22) & ((!\u_div_var|conteo\(23))))) # (!\sel_vel[0]~input_o\ & (\u_div_var|conteo\(23) & (\u_div_var|conteo\(22) $ (\sel_vel[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[0]~input_o\,
	datab => \u_div_var|conteo\(22),
	datac => \sel_vel[1]~input_o\,
	datad => \u_div_var|conteo\(23),
	combout => \u_div_var|LessThan0~12_combout\);

-- Location: LCCOMB_X6_Y24_N8
\u_div_var|LessThan0~31\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~31_combout\ = (\u_div_var|LessThan0~30_combout\) # ((\u_div_var|LessThan0~12_combout\ & ((!\u_div_var|LessThan0~33_combout\) # (!\u_div_var|conteo\(20)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|LessThan0~30_combout\,
	datab => \u_div_var|conteo\(20),
	datac => \u_div_var|LessThan0~33_combout\,
	datad => \u_div_var|LessThan0~12_combout\,
	combout => \u_div_var|LessThan0~31_combout\);

-- Location: LCCOMB_X6_Y24_N28
\u_div_var|LessThan0~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~15_combout\ = (\sel_vel[0]~input_o\ & (!\u_div_var|conteo\(15) & \u_div_var|conteo\(16))) # (!\sel_vel[0]~input_o\ & (\u_div_var|conteo\(15) & !\u_div_var|conteo\(16)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sel_vel[0]~input_o\,
	datac => \u_div_var|conteo\(15),
	datad => \u_div_var|conteo\(16),
	combout => \u_div_var|LessThan0~15_combout\);

-- Location: LCCOMB_X6_Y24_N10
\u_div_var|LessThan0~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~27_combout\ = (!\sel_vel[1]~input_o\ & (!\u_div_var|conteo\(14) & \u_div_var|LessThan0~15_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \u_div_var|conteo\(14),
	datad => \u_div_var|LessThan0~15_combout\,
	combout => \u_div_var|LessThan0~27_combout\);

-- Location: LCCOMB_X6_Y24_N20
\u_div_var|LessThan0~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~28_combout\ = (!\u_div_var|conteo\(16) & ((\sel_vel[0]~input_o\) # (!\u_div_var|conteo\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_div_var|conteo\(15),
	datac => \u_div_var|conteo\(16),
	datad => \sel_vel[0]~input_o\,
	combout => \u_div_var|LessThan0~28_combout\);

-- Location: LCCOMB_X3_Y24_N24
\u_gestor_rf5|Equal11~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Equal11~0_combout\ = (\sel_vel[1]~input_o\) # (\sel_vel[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datad => \sel_vel[0]~input_o\,
	combout => \u_gestor_rf5|Equal11~0_combout\);

-- Location: LCCOMB_X6_Y24_N0
\u_div_var|LessThan0~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~13_combout\ = \u_div_var|conteo\(17) $ (((!\sel_vel[1]~input_o\ & \sel_vel[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101101000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \sel_vel[0]~input_o\,
	datad => \u_div_var|conteo\(17),
	combout => \u_div_var|LessThan0~13_combout\);

-- Location: LCCOMB_X6_Y24_N22
\u_div_var|LessThan0~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~14_combout\ = (\u_div_var|LessThan0~13_combout\ & (\u_div_var|LessThan0~12_combout\ & (\u_gestor_rf5|Equal11~0_combout\ $ (!\u_div_var|conteo\(18)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|Equal11~0_combout\,
	datab => \u_div_var|LessThan0~13_combout\,
	datac => \u_div_var|conteo\(18),
	datad => \u_div_var|LessThan0~12_combout\,
	combout => \u_div_var|LessThan0~14_combout\);

-- Location: LCCOMB_X6_Y24_N4
\u_div_var|LessThan0~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~17_combout\ = (\u_div_var|conteo\(12) & (!\u_div_var|conteo\(11) & (\sel_vel[1]~input_o\ $ (\sel_vel[0]~input_o\)))) # (!\u_div_var|conteo\(12) & (((!\u_div_var|conteo\(11)) # (!\sel_vel[0]~input_o\)) # (!\sel_vel[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011101101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \sel_vel[0]~input_o\,
	datac => \u_div_var|conteo\(12),
	datad => \u_div_var|conteo\(11),
	combout => \u_div_var|LessThan0~17_combout\);

-- Location: LCCOMB_X6_Y24_N2
\u_div_var|LessThan0~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~18_combout\ = (\sel_vel[1]~input_o\ & (!\sel_vel[0]~input_o\ & (\u_div_var|conteo\(12) & \u_div_var|conteo\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \sel_vel[0]~input_o\,
	datac => \u_div_var|conteo\(12),
	datad => \u_div_var|conteo\(11),
	combout => \u_div_var|LessThan0~18_combout\);

-- Location: LCCOMB_X6_Y24_N12
\u_div_var|LessThan0~19\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~19_combout\ = ((\u_div_var|LessThan0~17_combout\) # ((!\u_div_var|conteo\(10) & \u_div_var|LessThan0~18_combout\))) # (!\u_div_var|conteo\(13))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(13),
	datab => \u_div_var|conteo\(10),
	datac => \u_div_var|LessThan0~17_combout\,
	datad => \u_div_var|LessThan0~18_combout\,
	combout => \u_div_var|LessThan0~19_combout\);

-- Location: LCCOMB_X6_Y24_N18
\u_div_var|LessThan0~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~16_combout\ = (\u_div_var|LessThan0~15_combout\ & (\sel_vel[1]~input_o\ $ (\u_div_var|conteo\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datac => \u_div_var|conteo\(14),
	datad => \u_div_var|LessThan0~15_combout\,
	combout => \u_div_var|LessThan0~16_combout\);

-- Location: LCCOMB_X6_Y24_N26
\u_div_var|LessThan0~23\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~23_combout\ = (\sel_vel[1]~input_o\ & (\u_div_var|conteo\(11) & (\sel_vel[0]~input_o\ $ (\u_div_var|conteo\(12))))) # (!\sel_vel[1]~input_o\ & (\u_div_var|conteo\(12) & (\sel_vel[0]~input_o\ $ (!\u_div_var|conteo\(11)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \sel_vel[0]~input_o\,
	datac => \u_div_var|conteo\(12),
	datad => \u_div_var|conteo\(11),
	combout => \u_div_var|LessThan0~23_combout\);

-- Location: LCCOMB_X6_Y24_N16
\u_div_var|LessThan0~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~24_combout\ = (!\u_div_var|conteo\(7) & (\u_div_var|conteo\(10) $ (((\sel_vel[0]~input_o\) # (!\sel_vel[1]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[1]~input_o\,
	datab => \sel_vel[0]~input_o\,
	datac => \u_div_var|conteo\(7),
	datad => \u_div_var|conteo\(10),
	combout => \u_div_var|LessThan0~24_combout\);

-- Location: LCCOMB_X6_Y24_N14
\u_div_var|LessThan0~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~25_combout\ = (!\u_div_var|conteo\(9) & (!\u_div_var|conteo\(8) & (\u_div_var|LessThan0~23_combout\ & \u_div_var|LessThan0~24_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(9),
	datab => \u_div_var|conteo\(8),
	datac => \u_div_var|LessThan0~23_combout\,
	datad => \u_div_var|LessThan0~24_combout\,
	combout => \u_div_var|LessThan0~25_combout\);

-- Location: LCCOMB_X7_Y24_N0
\u_div_var|LessThan0~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~20_combout\ = (!\u_div_var|conteo\(3) & (((!\u_div_var|conteo\(1) & !\u_div_var|conteo\(0))) # (!\u_div_var|conteo\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|conteo\(3),
	datab => \u_div_var|conteo\(1),
	datac => \u_div_var|conteo\(2),
	datad => \u_div_var|conteo\(0),
	combout => \u_div_var|LessThan0~20_combout\);

-- Location: LCCOMB_X7_Y24_N2
\u_div_var|LessThan0~21\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~21_combout\ = (\u_div_var|conteo\(5)) # ((\sel_vel[0]~input_o\ & (\u_div_var|conteo\(4) & !\u_div_var|LessThan0~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[0]~input_o\,
	datab => \u_div_var|conteo\(5),
	datac => \u_div_var|conteo\(4),
	datad => \u_div_var|LessThan0~20_combout\,
	combout => \u_div_var|LessThan0~21_combout\);

-- Location: LCCOMB_X7_Y24_N4
\u_div_var|LessThan0~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~22_combout\ = (\u_div_var|conteo\(6) & (!\sel_vel[0]~input_o\ & (!\sel_vel[1]~input_o\))) # (!\u_div_var|conteo\(6) & (((!\u_div_var|LessThan0~21_combout\) # (!\sel_vel[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011100110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_vel[0]~input_o\,
	datab => \u_div_var|conteo\(6),
	datac => \sel_vel[1]~input_o\,
	datad => \u_div_var|LessThan0~21_combout\,
	combout => \u_div_var|LessThan0~22_combout\);

-- Location: LCCOMB_X6_Y24_N24
\u_div_var|LessThan0~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~26_combout\ = (\u_div_var|LessThan0~16_combout\ & ((\u_div_var|LessThan0~19_combout\) # ((\u_div_var|LessThan0~25_combout\ & \u_div_var|LessThan0~22_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|LessThan0~19_combout\,
	datab => \u_div_var|LessThan0~16_combout\,
	datac => \u_div_var|LessThan0~25_combout\,
	datad => \u_div_var|LessThan0~22_combout\,
	combout => \u_div_var|LessThan0~26_combout\);

-- Location: LCCOMB_X6_Y24_N6
\u_div_var|LessThan0~29\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~29_combout\ = (\u_div_var|LessThan0~14_combout\ & ((\u_div_var|LessThan0~27_combout\) # ((\u_div_var|LessThan0~28_combout\) # (\u_div_var|LessThan0~26_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|LessThan0~27_combout\,
	datab => \u_div_var|LessThan0~28_combout\,
	datac => \u_div_var|LessThan0~14_combout\,
	datad => \u_div_var|LessThan0~26_combout\,
	combout => \u_div_var|LessThan0~29_combout\);

-- Location: LCCOMB_X6_Y24_N30
\u_div_var|LessThan0~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|LessThan0~32_combout\ = (\u_div_var|LessThan0~10_combout\) # ((\u_div_var|LessThan0~11_combout\ & ((\u_div_var|LessThan0~31_combout\) # (\u_div_var|LessThan0~29_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|LessThan0~10_combout\,
	datab => \u_div_var|LessThan0~11_combout\,
	datac => \u_div_var|LessThan0~31_combout\,
	datad => \u_div_var|LessThan0~29_combout\,
	combout => \u_div_var|LessThan0~32_combout\);

-- Location: LCCOMB_X6_Y23_N28
\u_div_var|estado~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_var|estado~0_combout\ = \u_div_var|LessThan0~32_combout\ $ (!\u_div_var|estado~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010110100101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_var|LessThan0~32_combout\,
	datac => \u_div_var|estado~q\,
	combout => \u_div_var|estado~0_combout\);

-- Location: FF_X6_Y23_N29
\u_div_var|estado\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_var|estado~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_var|estado~q\);

-- Location: LCCOMB_X3_Y25_N4
\led_frec~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \led_frec~0_combout\ = (\u_div_var|estado~q\ & (((\sw_menu[0]~input_o\) # (!\sw_menu[1]~input_o\)) # (!\sw_menu[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[2]~input_o\,
	datab => \sw_menu[1]~input_o\,
	datac => \sw_menu[0]~input_o\,
	datad => \u_div_var|estado~q\,
	combout => \led_frec~0_combout\);

-- Location: LCCOMB_X2_Y28_N8
\u_div_rtc|conteo[0]~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[0]~25_combout\ = \u_div_rtc|conteo\(0) $ (VCC)
-- \u_div_rtc|conteo[0]~26\ = CARRY(\u_div_rtc|conteo\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(0),
	datad => VCC,
	combout => \u_div_rtc|conteo[0]~25_combout\,
	cout => \u_div_rtc|conteo[0]~26\);

-- Location: FF_X2_Y28_N9
\u_div_rtc|conteo[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[0]~25_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(0));

-- Location: LCCOMB_X2_Y28_N10
\u_div_rtc|conteo[1]~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[1]~27_combout\ = (\u_div_rtc|conteo\(1) & (!\u_div_rtc|conteo[0]~26\)) # (!\u_div_rtc|conteo\(1) & ((\u_div_rtc|conteo[0]~26\) # (GND)))
-- \u_div_rtc|conteo[1]~28\ = CARRY((!\u_div_rtc|conteo[0]~26\) # (!\u_div_rtc|conteo\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(1),
	datad => VCC,
	cin => \u_div_rtc|conteo[0]~26\,
	combout => \u_div_rtc|conteo[1]~27_combout\,
	cout => \u_div_rtc|conteo[1]~28\);

-- Location: FF_X2_Y28_N11
\u_div_rtc|conteo[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[1]~27_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(1));

-- Location: LCCOMB_X2_Y28_N12
\u_div_rtc|conteo[2]~29\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[2]~29_combout\ = (\u_div_rtc|conteo\(2) & (\u_div_rtc|conteo[1]~28\ $ (GND))) # (!\u_div_rtc|conteo\(2) & (!\u_div_rtc|conteo[1]~28\ & VCC))
-- \u_div_rtc|conteo[2]~30\ = CARRY((\u_div_rtc|conteo\(2) & !\u_div_rtc|conteo[1]~28\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(2),
	datad => VCC,
	cin => \u_div_rtc|conteo[1]~28\,
	combout => \u_div_rtc|conteo[2]~29_combout\,
	cout => \u_div_rtc|conteo[2]~30\);

-- Location: FF_X2_Y28_N13
\u_div_rtc|conteo[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[2]~29_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(2));

-- Location: LCCOMB_X2_Y28_N14
\u_div_rtc|conteo[3]~31\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[3]~31_combout\ = (\u_div_rtc|conteo\(3) & (!\u_div_rtc|conteo[2]~30\)) # (!\u_div_rtc|conteo\(3) & ((\u_div_rtc|conteo[2]~30\) # (GND)))
-- \u_div_rtc|conteo[3]~32\ = CARRY((!\u_div_rtc|conteo[2]~30\) # (!\u_div_rtc|conteo\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(3),
	datad => VCC,
	cin => \u_div_rtc|conteo[2]~30\,
	combout => \u_div_rtc|conteo[3]~31_combout\,
	cout => \u_div_rtc|conteo[3]~32\);

-- Location: FF_X2_Y28_N15
\u_div_rtc|conteo[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[3]~31_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(3));

-- Location: LCCOMB_X2_Y28_N16
\u_div_rtc|conteo[4]~33\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[4]~33_combout\ = (\u_div_rtc|conteo\(4) & (\u_div_rtc|conteo[3]~32\ $ (GND))) # (!\u_div_rtc|conteo\(4) & (!\u_div_rtc|conteo[3]~32\ & VCC))
-- \u_div_rtc|conteo[4]~34\ = CARRY((\u_div_rtc|conteo\(4) & !\u_div_rtc|conteo[3]~32\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(4),
	datad => VCC,
	cin => \u_div_rtc|conteo[3]~32\,
	combout => \u_div_rtc|conteo[4]~33_combout\,
	cout => \u_div_rtc|conteo[4]~34\);

-- Location: FF_X2_Y28_N17
\u_div_rtc|conteo[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[4]~33_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(4));

-- Location: LCCOMB_X2_Y28_N18
\u_div_rtc|conteo[5]~35\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[5]~35_combout\ = (\u_div_rtc|conteo\(5) & (!\u_div_rtc|conteo[4]~34\)) # (!\u_div_rtc|conteo\(5) & ((\u_div_rtc|conteo[4]~34\) # (GND)))
-- \u_div_rtc|conteo[5]~36\ = CARRY((!\u_div_rtc|conteo[4]~34\) # (!\u_div_rtc|conteo\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(5),
	datad => VCC,
	cin => \u_div_rtc|conteo[4]~34\,
	combout => \u_div_rtc|conteo[5]~35_combout\,
	cout => \u_div_rtc|conteo[5]~36\);

-- Location: FF_X2_Y28_N19
\u_div_rtc|conteo[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[5]~35_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(5));

-- Location: LCCOMB_X2_Y28_N20
\u_div_rtc|conteo[6]~37\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[6]~37_combout\ = (\u_div_rtc|conteo\(6) & (\u_div_rtc|conteo[5]~36\ $ (GND))) # (!\u_div_rtc|conteo\(6) & (!\u_div_rtc|conteo[5]~36\ & VCC))
-- \u_div_rtc|conteo[6]~38\ = CARRY((\u_div_rtc|conteo\(6) & !\u_div_rtc|conteo[5]~36\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(6),
	datad => VCC,
	cin => \u_div_rtc|conteo[5]~36\,
	combout => \u_div_rtc|conteo[6]~37_combout\,
	cout => \u_div_rtc|conteo[6]~38\);

-- Location: FF_X2_Y28_N21
\u_div_rtc|conteo[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[6]~37_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(6));

-- Location: LCCOMB_X2_Y28_N22
\u_div_rtc|conteo[7]~39\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[7]~39_combout\ = (\u_div_rtc|conteo\(7) & (!\u_div_rtc|conteo[6]~38\)) # (!\u_div_rtc|conteo\(7) & ((\u_div_rtc|conteo[6]~38\) # (GND)))
-- \u_div_rtc|conteo[7]~40\ = CARRY((!\u_div_rtc|conteo[6]~38\) # (!\u_div_rtc|conteo\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(7),
	datad => VCC,
	cin => \u_div_rtc|conteo[6]~38\,
	combout => \u_div_rtc|conteo[7]~39_combout\,
	cout => \u_div_rtc|conteo[7]~40\);

-- Location: FF_X2_Y28_N23
\u_div_rtc|conteo[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[7]~39_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(7));

-- Location: LCCOMB_X2_Y28_N24
\u_div_rtc|conteo[8]~41\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[8]~41_combout\ = (\u_div_rtc|conteo\(8) & (\u_div_rtc|conteo[7]~40\ $ (GND))) # (!\u_div_rtc|conteo\(8) & (!\u_div_rtc|conteo[7]~40\ & VCC))
-- \u_div_rtc|conteo[8]~42\ = CARRY((\u_div_rtc|conteo\(8) & !\u_div_rtc|conteo[7]~40\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(8),
	datad => VCC,
	cin => \u_div_rtc|conteo[7]~40\,
	combout => \u_div_rtc|conteo[8]~41_combout\,
	cout => \u_div_rtc|conteo[8]~42\);

-- Location: FF_X2_Y28_N25
\u_div_rtc|conteo[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[8]~41_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(8));

-- Location: LCCOMB_X2_Y28_N26
\u_div_rtc|conteo[9]~43\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[9]~43_combout\ = (\u_div_rtc|conteo\(9) & (!\u_div_rtc|conteo[8]~42\)) # (!\u_div_rtc|conteo\(9) & ((\u_div_rtc|conteo[8]~42\) # (GND)))
-- \u_div_rtc|conteo[9]~44\ = CARRY((!\u_div_rtc|conteo[8]~42\) # (!\u_div_rtc|conteo\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(9),
	datad => VCC,
	cin => \u_div_rtc|conteo[8]~42\,
	combout => \u_div_rtc|conteo[9]~43_combout\,
	cout => \u_div_rtc|conteo[9]~44\);

-- Location: FF_X2_Y28_N27
\u_div_rtc|conteo[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[9]~43_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(9));

-- Location: LCCOMB_X2_Y28_N28
\u_div_rtc|conteo[10]~45\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[10]~45_combout\ = (\u_div_rtc|conteo\(10) & (\u_div_rtc|conteo[9]~44\ $ (GND))) # (!\u_div_rtc|conteo\(10) & (!\u_div_rtc|conteo[9]~44\ & VCC))
-- \u_div_rtc|conteo[10]~46\ = CARRY((\u_div_rtc|conteo\(10) & !\u_div_rtc|conteo[9]~44\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(10),
	datad => VCC,
	cin => \u_div_rtc|conteo[9]~44\,
	combout => \u_div_rtc|conteo[10]~45_combout\,
	cout => \u_div_rtc|conteo[10]~46\);

-- Location: FF_X2_Y28_N29
\u_div_rtc|conteo[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[10]~45_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(10));

-- Location: LCCOMB_X2_Y28_N30
\u_div_rtc|conteo[11]~47\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[11]~47_combout\ = (\u_div_rtc|conteo\(11) & (!\u_div_rtc|conteo[10]~46\)) # (!\u_div_rtc|conteo\(11) & ((\u_div_rtc|conteo[10]~46\) # (GND)))
-- \u_div_rtc|conteo[11]~48\ = CARRY((!\u_div_rtc|conteo[10]~46\) # (!\u_div_rtc|conteo\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(11),
	datad => VCC,
	cin => \u_div_rtc|conteo[10]~46\,
	combout => \u_div_rtc|conteo[11]~47_combout\,
	cout => \u_div_rtc|conteo[11]~48\);

-- Location: FF_X2_Y28_N31
\u_div_rtc|conteo[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[11]~47_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(11));

-- Location: LCCOMB_X2_Y27_N0
\u_div_rtc|conteo[12]~49\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[12]~49_combout\ = (\u_div_rtc|conteo\(12) & (\u_div_rtc|conteo[11]~48\ $ (GND))) # (!\u_div_rtc|conteo\(12) & (!\u_div_rtc|conteo[11]~48\ & VCC))
-- \u_div_rtc|conteo[12]~50\ = CARRY((\u_div_rtc|conteo\(12) & !\u_div_rtc|conteo[11]~48\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(12),
	datad => VCC,
	cin => \u_div_rtc|conteo[11]~48\,
	combout => \u_div_rtc|conteo[12]~49_combout\,
	cout => \u_div_rtc|conteo[12]~50\);

-- Location: FF_X2_Y27_N1
\u_div_rtc|conteo[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[12]~49_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(12));

-- Location: LCCOMB_X2_Y27_N2
\u_div_rtc|conteo[13]~51\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[13]~51_combout\ = (\u_div_rtc|conteo\(13) & (!\u_div_rtc|conteo[12]~50\)) # (!\u_div_rtc|conteo\(13) & ((\u_div_rtc|conteo[12]~50\) # (GND)))
-- \u_div_rtc|conteo[13]~52\ = CARRY((!\u_div_rtc|conteo[12]~50\) # (!\u_div_rtc|conteo\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(13),
	datad => VCC,
	cin => \u_div_rtc|conteo[12]~50\,
	combout => \u_div_rtc|conteo[13]~51_combout\,
	cout => \u_div_rtc|conteo[13]~52\);

-- Location: FF_X2_Y27_N3
\u_div_rtc|conteo[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[13]~51_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(13));

-- Location: LCCOMB_X2_Y27_N4
\u_div_rtc|conteo[14]~53\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[14]~53_combout\ = (\u_div_rtc|conteo\(14) & (\u_div_rtc|conteo[13]~52\ $ (GND))) # (!\u_div_rtc|conteo\(14) & (!\u_div_rtc|conteo[13]~52\ & VCC))
-- \u_div_rtc|conteo[14]~54\ = CARRY((\u_div_rtc|conteo\(14) & !\u_div_rtc|conteo[13]~52\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(14),
	datad => VCC,
	cin => \u_div_rtc|conteo[13]~52\,
	combout => \u_div_rtc|conteo[14]~53_combout\,
	cout => \u_div_rtc|conteo[14]~54\);

-- Location: FF_X2_Y27_N5
\u_div_rtc|conteo[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[14]~53_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(14));

-- Location: LCCOMB_X2_Y27_N6
\u_div_rtc|conteo[15]~55\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[15]~55_combout\ = (\u_div_rtc|conteo\(15) & (!\u_div_rtc|conteo[14]~54\)) # (!\u_div_rtc|conteo\(15) & ((\u_div_rtc|conteo[14]~54\) # (GND)))
-- \u_div_rtc|conteo[15]~56\ = CARRY((!\u_div_rtc|conteo[14]~54\) # (!\u_div_rtc|conteo\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(15),
	datad => VCC,
	cin => \u_div_rtc|conteo[14]~54\,
	combout => \u_div_rtc|conteo[15]~55_combout\,
	cout => \u_div_rtc|conteo[15]~56\);

-- Location: FF_X2_Y27_N7
\u_div_rtc|conteo[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[15]~55_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(15));

-- Location: LCCOMB_X2_Y27_N8
\u_div_rtc|conteo[16]~57\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[16]~57_combout\ = (\u_div_rtc|conteo\(16) & (\u_div_rtc|conteo[15]~56\ $ (GND))) # (!\u_div_rtc|conteo\(16) & (!\u_div_rtc|conteo[15]~56\ & VCC))
-- \u_div_rtc|conteo[16]~58\ = CARRY((\u_div_rtc|conteo\(16) & !\u_div_rtc|conteo[15]~56\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(16),
	datad => VCC,
	cin => \u_div_rtc|conteo[15]~56\,
	combout => \u_div_rtc|conteo[16]~57_combout\,
	cout => \u_div_rtc|conteo[16]~58\);

-- Location: FF_X2_Y27_N9
\u_div_rtc|conteo[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[16]~57_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(16));

-- Location: LCCOMB_X2_Y27_N10
\u_div_rtc|conteo[17]~59\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[17]~59_combout\ = (\u_div_rtc|conteo\(17) & (!\u_div_rtc|conteo[16]~58\)) # (!\u_div_rtc|conteo\(17) & ((\u_div_rtc|conteo[16]~58\) # (GND)))
-- \u_div_rtc|conteo[17]~60\ = CARRY((!\u_div_rtc|conteo[16]~58\) # (!\u_div_rtc|conteo\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(17),
	datad => VCC,
	cin => \u_div_rtc|conteo[16]~58\,
	combout => \u_div_rtc|conteo[17]~59_combout\,
	cout => \u_div_rtc|conteo[17]~60\);

-- Location: FF_X2_Y27_N11
\u_div_rtc|conteo[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[17]~59_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(17));

-- Location: LCCOMB_X2_Y27_N12
\u_div_rtc|conteo[18]~61\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[18]~61_combout\ = (\u_div_rtc|conteo\(18) & (\u_div_rtc|conteo[17]~60\ $ (GND))) # (!\u_div_rtc|conteo\(18) & (!\u_div_rtc|conteo[17]~60\ & VCC))
-- \u_div_rtc|conteo[18]~62\ = CARRY((\u_div_rtc|conteo\(18) & !\u_div_rtc|conteo[17]~60\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(18),
	datad => VCC,
	cin => \u_div_rtc|conteo[17]~60\,
	combout => \u_div_rtc|conteo[18]~61_combout\,
	cout => \u_div_rtc|conteo[18]~62\);

-- Location: FF_X2_Y27_N13
\u_div_rtc|conteo[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[18]~61_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(18));

-- Location: LCCOMB_X2_Y27_N14
\u_div_rtc|conteo[19]~63\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[19]~63_combout\ = (\u_div_rtc|conteo\(19) & (!\u_div_rtc|conteo[18]~62\)) # (!\u_div_rtc|conteo\(19) & ((\u_div_rtc|conteo[18]~62\) # (GND)))
-- \u_div_rtc|conteo[19]~64\ = CARRY((!\u_div_rtc|conteo[18]~62\) # (!\u_div_rtc|conteo\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(19),
	datad => VCC,
	cin => \u_div_rtc|conteo[18]~62\,
	combout => \u_div_rtc|conteo[19]~63_combout\,
	cout => \u_div_rtc|conteo[19]~64\);

-- Location: FF_X2_Y27_N15
\u_div_rtc|conteo[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[19]~63_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(19));

-- Location: LCCOMB_X2_Y27_N16
\u_div_rtc|conteo[20]~65\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[20]~65_combout\ = (\u_div_rtc|conteo\(20) & (\u_div_rtc|conteo[19]~64\ $ (GND))) # (!\u_div_rtc|conteo\(20) & (!\u_div_rtc|conteo[19]~64\ & VCC))
-- \u_div_rtc|conteo[20]~66\ = CARRY((\u_div_rtc|conteo\(20) & !\u_div_rtc|conteo[19]~64\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(20),
	datad => VCC,
	cin => \u_div_rtc|conteo[19]~64\,
	combout => \u_div_rtc|conteo[20]~65_combout\,
	cout => \u_div_rtc|conteo[20]~66\);

-- Location: FF_X2_Y27_N17
\u_div_rtc|conteo[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[20]~65_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(20));

-- Location: LCCOMB_X2_Y27_N18
\u_div_rtc|conteo[21]~67\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[21]~67_combout\ = (\u_div_rtc|conteo\(21) & (!\u_div_rtc|conteo[20]~66\)) # (!\u_div_rtc|conteo\(21) & ((\u_div_rtc|conteo[20]~66\) # (GND)))
-- \u_div_rtc|conteo[21]~68\ = CARRY((!\u_div_rtc|conteo[20]~66\) # (!\u_div_rtc|conteo\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(21),
	datad => VCC,
	cin => \u_div_rtc|conteo[20]~66\,
	combout => \u_div_rtc|conteo[21]~67_combout\,
	cout => \u_div_rtc|conteo[21]~68\);

-- Location: FF_X2_Y27_N19
\u_div_rtc|conteo[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[21]~67_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(21));

-- Location: LCCOMB_X2_Y27_N20
\u_div_rtc|conteo[22]~69\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[22]~69_combout\ = (\u_div_rtc|conteo\(22) & (\u_div_rtc|conteo[21]~68\ $ (GND))) # (!\u_div_rtc|conteo\(22) & (!\u_div_rtc|conteo[21]~68\ & VCC))
-- \u_div_rtc|conteo[22]~70\ = CARRY((\u_div_rtc|conteo\(22) & !\u_div_rtc|conteo[21]~68\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(22),
	datad => VCC,
	cin => \u_div_rtc|conteo[21]~68\,
	combout => \u_div_rtc|conteo[22]~69_combout\,
	cout => \u_div_rtc|conteo[22]~70\);

-- Location: FF_X2_Y27_N21
\u_div_rtc|conteo[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[22]~69_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(22));

-- Location: LCCOMB_X2_Y27_N22
\u_div_rtc|conteo[23]~71\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[23]~71_combout\ = (\u_div_rtc|conteo\(23) & (!\u_div_rtc|conteo[22]~70\)) # (!\u_div_rtc|conteo\(23) & ((\u_div_rtc|conteo[22]~70\) # (GND)))
-- \u_div_rtc|conteo[23]~72\ = CARRY((!\u_div_rtc|conteo[22]~70\) # (!\u_div_rtc|conteo\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(23),
	datad => VCC,
	cin => \u_div_rtc|conteo[22]~70\,
	combout => \u_div_rtc|conteo[23]~71_combout\,
	cout => \u_div_rtc|conteo[23]~72\);

-- Location: FF_X2_Y27_N23
\u_div_rtc|conteo[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[23]~71_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(23));

-- Location: LCCOMB_X2_Y27_N24
\u_div_rtc|conteo[24]~73\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|conteo[24]~73_combout\ = \u_div_rtc|conteo[23]~72\ $ (!\u_div_rtc|conteo\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u_div_rtc|conteo\(24),
	cin => \u_div_rtc|conteo[23]~72\,
	combout => \u_div_rtc|conteo[24]~73_combout\);

-- Location: FF_X2_Y27_N25
\u_div_rtc|conteo[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|conteo[24]~73_combout\,
	clrn => \rst~input_o\,
	sclr => \u_div_rtc|ALT_INV_LessThan0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|conteo\(24));

-- Location: LCCOMB_X2_Y27_N28
\u_div_rtc|LessThan0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~6_combout\ = (!\u_div_rtc|conteo\(21)) # (!\u_div_rtc|conteo\(20))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(20),
	datad => \u_div_rtc|conteo\(21),
	combout => \u_div_rtc|LessThan0~6_combout\);

-- Location: LCCOMB_X2_Y27_N30
\u_div_rtc|LessThan0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~7_combout\ = (((\u_div_rtc|LessThan0~6_combout\) # (!\u_div_rtc|conteo\(19))) # (!\u_div_rtc|conteo\(22))) # (!\u_div_rtc|conteo\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(18),
	datab => \u_div_rtc|conteo\(22),
	datac => \u_div_rtc|conteo\(19),
	datad => \u_div_rtc|LessThan0~6_combout\,
	combout => \u_div_rtc|LessThan0~7_combout\);

-- Location: LCCOMB_X2_Y28_N4
\u_div_rtc|LessThan0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~3_combout\ = (!\u_div_rtc|conteo\(7) & (!\u_div_rtc|conteo\(6) & (!\u_div_rtc|conteo\(9) & !\u_div_rtc|conteo\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(7),
	datab => \u_div_rtc|conteo\(6),
	datac => \u_div_rtc|conteo\(9),
	datad => \u_div_rtc|conteo\(8),
	combout => \u_div_rtc|LessThan0~3_combout\);

-- Location: LCCOMB_X2_Y27_N26
\u_div_rtc|LessThan0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~0_combout\ = (((!\u_div_rtc|conteo\(11)) # (!\u_div_rtc|conteo\(13))) # (!\u_div_rtc|conteo\(12))) # (!\u_div_rtc|conteo\(14))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(14),
	datab => \u_div_rtc|conteo\(12),
	datac => \u_div_rtc|conteo\(13),
	datad => \u_div_rtc|conteo\(11),
	combout => \u_div_rtc|LessThan0~0_combout\);

-- Location: LCCOMB_X3_Y28_N2
\u_div_rtc|LessThan0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~1_combout\ = (((!\u_div_rtc|conteo\(1)) # (!\u_div_rtc|conteo\(0))) # (!\u_div_rtc|conteo\(2))) # (!\u_div_rtc|conteo\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(3),
	datab => \u_div_rtc|conteo\(2),
	datac => \u_div_rtc|conteo\(0),
	datad => \u_div_rtc|conteo\(1),
	combout => \u_div_rtc|LessThan0~1_combout\);

-- Location: LCCOMB_X3_Y28_N4
\u_div_rtc|LessThan0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~2_combout\ = ((\u_div_rtc|LessThan0~1_combout\) # (!\u_div_rtc|conteo\(4))) # (!\u_div_rtc|conteo\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_div_rtc|conteo\(5),
	datac => \u_div_rtc|conteo\(4),
	datad => \u_div_rtc|LessThan0~1_combout\,
	combout => \u_div_rtc|LessThan0~2_combout\);

-- Location: LCCOMB_X2_Y28_N6
\u_div_rtc|LessThan0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~4_combout\ = (\u_div_rtc|LessThan0~0_combout\) # ((!\u_div_rtc|conteo\(10) & (\u_div_rtc|LessThan0~3_combout\ & \u_div_rtc|LessThan0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(10),
	datab => \u_div_rtc|LessThan0~3_combout\,
	datac => \u_div_rtc|LessThan0~0_combout\,
	datad => \u_div_rtc|LessThan0~2_combout\,
	combout => \u_div_rtc|LessThan0~4_combout\);

-- Location: LCCOMB_X2_Y28_N0
\u_div_rtc|LessThan0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~5_combout\ = (!\u_div_rtc|conteo\(17) & (((!\u_div_rtc|conteo\(15) & \u_div_rtc|LessThan0~4_combout\)) # (!\u_div_rtc|conteo\(16))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(15),
	datab => \u_div_rtc|conteo\(17),
	datac => \u_div_rtc|conteo\(16),
	datad => \u_div_rtc|LessThan0~4_combout\,
	combout => \u_div_rtc|LessThan0~5_combout\);

-- Location: LCCOMB_X2_Y28_N2
\u_div_rtc|LessThan0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|LessThan0~8_combout\ = ((!\u_div_rtc|conteo\(23) & ((\u_div_rtc|LessThan0~7_combout\) # (\u_div_rtc|LessThan0~5_combout\)))) # (!\u_div_rtc|conteo\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011101110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_div_rtc|conteo\(24),
	datab => \u_div_rtc|conteo\(23),
	datac => \u_div_rtc|LessThan0~7_combout\,
	datad => \u_div_rtc|LessThan0~5_combout\,
	combout => \u_div_rtc|LessThan0~8_combout\);

-- Location: LCCOMB_X3_Y28_N16
\u_div_rtc|estado~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_div_rtc|estado~0_combout\ = \u_div_rtc|estado~q\ $ (!\u_div_rtc|LessThan0~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_div_rtc|estado~q\,
	datad => \u_div_rtc|LessThan0~8_combout\,
	combout => \u_div_rtc|estado~0_combout\);

-- Location: FF_X3_Y28_N17
\u_div_rtc|estado\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_div_rtc|estado~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_div_rtc|estado~q\);

-- Location: LCCOMB_X3_Y25_N16
\u_gestor_rf5|paso1~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|paso1~feeder_combout\ = \u_div_rtc|estado~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_div_rtc|estado~q\,
	combout => \u_gestor_rf5|paso1~feeder_combout\);

-- Location: FF_X3_Y25_N17
\u_gestor_rf5|paso1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|paso1~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|paso1~q\);

-- Location: FF_X3_Y25_N7
\u_gestor_rf5|paso2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|paso1~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|paso2~q\);

-- Location: LCCOMB_X3_Y25_N6
\u_gestor_rf5|process_2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|process_2~0_combout\ = (!\u_gestor_rf5|paso2~q\ & (\u_gestor_rf5|paso1~q\ & ((!\Equal0~0_combout\) # (!\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[2]~input_o\,
	datab => \Equal0~0_combout\,
	datac => \u_gestor_rf5|paso2~q\,
	datad => \u_gestor_rf5|paso1~q\,
	combout => \u_gestor_rf5|process_2~0_combout\);

-- Location: LCCOMB_X4_Y24_N8
\u_gestor_rf5|timer[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|timer[0]~3_combout\ = (\hab_conteo~0_combout\) # ((\u_gestor_rf5|process_2~0_combout\ & (!\u_gestor_rf5|timer\(0) & \u_gestor_rf5|timer\(1))) # (!\u_gestor_rf5|process_2~0_combout\ & (\u_gestor_rf5|timer\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hab_conteo~0_combout\,
	datab => \u_gestor_rf5|process_2~0_combout\,
	datac => \u_gestor_rf5|timer\(0),
	datad => \u_gestor_rf5|timer\(1),
	combout => \u_gestor_rf5|timer[0]~3_combout\);

-- Location: FF_X4_Y24_N9
\u_gestor_rf5|timer[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|timer[0]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|timer\(0));

-- Location: LCCOMB_X3_Y23_N14
\u_gestor_rf5|timer[1]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|timer[1]~2_combout\ = (\hab_conteo~0_combout\) # ((\u_gestor_rf5|timer\(1) & ((\u_gestor_rf5|timer\(0)) # (!\u_gestor_rf5|process_2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hab_conteo~0_combout\,
	datab => \u_gestor_rf5|timer\(0),
	datac => \u_gestor_rf5|timer\(1),
	datad => \u_gestor_rf5|process_2~0_combout\,
	combout => \u_gestor_rf5|timer[1]~2_combout\);

-- Location: FF_X3_Y23_N15
\u_gestor_rf5|timer[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|timer[1]~2_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|timer\(1));

-- Location: FF_X3_Y23_N17
\u_gestor_rf5|color_activo[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \cod_color[1]~1_combout\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|color_activo\(0));

-- Location: LCCOMB_X4_Y23_N12
\bus_hex3[0]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[0]~0_combout\ = (!\u_gestor_rf5|color_activo\(0) & ((\u_gestor_rf5|timer\(1)) # (\u_gestor_rf5|timer\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|timer\(1),
	datab => \u_gestor_rf5|timer\(0),
	datad => \u_gestor_rf5|color_activo\(0),
	combout => \bus_hex3[0]~0_combout\);

-- Location: LCCOMB_X4_Y24_N2
\bus_hex1[2]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~0_combout\ = (!\u_gestor_rf5|timer\(1) & !\u_gestor_rf5|timer\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|timer\(1),
	datac => \u_gestor_rf5|timer\(0),
	combout => \bus_hex1[2]~0_combout\);

-- Location: LCCOMB_X4_Y23_N18
\bus_hex3[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[0]~1_combout\ = (\bus_hex1[2]~0_combout\ & ((\sw_menu[2]~input_o\ & ((\sw_menu[0]~input_o\) # (!\sw_menu[1]~input_o\))) # (!\sw_menu[2]~input_o\ & (!\sw_menu[1]~input_o\ & \sw_menu[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[2]~input_o\,
	datab => \sw_menu[1]~input_o\,
	datac => \bus_hex1[2]~0_combout\,
	datad => \sw_menu[0]~input_o\,
	combout => \bus_hex3[0]~1_combout\);

-- Location: LCCOMB_X4_Y23_N8
\bus_hex3[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[0]~2_combout\ = (\modo_cons~input_o\ & (((!\u_mem_rf4|salida_color[1]~3_combout\)))) # (!\modo_cons~input_o\ & ((\bus_hex3[0]~0_combout\) # ((\bus_hex3[0]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~0_combout\,
	datab => \modo_cons~input_o\,
	datac => \u_mem_rf4|salida_color[1]~3_combout\,
	datad => \bus_hex3[0]~1_combout\,
	combout => \bus_hex3[0]~2_combout\);

-- Location: LCCOMB_X3_Y23_N18
\u_gestor_rf5|color_activo[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|color_activo[1]~1_combout\ = !\u_gestor_rf5|Equal0~9_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_gestor_rf5|Equal0~9_combout\,
	combout => \u_gestor_rf5|color_activo[1]~1_combout\);

-- Location: FF_X3_Y23_N19
\u_gestor_rf5|color_activo[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|color_activo[1]~1_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|color_activo\(1));

-- Location: LCCOMB_X5_Y23_N24
\bus_hex2[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[3]~0_combout\ = (!\sw_menu[1]~input_o\ & \sw_menu[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datad => \sw_menu[2]~input_o\,
	combout => \bus_hex2[3]~0_combout\);

-- Location: LCCOMB_X5_Y23_N2
\bus_hex3[1]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[1]~3_combout\ = (\bus_hex1[2]~0_combout\ & ((\sw_menu[0]~input_o\) # ((\bus_hex2[3]~0_combout\)))) # (!\bus_hex1[2]~0_combout\ & (((!\u_gestor_rf5|color_activo\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~0_combout\,
	datab => \sw_menu[0]~input_o\,
	datac => \u_gestor_rf5|color_activo\(1),
	datad => \bus_hex2[3]~0_combout\,
	combout => \bus_hex3[1]~3_combout\);

-- Location: LCCOMB_X5_Y23_N28
\bus_hex3[1]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[1]~4_combout\ = (\modo_cons~input_o\ & ((\u_mem_rf4|salida_color[0]~1_combout\) # ((!\u_mem_rf4|salida_color[1]~3_combout\)))) # (!\modo_cons~input_o\ & (((\bus_hex3[1]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111110110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|salida_color[0]~1_combout\,
	datab => \u_mem_rf4|salida_color[1]~3_combout\,
	datac => \modo_cons~input_o\,
	datad => \bus_hex3[1]~3_combout\,
	combout => \bus_hex3[1]~4_combout\);

-- Location: FF_X3_Y23_N13
\u_gestor_rf5|color_activo[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|Equal0~9_combout\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|color_activo\(2));

-- Location: LCCOMB_X5_Y23_N0
\bus_hex3[2]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[2]~5_combout\ = (\bus_hex1[2]~0_combout\ & (\sw_menu[2]~input_o\ $ (((\Equal0~0_combout\))))) # (!\bus_hex1[2]~0_combout\ & (((!\u_gestor_rf5|color_activo\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010011110001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~0_combout\,
	datab => \sw_menu[2]~input_o\,
	datac => \u_gestor_rf5|color_activo\(2),
	datad => \Equal0~0_combout\,
	combout => \bus_hex3[2]~5_combout\);

-- Location: LCCOMB_X5_Y23_N26
\bus_hex3[2]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[2]~6_combout\ = (\modo_cons~input_o\ & (!\u_mem_rf4|salida_color[0]~1_combout\)) # (!\modo_cons~input_o\ & ((\bus_hex3[2]~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|salida_color[0]~1_combout\,
	datac => \modo_cons~input_o\,
	datad => \bus_hex3[2]~5_combout\,
	combout => \bus_hex3[2]~6_combout\);

-- Location: LCCOMB_X4_Y24_N0
\bus_hex1[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~1_combout\ = (!\u_gestor_rf5|timer\(1) & (!\sw_menu[0]~input_o\ & !\u_gestor_rf5|timer\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|timer\(1),
	datab => \sw_menu[0]~input_o\,
	datac => \u_gestor_rf5|timer\(0),
	combout => \bus_hex1[2]~1_combout\);

-- Location: LCCOMB_X5_Y23_N12
\bus_hex3[3]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex3[3]~7_combout\ = (\modo_cons~input_o\) # ((\sw_menu[2]~input_o\ $ (\sw_menu[1]~input_o\)) # (!\bus_hex1[2]~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \sw_menu[2]~input_o\,
	datac => \bus_hex1[2]~1_combout\,
	datad => \sw_menu[1]~input_o\,
	combout => \bus_hex3[3]~7_combout\);

-- Location: LCCOMB_X5_Y23_N14
\d3|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux6~0_combout\ = (\bus_hex3[2]~6_combout\ & ((\bus_hex3[0]~2_combout\ & (!\bus_hex3[1]~4_combout\)) # (!\bus_hex3[0]~2_combout\ & ((!\bus_hex3[3]~7_combout\))))) # (!\bus_hex3[2]~6_combout\ & (((\bus_hex3[1]~4_combout\) # (\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111101111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux6~0_combout\);

-- Location: LCCOMB_X5_Y23_N16
\d3|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux5~0_combout\ = (\bus_hex3[0]~2_combout\ & ((\bus_hex3[1]~4_combout\) # (\bus_hex3[2]~6_combout\ $ (!\bus_hex3[3]~7_combout\)))) # (!\bus_hex3[0]~2_combout\ & (\bus_hex3[1]~4_combout\ & (\bus_hex3[2]~6_combout\ $ (!\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100010001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux5~0_combout\);

-- Location: LCCOMB_X5_Y23_N10
\d3|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux4~0_combout\ = (\bus_hex3[0]~2_combout\ & (((\bus_hex3[2]~6_combout\) # (!\bus_hex3[3]~7_combout\)) # (!\bus_hex3[1]~4_combout\))) # (!\bus_hex3[0]~2_combout\ & (\bus_hex3[2]~6_combout\ & (\bus_hex3[1]~4_combout\ $ (!\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux4~0_combout\);

-- Location: LCCOMB_X5_Y23_N8
\d3|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux3~0_combout\ = (\bus_hex3[1]~4_combout\ & ((\bus_hex3[3]~7_combout\) # ((\bus_hex3[0]~2_combout\ & \bus_hex3[2]~6_combout\)))) # (!\bus_hex3[1]~4_combout\ & ((\bus_hex3[0]~2_combout\ & (\bus_hex3[2]~6_combout\ $ (!\bus_hex3[3]~7_combout\))) # 
-- (!\bus_hex3[0]~2_combout\ & (\bus_hex3[2]~6_combout\ & !\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux3~0_combout\);

-- Location: LCCOMB_X5_Y23_N18
\d3|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux2~0_combout\ = (\bus_hex3[0]~2_combout\ & (\bus_hex3[3]~7_combout\ & ((\bus_hex3[1]~4_combout\) # (\bus_hex3[2]~6_combout\)))) # (!\bus_hex3[0]~2_combout\ & (\bus_hex3[1]~4_combout\ & (\bus_hex3[2]~6_combout\ $ (!\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux2~0_combout\);

-- Location: LCCOMB_X5_Y23_N20
\d3|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux1~0_combout\ = (\bus_hex3[0]~2_combout\ & ((\bus_hex3[1]~4_combout\ & ((\bus_hex3[3]~7_combout\))) # (!\bus_hex3[1]~4_combout\ & (\bus_hex3[2]~6_combout\)))) # (!\bus_hex3[0]~2_combout\ & (\bus_hex3[2]~6_combout\ & ((\bus_hex3[1]~4_combout\) # 
-- (\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux1~0_combout\);

-- Location: LCCOMB_X5_Y23_N30
\d3|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d3|Mux0~0_combout\ = (\bus_hex3[0]~2_combout\ & (\bus_hex3[3]~7_combout\ $ (((!\bus_hex3[1]~4_combout\ & !\bus_hex3[2]~6_combout\))))) # (!\bus_hex3[0]~2_combout\ & (\bus_hex3[2]~6_combout\ & (\bus_hex3[1]~4_combout\ $ (!\bus_hex3[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex3[0]~2_combout\,
	datab => \bus_hex3[1]~4_combout\,
	datac => \bus_hex3[2]~6_combout\,
	datad => \bus_hex3[3]~7_combout\,
	combout => \d3|Mux0~0_combout\);

-- Location: LCCOMB_X3_Y25_N2
\bus_hex2[1]~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[1]~9_combout\ = (\sw_menu[2]~input_o\ & (\bus_hex1[2]~0_combout\ & (\sw_menu[0]~input_o\ $ (!\sw_menu[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[2]~input_o\,
	datab => \bus_hex1[2]~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \sw_menu[1]~input_o\,
	combout => \bus_hex2[1]~9_combout\);

-- Location: LCCOMB_X3_Y25_N8
\u_gestor_rf5|t_uni~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_uni~1_combout\ = (!\u_gestor_rf5|process_2~4_combout\ & (!\u_gestor_rf5|Equal6~0_combout\ & (\u_gestor_rf5|t_uni\(0) $ (\u_gestor_rf5|t_uni\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|process_2~4_combout\,
	datab => \u_gestor_rf5|t_uni\(0),
	datac => \u_gestor_rf5|t_uni\(1),
	datad => \u_gestor_rf5|Equal6~0_combout\,
	combout => \u_gestor_rf5|t_uni~1_combout\);

-- Location: FF_X3_Y25_N9
\u_gestor_rf5|t_uni[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_uni~1_combout\,
	clrn => \rst~input_o\,
	ena => \u_gestor_rf5|process_2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_uni\(1));

-- Location: LCCOMB_X1_Y25_N0
\u_gestor_rf5|Add3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Add3~0_combout\ = \u_gestor_rf5|t_uni\(2) $ (((\u_gestor_rf5|t_uni\(0) & \u_gestor_rf5|t_uni\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101001101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_uni\(2),
	datab => \u_gestor_rf5|t_uni\(0),
	datac => \u_gestor_rf5|t_uni\(1),
	combout => \u_gestor_rf5|Add3~0_combout\);

-- Location: LCCOMB_X1_Y25_N6
\u_gestor_rf5|t_uni~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_uni~2_combout\ = (\u_gestor_rf5|Add3~0_combout\ & (!\u_gestor_rf5|Equal6~0_combout\ & !\u_gestor_rf5|process_2~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|Add3~0_combout\,
	datac => \u_gestor_rf5|Equal6~0_combout\,
	datad => \u_gestor_rf5|process_2~4_combout\,
	combout => \u_gestor_rf5|t_uni~2_combout\);

-- Location: FF_X1_Y25_N7
\u_gestor_rf5|t_uni[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_uni~2_combout\,
	clrn => \rst~input_o\,
	ena => \u_gestor_rf5|process_2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_uni\(2));

-- Location: LCCOMB_X1_Y25_N30
\u_gestor_rf5|t_dec[1]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_dec[1]~3_combout\ = (\u_gestor_rf5|t_dec\(1) & (((!\u_gestor_rf5|t_dec\(0) & \u_gestor_rf5|t_dec[3]~0_combout\)) # (!\u_gestor_rf5|t_dec[3]~1_combout\))) # (!\u_gestor_rf5|t_dec\(1) & (((\u_gestor_rf5|t_dec\(0) & 
-- \u_gestor_rf5|t_dec[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111110001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec[3]~1_combout\,
	datab => \u_gestor_rf5|t_dec\(0),
	datac => \u_gestor_rf5|t_dec\(1),
	datad => \u_gestor_rf5|t_dec[3]~0_combout\,
	combout => \u_gestor_rf5|t_dec[1]~3_combout\);

-- Location: FF_X1_Y25_N31
\u_gestor_rf5|t_dec[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_dec[1]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_dec\(1));

-- Location: LCCOMB_X1_Y25_N26
\u_gestor_rf5|Add2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Add2~1_combout\ = \u_gestor_rf5|t_dec\(3) $ (((\u_gestor_rf5|t_dec\(2) & (\u_gestor_rf5|t_dec\(1) & \u_gestor_rf5|t_dec\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec\(2),
	datab => \u_gestor_rf5|t_dec\(3),
	datac => \u_gestor_rf5|t_dec\(1),
	datad => \u_gestor_rf5|t_dec\(0),
	combout => \u_gestor_rf5|Add2~1_combout\);

-- Location: LCCOMB_X1_Y25_N18
\u_gestor_rf5|t_dec[3]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_dec[3]~5_combout\ = (\u_gestor_rf5|Add2~1_combout\ & ((\u_gestor_rf5|t_dec[3]~0_combout\) # ((\u_gestor_rf5|t_dec\(3) & !\u_gestor_rf5|t_dec[3]~1_combout\)))) # (!\u_gestor_rf5|Add2~1_combout\ & (((\u_gestor_rf5|t_dec\(3) & 
-- !\u_gestor_rf5|t_dec[3]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|Add2~1_combout\,
	datab => \u_gestor_rf5|t_dec[3]~0_combout\,
	datac => \u_gestor_rf5|t_dec\(3),
	datad => \u_gestor_rf5|t_dec[3]~1_combout\,
	combout => \u_gestor_rf5|t_dec[3]~5_combout\);

-- Location: FF_X1_Y25_N19
\u_gestor_rf5|t_dec[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_dec[3]~5_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_dec\(3));

-- Location: LCCOMB_X1_Y25_N14
\u_gestor_rf5|Equal7~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Equal7~0_combout\ = (!\u_gestor_rf5|t_dec\(2) & (\u_gestor_rf5|t_dec\(3) & (!\u_gestor_rf5|t_dec\(1) & \u_gestor_rf5|t_dec\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec\(2),
	datab => \u_gestor_rf5|t_dec\(3),
	datac => \u_gestor_rf5|t_dec\(1),
	datad => \u_gestor_rf5|t_dec\(0),
	combout => \u_gestor_rf5|Equal7~0_combout\);

-- Location: LCCOMB_X1_Y25_N24
\u_gestor_rf5|t_dec[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_dec[3]~0_combout\ = (\u_gestor_rf5|Equal6~0_combout\ & (!\u_gestor_rf5|Equal7~0_combout\ & (\u_gestor_rf5|process_2~0_combout\ & !\u_gestor_rf5|process_2~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|Equal6~0_combout\,
	datab => \u_gestor_rf5|Equal7~0_combout\,
	datac => \u_gestor_rf5|process_2~0_combout\,
	datad => \u_gestor_rf5|process_2~4_combout\,
	combout => \u_gestor_rf5|t_dec[3]~0_combout\);

-- Location: LCCOMB_X1_Y25_N20
\u_gestor_rf5|t_dec[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_dec[0]~2_combout\ = (\u_gestor_rf5|t_dec\(0) & ((!\u_gestor_rf5|t_dec[3]~1_combout\))) # (!\u_gestor_rf5|t_dec\(0) & (\u_gestor_rf5|t_dec[3]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|t_dec[3]~0_combout\,
	datac => \u_gestor_rf5|t_dec\(0),
	datad => \u_gestor_rf5|t_dec[3]~1_combout\,
	combout => \u_gestor_rf5|t_dec[0]~2_combout\);

-- Location: FF_X1_Y25_N21
\u_gestor_rf5|t_dec[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_dec[0]~2_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_dec\(0));

-- Location: LCCOMB_X1_Y25_N22
\u_gestor_rf5|process_2~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|process_2~2_combout\ = (!\u_gestor_rf5|t_uni\(2) & (!\u_gestor_rf5|t_uni\(0) & (!\u_gestor_rf5|t_uni\(1) & !\u_gestor_rf5|t_dec\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_uni\(2),
	datab => \u_gestor_rf5|t_uni\(0),
	datac => \u_gestor_rf5|t_uni\(1),
	datad => \u_gestor_rf5|t_dec\(0),
	combout => \u_gestor_rf5|process_2~2_combout\);

-- Location: LCCOMB_X5_Y25_N20
\u_gestor_rf5|t_cen[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_cen[3]~0_combout\ = (\u_gestor_rf5|process_2~0_combout\ & ((\u_gestor_rf5|process_2~4_combout\) # ((\u_gestor_rf5|Equal7~0_combout\ & \u_gestor_rf5|Equal6~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|process_2~0_combout\,
	datab => \u_gestor_rf5|Equal7~0_combout\,
	datac => \u_gestor_rf5|process_2~4_combout\,
	datad => \u_gestor_rf5|Equal6~0_combout\,
	combout => \u_gestor_rf5|t_cen[3]~0_combout\);

-- Location: LCCOMB_X5_Y25_N4
\u_gestor_rf5|t_cen[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_cen[0]~1_combout\ = \u_gestor_rf5|t_cen\(0) $ (\u_gestor_rf5|t_cen[3]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_gestor_rf5|t_cen\(0),
	datad => \u_gestor_rf5|t_cen[3]~0_combout\,
	combout => \u_gestor_rf5|t_cen[0]~1_combout\);

-- Location: FF_X5_Y25_N5
\u_gestor_rf5|t_cen[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_cen[0]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_cen\(0));

-- Location: LCCOMB_X5_Y25_N30
\u_gestor_rf5|t_cen[2]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_cen[2]~4_combout\ = (\u_gestor_rf5|t_cen\(1) & \u_gestor_rf5|t_cen\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|t_cen\(1),
	datac => \u_gestor_rf5|t_cen\(0),
	combout => \u_gestor_rf5|t_cen[2]~4_combout\);

-- Location: LCCOMB_X5_Y25_N18
\u_gestor_rf5|t_cen[2]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_cen[2]~3_combout\ = \u_gestor_rf5|t_cen\(2) $ (((\u_gestor_rf5|t_cen\(1) & (\u_gestor_rf5|t_cen\(0) & \u_gestor_rf5|t_cen[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_cen\(1),
	datab => \u_gestor_rf5|t_cen\(0),
	datac => \u_gestor_rf5|t_cen\(2),
	datad => \u_gestor_rf5|t_cen[3]~0_combout\,
	combout => \u_gestor_rf5|t_cen[2]~3_combout\);

-- Location: FF_X5_Y25_N19
\u_gestor_rf5|t_cen[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_cen[2]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_cen\(2));

-- Location: LCCOMB_X5_Y25_N12
\u_gestor_rf5|t_cen[3]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_cen[3]~5_combout\ = \u_gestor_rf5|t_cen\(3) $ (((\u_gestor_rf5|t_cen[2]~4_combout\ & (\u_gestor_rf5|t_cen\(2) & \u_gestor_rf5|t_cen[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_cen[2]~4_combout\,
	datab => \u_gestor_rf5|t_cen\(2),
	datac => \u_gestor_rf5|t_cen\(3),
	datad => \u_gestor_rf5|t_cen[3]~0_combout\,
	combout => \u_gestor_rf5|t_cen[3]~5_combout\);

-- Location: FF_X5_Y25_N13
\u_gestor_rf5|t_cen[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_cen[3]~5_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_cen\(3));

-- Location: LCCOMB_X5_Y25_N22
\u_gestor_rf5|process_2~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|process_2~3_combout\ = (!\u_gestor_rf5|t_cen\(3) & (!\u_gestor_rf5|t_cen\(1) & (\u_gestor_rf5|t_cen\(0) & !\u_gestor_rf5|t_cen\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_cen\(3),
	datab => \u_gestor_rf5|t_cen\(1),
	datac => \u_gestor_rf5|t_cen\(0),
	datad => \u_gestor_rf5|t_cen\(2),
	combout => \u_gestor_rf5|process_2~3_combout\);

-- Location: LCCOMB_X1_Y25_N16
\u_gestor_rf5|t_uni~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_uni~0_combout\ = (!\u_gestor_rf5|t_uni\(0) & (((!\u_gestor_rf5|process_2~3_combout\) # (!\u_gestor_rf5|process_2~1_combout\)) # (!\u_gestor_rf5|process_2~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|process_2~2_combout\,
	datab => \u_gestor_rf5|process_2~1_combout\,
	datac => \u_gestor_rf5|t_uni\(0),
	datad => \u_gestor_rf5|process_2~3_combout\,
	combout => \u_gestor_rf5|t_uni~0_combout\);

-- Location: FF_X1_Y25_N17
\u_gestor_rf5|t_uni[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_uni~0_combout\,
	clrn => \rst~input_o\,
	ena => \u_gestor_rf5|process_2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_uni\(0));

-- Location: LCCOMB_X3_Y25_N26
\u_gestor_rf5|Add3~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Add3~1_combout\ = \u_gestor_rf5|t_uni\(3) $ (((\u_gestor_rf5|t_uni\(0) & (\u_gestor_rf5|t_uni\(2) & \u_gestor_rf5|t_uni\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_uni\(3),
	datab => \u_gestor_rf5|t_uni\(0),
	datac => \u_gestor_rf5|t_uni\(2),
	datad => \u_gestor_rf5|t_uni\(1),
	combout => \u_gestor_rf5|Add3~1_combout\);

-- Location: LCCOMB_X3_Y25_N10
\u_gestor_rf5|t_uni~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_uni~3_combout\ = (\u_gestor_rf5|Add3~1_combout\ & (!\u_gestor_rf5|process_2~4_combout\ & !\u_gestor_rf5|Equal6~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|Add3~1_combout\,
	datac => \u_gestor_rf5|process_2~4_combout\,
	datad => \u_gestor_rf5|Equal6~0_combout\,
	combout => \u_gestor_rf5|t_uni~3_combout\);

-- Location: FF_X3_Y25_N11
\u_gestor_rf5|t_uni[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_uni~3_combout\,
	clrn => \rst~input_o\,
	ena => \u_gestor_rf5|process_2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_uni\(3));

-- Location: LCCOMB_X3_Y25_N24
\u_gestor_rf5|Equal6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Equal6~0_combout\ = (\u_gestor_rf5|t_uni\(3) & (!\u_gestor_rf5|t_uni\(2) & (!\u_gestor_rf5|t_uni\(1) & \u_gestor_rf5|t_uni\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_uni\(3),
	datab => \u_gestor_rf5|t_uni\(2),
	datac => \u_gestor_rf5|t_uni\(1),
	datad => \u_gestor_rf5|t_uni\(0),
	combout => \u_gestor_rf5|Equal6~0_combout\);

-- Location: LCCOMB_X1_Y25_N10
\u_gestor_rf5|t_dec[3]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_dec[3]~1_combout\ = (\u_gestor_rf5|process_2~0_combout\ & ((\u_gestor_rf5|Equal6~0_combout\) # (\u_gestor_rf5|process_2~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|Equal6~0_combout\,
	datac => \u_gestor_rf5|process_2~0_combout\,
	datad => \u_gestor_rf5|process_2~4_combout\,
	combout => \u_gestor_rf5|t_dec[3]~1_combout\);

-- Location: LCCOMB_X1_Y25_N8
\u_gestor_rf5|Add2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|Add2~0_combout\ = \u_gestor_rf5|t_dec\(2) $ (((\u_gestor_rf5|t_dec\(1) & \u_gestor_rf5|t_dec\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec\(2),
	datac => \u_gestor_rf5|t_dec\(1),
	datad => \u_gestor_rf5|t_dec\(0),
	combout => \u_gestor_rf5|Add2~0_combout\);

-- Location: LCCOMB_X1_Y25_N12
\u_gestor_rf5|t_dec[2]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_dec[2]~4_combout\ = (\u_gestor_rf5|t_dec[3]~1_combout\ & (\u_gestor_rf5|Add2~0_combout\ & ((\u_gestor_rf5|t_dec[3]~0_combout\)))) # (!\u_gestor_rf5|t_dec[3]~1_combout\ & ((\u_gestor_rf5|t_dec\(2)) # ((\u_gestor_rf5|Add2~0_combout\ & 
-- \u_gestor_rf5|t_dec[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec[3]~1_combout\,
	datab => \u_gestor_rf5|Add2~0_combout\,
	datac => \u_gestor_rf5|t_dec\(2),
	datad => \u_gestor_rf5|t_dec[3]~0_combout\,
	combout => \u_gestor_rf5|t_dec[2]~4_combout\);

-- Location: FF_X1_Y25_N13
\u_gestor_rf5|t_dec[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_dec[2]~4_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_dec\(2));

-- Location: LCCOMB_X1_Y25_N4
\u_gestor_rf5|process_2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|process_2~1_combout\ = (!\u_gestor_rf5|t_dec\(2) & (\u_gestor_rf5|t_dec\(3) & (!\u_gestor_rf5|t_dec\(1) & !\u_gestor_rf5|t_uni\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec\(2),
	datab => \u_gestor_rf5|t_dec\(3),
	datac => \u_gestor_rf5|t_dec\(1),
	datad => \u_gestor_rf5|t_uni\(3),
	combout => \u_gestor_rf5|process_2~1_combout\);

-- Location: LCCOMB_X1_Y25_N28
\u_gestor_rf5|process_2~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|process_2~4_combout\ = (\u_gestor_rf5|process_2~1_combout\ & (\u_gestor_rf5|process_2~2_combout\ & \u_gestor_rf5|process_2~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|process_2~1_combout\,
	datac => \u_gestor_rf5|process_2~2_combout\,
	datad => \u_gestor_rf5|process_2~3_combout\,
	combout => \u_gestor_rf5|process_2~4_combout\);

-- Location: LCCOMB_X5_Y25_N28
\u_gestor_rf5|t_cen[1]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|t_cen[1]~2_combout\ = (\u_gestor_rf5|t_cen[3]~0_combout\ & (!\u_gestor_rf5|process_2~4_combout\ & (\u_gestor_rf5|t_cen\(0) $ (\u_gestor_rf5|t_cen\(1))))) # (!\u_gestor_rf5|t_cen[3]~0_combout\ & (((\u_gestor_rf5|t_cen\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|process_2~4_combout\,
	datab => \u_gestor_rf5|t_cen\(0),
	datac => \u_gestor_rf5|t_cen\(1),
	datad => \u_gestor_rf5|t_cen[3]~0_combout\,
	combout => \u_gestor_rf5|t_cen[1]~2_combout\);

-- Location: FF_X5_Y25_N29
\u_gestor_rf5|t_cen[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_gestor_rf5|t_cen[1]~2_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_gestor_rf5|t_cen\(1));

-- Location: LCCOMB_X4_Y25_N16
\u_mem_rf4|registros[0][9]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[0][9]~feeder_combout\ = \u_gestor_rf5|t_cen\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_gestor_rf5|t_cen\(1),
	combout => \u_mem_rf4|registros[0][9]~feeder_combout\);

-- Location: FF_X4_Y25_N17
\u_mem_rf4|registros[0][9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[0][9]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][9]~q\);

-- Location: LCCOMB_X2_Y25_N6
\u_mem_rf4|registros[1][9]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][9]~feeder_combout\ = \u_mem_rf4|registros[0][9]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][9]~q\,
	combout => \u_mem_rf4|registros[1][9]~feeder_combout\);

-- Location: FF_X2_Y25_N7
\u_mem_rf4|registros[1][9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][9]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][9]~q\);

-- Location: LCCOMB_X2_Y25_N4
\u_mem_rf4|registros[2][9]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][9]~feeder_combout\ = \u_mem_rf4|registros[1][9]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][9]~q\,
	combout => \u_mem_rf4|registros[2][9]~feeder_combout\);

-- Location: FF_X2_Y25_N5
\u_mem_rf4|registros[2][9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][9]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][9]~q\);

-- Location: LCCOMB_X2_Y25_N10
\bus_hex2[1]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[1]~6_combout\ = (\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\) # ((\u_mem_rf4|registros[2][9]~q\)))) # (!\sel_memoria[1]~input_o\ & (!\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[0][9]~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[2][9]~q\,
	datad => \u_mem_rf4|registros[0][9]~q\,
	combout => \bus_hex2[1]~6_combout\);

-- Location: FF_X2_Y25_N17
\u_mem_rf4|registros[3][9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][9]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][9]~q\);

-- Location: LCCOMB_X2_Y25_N16
\bus_hex2[1]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[1]~7_combout\ = (\bus_hex2[1]~6_combout\ & (((\u_mem_rf4|registros[3][9]~q\)) # (!\sel_memoria[0]~input_o\))) # (!\bus_hex2[1]~6_combout\ & (\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[1][9]~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011010100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~6_combout\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[3][9]~q\,
	datad => \u_mem_rf4|registros[1][9]~q\,
	combout => \bus_hex2[1]~7_combout\);

-- Location: LCCOMB_X5_Y25_N10
\bus_hex2[1]~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[1]~8_combout\ = (\bus_hex2[3]~0_combout\ & (\bus_hex1[2]~0_combout\ & (\sw_menu[0]~input_o\ & \u_gestor_rf5|t_cen\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[3]~0_combout\,
	datab => \bus_hex1[2]~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \u_gestor_rf5|t_cen\(1),
	combout => \bus_hex2[1]~8_combout\);

-- Location: LCCOMB_X5_Y25_N24
\bus_hex2[1]~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[1]~10_combout\ = (\modo_cons~input_o\ & (((\bus_hex2[1]~7_combout\)))) # (!\modo_cons~input_o\ & ((\bus_hex2[1]~9_combout\) # ((\bus_hex2[1]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \bus_hex2[1]~9_combout\,
	datac => \bus_hex2[1]~7_combout\,
	datad => \bus_hex2[1]~8_combout\,
	combout => \bus_hex2[1]~10_combout\);

-- Location: LCCOMB_X5_Y25_N16
\bus_hex2[2]~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[2]~11_combout\ = (((\u_gestor_rf5|t_cen\(2)) # (!\sw_menu[0]~input_o\)) # (!\bus_hex1[2]~0_combout\)) # (!\bus_hex2[3]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[3]~0_combout\,
	datab => \bus_hex1[2]~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \u_gestor_rf5|t_cen\(2),
	combout => \bus_hex2[2]~11_combout\);

-- Location: LCCOMB_X4_Y25_N2
\u_mem_rf4|registros[0][10]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[0][10]~feeder_combout\ = \u_gestor_rf5|t_cen\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_gestor_rf5|t_cen\(2),
	combout => \u_mem_rf4|registros[0][10]~feeder_combout\);

-- Location: FF_X4_Y25_N3
\u_mem_rf4|registros[0][10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[0][10]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][10]~q\);

-- Location: LCCOMB_X4_Y25_N18
\u_mem_rf4|registros[1][10]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][10]~feeder_combout\ = \u_mem_rf4|registros[0][10]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][10]~q\,
	combout => \u_mem_rf4|registros[1][10]~feeder_combout\);

-- Location: FF_X4_Y25_N19
\u_mem_rf4|registros[1][10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][10]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][10]~q\);

-- Location: LCCOMB_X4_Y25_N8
\u_mem_rf4|registros[2][10]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][10]~feeder_combout\ = \u_mem_rf4|registros[1][10]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][10]~q\,
	combout => \u_mem_rf4|registros[2][10]~feeder_combout\);

-- Location: FF_X4_Y25_N9
\u_mem_rf4|registros[2][10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][10]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][10]~q\);

-- Location: FF_X4_Y25_N1
\u_mem_rf4|registros[3][10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][10]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][10]~q\);

-- Location: LCCOMB_X4_Y25_N28
\bus_hex2[2]~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[2]~12_combout\ = (\sel_memoria[1]~input_o\ & (((\sel_memoria[0]~input_o\)))) # (!\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[1][10]~q\))) # (!\sel_memoria[0]~input_o\ & (\u_mem_rf4|registros[0][10]~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \u_mem_rf4|registros[0][10]~q\,
	datac => \sel_memoria[0]~input_o\,
	datad => \u_mem_rf4|registros[1][10]~q\,
	combout => \bus_hex2[2]~12_combout\);

-- Location: LCCOMB_X4_Y25_N0
\bus_hex2[2]~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[2]~13_combout\ = (\sel_memoria[1]~input_o\ & ((\bus_hex2[2]~12_combout\ & ((\u_mem_rf4|registros[3][10]~q\))) # (!\bus_hex2[2]~12_combout\ & (\u_mem_rf4|registros[2][10]~q\)))) # (!\sel_memoria[1]~input_o\ & (((\bus_hex2[2]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \u_mem_rf4|registros[2][10]~q\,
	datac => \u_mem_rf4|registros[3][10]~q\,
	datad => \bus_hex2[2]~12_combout\,
	combout => \bus_hex2[2]~13_combout\);

-- Location: LCCOMB_X5_Y25_N0
\bus_hex2[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[0]~2_combout\ = (!\modo_cons~input_o\ & ((\sw_menu[2]~input_o\ $ (\sw_menu[1]~input_o\)) # (!\bus_hex1[2]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \sw_menu[2]~input_o\,
	datac => \sw_menu[1]~input_o\,
	datad => \bus_hex1[2]~1_combout\,
	combout => \bus_hex2[0]~2_combout\);

-- Location: LCCOMB_X5_Y25_N14
\bus_hex2[2]~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[2]~14_combout\ = (\modo_cons~input_o\ & ((\bus_hex2[2]~13_combout\) # ((\bus_hex2[2]~11_combout\ & \bus_hex2[0]~2_combout\)))) # (!\modo_cons~input_o\ & (\bus_hex2[2]~11_combout\ & ((\bus_hex2[0]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \bus_hex2[2]~11_combout\,
	datac => \bus_hex2[2]~13_combout\,
	datad => \bus_hex2[0]~2_combout\,
	combout => \bus_hex2[2]~14_combout\);

-- Location: LCCOMB_X4_Y25_N24
\u_mem_rf4|registros[0][8]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[0][8]~feeder_combout\ = \u_gestor_rf5|t_cen\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_gestor_rf5|t_cen\(0),
	combout => \u_mem_rf4|registros[0][8]~feeder_combout\);

-- Location: FF_X4_Y25_N25
\u_mem_rf4|registros[0][8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[0][8]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][8]~q\);

-- Location: LCCOMB_X4_Y25_N4
\u_mem_rf4|registros[1][8]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][8]~feeder_combout\ = \u_mem_rf4|registros[0][8]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][8]~q\,
	combout => \u_mem_rf4|registros[1][8]~feeder_combout\);

-- Location: FF_X4_Y25_N5
\u_mem_rf4|registros[1][8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][8]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][8]~q\);

-- Location: FF_X4_Y25_N23
\u_mem_rf4|registros[2][8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[1][8]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][8]~q\);

-- Location: FF_X4_Y25_N15
\u_mem_rf4|registros[3][8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][8]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][8]~q\);

-- Location: LCCOMB_X4_Y25_N20
\bus_hex2[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[0]~3_combout\ = (\sel_memoria[1]~input_o\ & (\sel_memoria[0]~input_o\)) # (!\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\ & (\u_mem_rf4|registros[1][8]~q\)) # (!\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[0][8]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[1][8]~q\,
	datad => \u_mem_rf4|registros[0][8]~q\,
	combout => \bus_hex2[0]~3_combout\);

-- Location: LCCOMB_X4_Y25_N14
\bus_hex2[0]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[0]~4_combout\ = (\sel_memoria[1]~input_o\ & ((\bus_hex2[0]~3_combout\ & ((\u_mem_rf4|registros[3][8]~q\))) # (!\bus_hex2[0]~3_combout\ & (\u_mem_rf4|registros[2][8]~q\)))) # (!\sel_memoria[1]~input_o\ & (((\bus_hex2[0]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][8]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[3][8]~q\,
	datad => \bus_hex2[0]~3_combout\,
	combout => \bus_hex2[0]~4_combout\);

-- Location: LCCOMB_X5_Y25_N26
\bus_hex2[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[0]~1_combout\ = (((\u_gestor_rf5|t_cen\(0)) # (!\bus_hex1[2]~0_combout\)) # (!\sw_menu[0]~input_o\)) # (!\bus_hex2[3]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[3]~0_combout\,
	datab => \sw_menu[0]~input_o\,
	datac => \u_gestor_rf5|t_cen\(0),
	datad => \bus_hex1[2]~0_combout\,
	combout => \bus_hex2[0]~1_combout\);

-- Location: LCCOMB_X5_Y25_N6
\bus_hex2[0]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[0]~5_combout\ = (\bus_hex2[0]~4_combout\ & ((\modo_cons~input_o\) # ((\bus_hex2[0]~2_combout\ & \bus_hex2[0]~1_combout\)))) # (!\bus_hex2[0]~4_combout\ & (\bus_hex2[0]~2_combout\ & (\bus_hex2[0]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[0]~4_combout\,
	datab => \bus_hex2[0]~2_combout\,
	datac => \bus_hex2[0]~1_combout\,
	datad => \modo_cons~input_o\,
	combout => \bus_hex2[0]~5_combout\);

-- Location: LCCOMB_X5_Y25_N2
\bus_hex2[3]~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[3]~15_combout\ = (\u_gestor_rf5|t_cen\(3)) # (((!\bus_hex2[3]~0_combout\) # (!\sw_menu[0]~input_o\)) # (!\bus_hex1[2]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_cen\(3),
	datab => \bus_hex1[2]~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \bus_hex2[3]~0_combout\,
	combout => \bus_hex2[3]~15_combout\);

-- Location: FF_X2_Y25_N25
\u_mem_rf4|registros[0][11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_cen\(3),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][11]~q\);

-- Location: FF_X2_Y25_N1
\u_mem_rf4|registros[1][11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[0][11]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][11]~q\);

-- Location: LCCOMB_X2_Y25_N26
\u_mem_rf4|registros[2][11]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][11]~feeder_combout\ = \u_mem_rf4|registros[1][11]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][11]~q\,
	combout => \u_mem_rf4|registros[2][11]~feeder_combout\);

-- Location: FF_X2_Y25_N27
\u_mem_rf4|registros[2][11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][11]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][11]~q\);

-- Location: LCCOMB_X2_Y25_N24
\bus_hex2[3]~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[3]~16_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\ & (\u_mem_rf4|registros[2][11]~q\)) # (!\sel_memoria[1]~input_o\ & ((\u_mem_rf4|registros[0][11]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][11]~q\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[0][11]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \bus_hex2[3]~16_combout\);

-- Location: FF_X2_Y25_N21
\u_mem_rf4|registros[3][11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][11]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][11]~q\);

-- Location: LCCOMB_X2_Y25_N20
\bus_hex2[3]~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[3]~17_combout\ = (\sel_memoria[0]~input_o\ & ((\bus_hex2[3]~16_combout\ & (\u_mem_rf4|registros[3][11]~q\)) # (!\bus_hex2[3]~16_combout\ & ((\u_mem_rf4|registros[1][11]~q\))))) # (!\sel_memoria[0]~input_o\ & (\bus_hex2[3]~16_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \bus_hex2[3]~16_combout\,
	datac => \u_mem_rf4|registros[3][11]~q\,
	datad => \u_mem_rf4|registros[1][11]~q\,
	combout => \bus_hex2[3]~17_combout\);

-- Location: LCCOMB_X5_Y25_N8
\bus_hex2[3]~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex2[3]~18_combout\ = (\modo_cons~input_o\ & ((\bus_hex2[3]~17_combout\) # ((\bus_hex2[3]~15_combout\ & \bus_hex2[0]~2_combout\)))) # (!\modo_cons~input_o\ & (\bus_hex2[3]~15_combout\ & ((\bus_hex2[0]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \bus_hex2[3]~15_combout\,
	datac => \bus_hex2[3]~17_combout\,
	datad => \bus_hex2[0]~2_combout\,
	combout => \bus_hex2[3]~18_combout\);

-- Location: LCCOMB_X29_Y28_N20
\d2|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux6~0_combout\ = (\bus_hex2[2]~14_combout\ & ((\bus_hex2[0]~5_combout\ & (!\bus_hex2[1]~10_combout\)) # (!\bus_hex2[0]~5_combout\ & ((!\bus_hex2[3]~18_combout\))))) # (!\bus_hex2[2]~14_combout\ & ((\bus_hex2[1]~10_combout\) # 
-- ((\bus_hex2[3]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111001101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux6~0_combout\);

-- Location: LCCOMB_X29_Y28_N22
\d2|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux5~0_combout\ = (\bus_hex2[1]~10_combout\ & ((\bus_hex2[0]~5_combout\) # (\bus_hex2[2]~14_combout\ $ (!\bus_hex2[3]~18_combout\)))) # (!\bus_hex2[1]~10_combout\ & (\bus_hex2[0]~5_combout\ & (\bus_hex2[2]~14_combout\ $ (!\bus_hex2[3]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100010110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux5~0_combout\);

-- Location: LCCOMB_X29_Y28_N16
\d2|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux4~0_combout\ = (\bus_hex2[1]~10_combout\ & ((\bus_hex2[3]~18_combout\ & (\bus_hex2[2]~14_combout\)) # (!\bus_hex2[3]~18_combout\ & ((\bus_hex2[0]~5_combout\))))) # (!\bus_hex2[1]~10_combout\ & ((\bus_hex2[0]~5_combout\) # ((\bus_hex2[2]~14_combout\ 
-- & !\bus_hex2[3]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux4~0_combout\);

-- Location: LCCOMB_X29_Y28_N6
\d2|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux3~0_combout\ = (\bus_hex2[1]~10_combout\ & ((\bus_hex2[3]~18_combout\) # ((\bus_hex2[2]~14_combout\ & \bus_hex2[0]~5_combout\)))) # (!\bus_hex2[1]~10_combout\ & ((\bus_hex2[2]~14_combout\ & (\bus_hex2[0]~5_combout\ $ (!\bus_hex2[3]~18_combout\))) # 
-- (!\bus_hex2[2]~14_combout\ & (\bus_hex2[0]~5_combout\ & !\bus_hex2[3]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux3~0_combout\);

-- Location: LCCOMB_X29_Y28_N0
\d2|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux2~0_combout\ = (\bus_hex2[1]~10_combout\ & (\bus_hex2[3]~18_combout\ $ (((!\bus_hex2[2]~14_combout\ & !\bus_hex2[0]~5_combout\))))) # (!\bus_hex2[1]~10_combout\ & (\bus_hex2[2]~14_combout\ & (\bus_hex2[0]~5_combout\ & \bus_hex2[3]~18_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux2~0_combout\);

-- Location: LCCOMB_X29_Y28_N10
\d2|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux1~0_combout\ = (\bus_hex2[1]~10_combout\ & ((\bus_hex2[0]~5_combout\ & ((\bus_hex2[3]~18_combout\))) # (!\bus_hex2[0]~5_combout\ & (\bus_hex2[2]~14_combout\)))) # (!\bus_hex2[1]~10_combout\ & (\bus_hex2[2]~14_combout\ & ((\bus_hex2[0]~5_combout\) # 
-- (\bus_hex2[3]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux1~0_combout\);

-- Location: LCCOMB_X29_Y28_N12
\d2|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d2|Mux0~0_combout\ = (\bus_hex2[2]~14_combout\ & (\bus_hex2[3]~18_combout\ $ (((!\bus_hex2[1]~10_combout\ & !\bus_hex2[0]~5_combout\))))) # (!\bus_hex2[2]~14_combout\ & (\bus_hex2[0]~5_combout\ & (\bus_hex2[1]~10_combout\ $ (!\bus_hex2[3]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[1]~10_combout\,
	datab => \bus_hex2[2]~14_combout\,
	datac => \bus_hex2[0]~5_combout\,
	datad => \bus_hex2[3]~18_combout\,
	combout => \d2|Mux0~0_combout\);

-- Location: LCCOMB_X4_Y23_N2
\c_azul|dec[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|dec[0]~6_combout\ = !\c_azul|dec\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_azul|dec\(0),
	combout => \c_azul|dec[0]~6_combout\);

-- Location: LCCOMB_X4_Y26_N12
\c_azul|uni[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|uni[0]~3_combout\ = !\c_azul|uni\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_azul|uni\(0),
	combout => \c_azul|uni[0]~3_combout\);

-- Location: LCCOMB_X4_Y26_N18
\comb~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \comb~8_combout\ = (!\sinc_a|d_sync2~q\ & (\hab_conteo~0_combout\ & \sinc_a|d_sync1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sinc_a|d_sync2~q\,
	datac => \hab_conteo~0_combout\,
	datad => \sinc_a|d_sync1~q\,
	combout => \comb~8_combout\);

-- Location: FF_X4_Y26_N13
\c_azul|uni[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|uni[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \comb~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|uni\(0));

-- Location: LCCOMB_X4_Y26_N8
\c_azul|uni[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|uni[2]~1_combout\ = \c_azul|uni\(2) $ (((\c_azul|uni\(1) & (\c_azul|uni\(0) & \comb~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|uni\(1),
	datab => \c_azul|uni\(0),
	datac => \c_azul|uni\(2),
	datad => \comb~8_combout\,
	combout => \c_azul|uni[2]~1_combout\);

-- Location: FF_X4_Y26_N9
\c_azul|uni[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|uni[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|uni\(2));

-- Location: LCCOMB_X4_Y26_N30
\c_azul|uni~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|uni~0_combout\ = (\c_azul|uni\(1) & (((!\c_azul|uni\(0))))) # (!\c_azul|uni\(1) & (\c_azul|uni\(0) & ((\c_azul|uni\(2)) # (!\c_azul|uni\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|uni\(3),
	datab => \c_azul|uni\(2),
	datac => \c_azul|uni\(1),
	datad => \c_azul|uni\(0),
	combout => \c_azul|uni~0_combout\);

-- Location: FF_X4_Y26_N31
\c_azul|uni[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|uni~0_combout\,
	clrn => \rst~input_o\,
	ena => \comb~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|uni\(1));

-- Location: LCCOMB_X4_Y26_N6
\c_azul|uni~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|uni~2_combout\ = (\c_azul|uni\(1) & (\c_azul|uni\(3) $ (((\c_azul|uni\(2) & \c_azul|uni\(0)))))) # (!\c_azul|uni\(1) & (\c_azul|uni\(3) & ((\c_azul|uni\(2)) # (!\c_azul|uni\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|uni\(1),
	datab => \c_azul|uni\(2),
	datac => \c_azul|uni\(3),
	datad => \c_azul|uni\(0),
	combout => \c_azul|uni~2_combout\);

-- Location: FF_X4_Y26_N7
\c_azul|uni[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|uni~2_combout\,
	clrn => \rst~input_o\,
	ena => \comb~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|uni\(3));

-- Location: LCCOMB_X4_Y26_N4
\c_azul|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|Equal0~0_combout\ = (\c_azul|uni\(3) & (!\c_azul|uni\(2) & (!\c_azul|uni\(1) & \c_azul|uni\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|uni\(3),
	datab => \c_azul|uni\(2),
	datac => \c_azul|uni\(1),
	datad => \c_azul|uni\(0),
	combout => \c_azul|Equal0~0_combout\);

-- Location: LCCOMB_X4_Y23_N10
\c_azul|dec[3]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|dec[3]~5_combout\ = (\c_azul|Equal0~0_combout\ & (!\sinc_a|d_sync2~q\ & (\sinc_a|d_sync1~q\ & \hab_conteo~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|Equal0~0_combout\,
	datab => \sinc_a|d_sync2~q\,
	datac => \sinc_a|d_sync1~q\,
	datad => \hab_conteo~0_combout\,
	combout => \c_azul|dec[3]~5_combout\);

-- Location: FF_X4_Y23_N3
\c_azul|dec[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|dec[0]~6_combout\,
	clrn => \rst~input_o\,
	ena => \c_azul|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|dec\(0));

-- Location: LCCOMB_X4_Y23_N28
\c_azul|dec~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|dec~4_combout\ = (\c_azul|dec\(2) & (\c_azul|dec\(3) $ (((\c_azul|dec\(1) & \c_azul|dec\(0)))))) # (!\c_azul|dec\(2) & (\c_azul|dec\(3) & ((\c_azul|dec\(1)) # (!\c_azul|dec\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(2),
	datab => \c_azul|dec\(1),
	datac => \c_azul|dec\(3),
	datad => \c_azul|dec\(0),
	combout => \c_azul|dec~4_combout\);

-- Location: FF_X4_Y23_N29
\c_azul|dec[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|dec~4_combout\,
	clrn => \rst~input_o\,
	ena => \c_azul|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|dec\(3));

-- Location: LCCOMB_X4_Y23_N16
\c_azul|dec~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|dec~2_combout\ = (\c_azul|dec\(0) & (!\c_azul|dec\(1) & ((\c_azul|dec\(2)) # (!\c_azul|dec\(3))))) # (!\c_azul|dec\(0) & (((\c_azul|dec\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011100000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(2),
	datab => \c_azul|dec\(0),
	datac => \c_azul|dec\(1),
	datad => \c_azul|dec\(3),
	combout => \c_azul|dec~2_combout\);

-- Location: FF_X4_Y23_N17
\c_azul|dec[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|dec~2_combout\,
	clrn => \rst~input_o\,
	ena => \c_azul|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|dec\(1));

-- Location: LCCOMB_X4_Y23_N30
\c_azul|dec[2]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_azul|dec[2]~3_combout\ = \c_azul|dec\(2) $ (((\c_azul|dec\(1) & (\c_azul|dec\(0) & \c_azul|dec[3]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(1),
	datab => \c_azul|dec\(0),
	datac => \c_azul|dec\(2),
	datad => \c_azul|dec[3]~5_combout\,
	combout => \c_azul|dec[2]~3_combout\);

-- Location: FF_X4_Y23_N31
\c_azul|dec[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_azul|dec[2]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_azul|dec\(2));

-- Location: LCCOMB_X1_Y23_N24
\u_mem_rf4|registros[0][6]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[0][6]~feeder_combout\ = \u_gestor_rf5|t_dec\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_gestor_rf5|t_dec\(2),
	combout => \u_mem_rf4|registros[0][6]~feeder_combout\);

-- Location: FF_X1_Y23_N25
\u_mem_rf4|registros[0][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[0][6]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][6]~q\);

-- Location: LCCOMB_X1_Y23_N18
\u_mem_rf4|registros[1][6]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][6]~feeder_combout\ = \u_mem_rf4|registros[0][6]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][6]~q\,
	combout => \u_mem_rf4|registros[1][6]~feeder_combout\);

-- Location: FF_X1_Y23_N19
\u_mem_rf4|registros[1][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][6]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][6]~q\);

-- Location: LCCOMB_X1_Y23_N30
\bus_hex1[2]~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~24_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\) # (\u_mem_rf4|registros[1][6]~q\)))) # (!\sel_memoria[0]~input_o\ & (\u_mem_rf4|registros[0][6]~q\ & (!\sel_memoria[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \u_mem_rf4|registros[0][6]~q\,
	datac => \sel_memoria[1]~input_o\,
	datad => \u_mem_rf4|registros[1][6]~q\,
	combout => \bus_hex1[2]~24_combout\);

-- Location: LCCOMB_X1_Y23_N4
\u_mem_rf4|registros[2][6]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][6]~feeder_combout\ = \u_mem_rf4|registros[1][6]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][6]~q\,
	combout => \u_mem_rf4|registros[2][6]~feeder_combout\);

-- Location: FF_X1_Y23_N5
\u_mem_rf4|registros[2][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][6]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][6]~q\);

-- Location: FF_X1_Y23_N9
\u_mem_rf4|registros[3][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][6]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][6]~q\);

-- Location: LCCOMB_X1_Y23_N8
\bus_hex1[2]~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~25_combout\ = (\bus_hex1[2]~24_combout\ & (((\u_mem_rf4|registros[3][6]~q\) # (!\sel_memoria[1]~input_o\)))) # (!\bus_hex1[2]~24_combout\ & (\u_mem_rf4|registros[2][6]~q\ & ((\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~24_combout\,
	datab => \u_mem_rf4|registros[2][6]~q\,
	datac => \u_mem_rf4|registros[3][6]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \bus_hex1[2]~25_combout\);

-- Location: LCCOMB_X2_Y22_N0
\c_total|dec[0]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|dec[0]~4_combout\ = !\c_total|dec\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_total|dec\(0),
	combout => \c_total|dec[0]~4_combout\);

-- Location: LCCOMB_X3_Y22_N12
\c_total|uni[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|uni[0]~3_combout\ = !\c_total|uni\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_total|uni\(0),
	combout => \c_total|uni[0]~3_combout\);

-- Location: FF_X3_Y22_N13
\c_total|uni[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|uni[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|uni\(0));

-- Location: LCCOMB_X3_Y22_N24
\c_total|uni[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|uni[2]~1_combout\ = \c_total|uni\(2) $ (((\hab_conteo~0_combout\ & (\c_total|uni\(1) & \c_total|uni\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hab_conteo~0_combout\,
	datab => \c_total|uni\(1),
	datac => \c_total|uni\(2),
	datad => \c_total|uni\(0),
	combout => \c_total|uni[2]~1_combout\);

-- Location: FF_X3_Y22_N25
\c_total|uni[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|uni[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|uni\(2));

-- Location: LCCOMB_X3_Y22_N22
\c_total|uni~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|uni~2_combout\ = (\c_total|uni\(0) & ((\c_total|uni\(1) & (\c_total|uni\(3) $ (\c_total|uni\(2)))) # (!\c_total|uni\(1) & (\c_total|uni\(3) & \c_total|uni\(2))))) # (!\c_total|uni\(0) & (((\c_total|uni\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|uni\(0),
	datab => \c_total|uni\(1),
	datac => \c_total|uni\(3),
	datad => \c_total|uni\(2),
	combout => \c_total|uni~2_combout\);

-- Location: FF_X3_Y22_N23
\c_total|uni[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|uni~2_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|uni\(3));

-- Location: LCCOMB_X3_Y22_N2
\c_total|uni~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|uni~0_combout\ = (\c_total|uni\(1) & (((!\c_total|uni\(0))))) # (!\c_total|uni\(1) & (\c_total|uni\(0) & ((\c_total|uni\(2)) # (!\c_total|uni\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|uni\(3),
	datab => \c_total|uni\(2),
	datac => \c_total|uni\(1),
	datad => \c_total|uni\(0),
	combout => \c_total|uni~0_combout\);

-- Location: FF_X3_Y22_N3
\c_total|uni[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|uni~0_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|uni\(1));

-- Location: LCCOMB_X3_Y22_N4
\c_total|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|Equal0~0_combout\ = (\c_total|uni\(0) & (!\c_total|uni\(1) & (\c_total|uni\(3) & !\c_total|uni\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|uni\(0),
	datab => \c_total|uni\(1),
	datac => \c_total|uni\(3),
	datad => \c_total|uni\(2),
	combout => \c_total|Equal0~0_combout\);

-- Location: LCCOMB_X2_Y22_N12
\c_total|dec[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|dec[3]~0_combout\ = (\hab_conteo~0_combout\ & \c_total|Equal0~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \hab_conteo~0_combout\,
	datad => \c_total|Equal0~0_combout\,
	combout => \c_total|dec[3]~0_combout\);

-- Location: FF_X2_Y22_N1
\c_total|dec[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|dec[0]~4_combout\,
	clrn => \rst~input_o\,
	ena => \c_total|dec[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|dec\(0));

-- Location: LCCOMB_X2_Y22_N22
\c_total|dec~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|dec~3_combout\ = (\c_total|dec\(1) & (\c_total|dec\(3) $ (((\c_total|dec\(2) & \c_total|dec\(0)))))) # (!\c_total|dec\(1) & (\c_total|dec\(3) & ((\c_total|dec\(2)) # (!\c_total|dec\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|dec\(1),
	datab => \c_total|dec\(2),
	datac => \c_total|dec\(3),
	datad => \c_total|dec\(0),
	combout => \c_total|dec~3_combout\);

-- Location: FF_X2_Y22_N23
\c_total|dec[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|dec~3_combout\,
	clrn => \rst~input_o\,
	ena => \c_total|dec[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|dec\(3));

-- Location: LCCOMB_X2_Y22_N2
\c_total|dec~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|dec~1_combout\ = (\c_total|dec\(1) & (((!\c_total|dec\(0))))) # (!\c_total|dec\(1) & (\c_total|dec\(0) & ((\c_total|dec\(2)) # (!\c_total|dec\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|dec\(3),
	datab => \c_total|dec\(2),
	datac => \c_total|dec\(1),
	datad => \c_total|dec\(0),
	combout => \c_total|dec~1_combout\);

-- Location: FF_X2_Y22_N3
\c_total|dec[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|dec~1_combout\,
	clrn => \rst~input_o\,
	ena => \c_total|dec[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|dec\(1));

-- Location: LCCOMB_X2_Y22_N24
\c_total|dec[2]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_total|dec[2]~2_combout\ = \c_total|dec\(2) $ (((\c_total|dec\(1) & (\c_total|dec\(0) & \c_total|dec[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|dec\(1),
	datab => \c_total|dec\(0),
	datac => \c_total|dec\(2),
	datad => \c_total|dec[3]~0_combout\,
	combout => \c_total|dec[2]~2_combout\);

-- Location: FF_X2_Y22_N25
\c_total|dec[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_total|dec[2]~2_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_total|dec\(2));

-- Location: LCCOMB_X4_Y23_N14
\bus_hex1[2]~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~13_combout\ = (!\u_gestor_rf5|color_activo\(1) & (\u_gestor_rf5|color_activo\(2) & ((\u_gestor_rf5|timer\(0)) # (\u_gestor_rf5|timer\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|color_activo\(1),
	datab => \u_gestor_rf5|color_activo\(2),
	datac => \u_gestor_rf5|timer\(0),
	datad => \u_gestor_rf5|timer\(1),
	combout => \bus_hex1[2]~13_combout\);

-- Location: LCCOMB_X4_Y23_N24
\bus_hex1[2]~19\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~19_combout\ = (\bus_hex2[3]~0_combout\ & (((\bus_hex1[2]~13_combout\ & !\u_gestor_rf5|color_activo\(0))))) # (!\bus_hex2[3]~0_combout\ & ((\bus_hex1[2]~1_combout\) # ((\bus_hex1[2]~13_combout\ & !\u_gestor_rf5|color_activo\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex2[3]~0_combout\,
	datab => \bus_hex1[2]~1_combout\,
	datac => \bus_hex1[2]~13_combout\,
	datad => \u_gestor_rf5|color_activo\(0),
	combout => \bus_hex1[2]~19_combout\);

-- Location: LCCOMB_X5_Y23_N22
\bus_hex1[2]~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~20_combout\ = (\bus_hex1[2]~19_combout\) # ((\bus_hex1[2]~0_combout\ & (!\sw_menu[2]~input_o\ & \sw_menu[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~0_combout\,
	datab => \sw_menu[2]~input_o\,
	datac => \sw_menu[0]~input_o\,
	datad => \bus_hex1[2]~19_combout\,
	combout => \bus_hex1[2]~20_combout\);

-- Location: LCCOMB_X2_Y24_N14
\bus_hex1[2]~21\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~21_combout\ = (\bus_hex1[2]~20_combout\ & ((\c_total|dec\(2)) # ((\sw_menu[0]~input_o\) # (!\bus_hex1[2]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|dec\(2),
	datab => \bus_hex1[2]~20_combout\,
	datac => \bus_hex1[2]~0_combout\,
	datad => \sw_menu[0]~input_o\,
	combout => \bus_hex1[2]~21_combout\);

-- Location: LCCOMB_X3_Y24_N4
\c_rojo|dec[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|dec[0]~6_combout\ = !\c_rojo|dec\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_rojo|dec\(0),
	combout => \c_rojo|dec[0]~6_combout\);

-- Location: LCCOMB_X4_Y24_N14
\c_rojo|uni[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|uni[0]~3_combout\ = !\c_rojo|uni\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_rojo|uni\(0),
	combout => \c_rojo|uni[0]~3_combout\);

-- Location: LCCOMB_X4_Y24_N18
\comb~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \comb~10_combout\ = (!\sinc_r|d_sync2~q\ & (\hab_conteo~0_combout\ & \sinc_r|d_sync1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sinc_r|d_sync2~q\,
	datac => \hab_conteo~0_combout\,
	datad => \sinc_r|d_sync1~q\,
	combout => \comb~10_combout\);

-- Location: FF_X4_Y24_N15
\c_rojo|uni[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|uni[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \comb~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|uni\(0));

-- Location: LCCOMB_X4_Y24_N4
\c_rojo|uni[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|uni[2]~1_combout\ = \c_rojo|uni\(2) $ (((\c_rojo|uni\(1) & (\c_rojo|uni\(0) & \comb~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|uni\(1),
	datab => \c_rojo|uni\(0),
	datac => \c_rojo|uni\(2),
	datad => \comb~10_combout\,
	combout => \c_rojo|uni[2]~1_combout\);

-- Location: FF_X4_Y24_N5
\c_rojo|uni[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|uni[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|uni\(2));

-- Location: LCCOMB_X4_Y24_N12
\c_rojo|uni~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|uni~2_combout\ = (\c_rojo|uni\(0) & ((\c_rojo|uni\(2) & (\c_rojo|uni\(3) $ (\c_rojo|uni\(1)))) # (!\c_rojo|uni\(2) & (\c_rojo|uni\(3) & \c_rojo|uni\(1))))) # (!\c_rojo|uni\(0) & (((\c_rojo|uni\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|uni\(0),
	datab => \c_rojo|uni\(2),
	datac => \c_rojo|uni\(3),
	datad => \c_rojo|uni\(1),
	combout => \c_rojo|uni~2_combout\);

-- Location: FF_X4_Y24_N13
\c_rojo|uni[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|uni~2_combout\,
	clrn => \rst~input_o\,
	ena => \comb~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|uni\(3));

-- Location: LCCOMB_X4_Y24_N6
\c_rojo|uni~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|uni~0_combout\ = (\c_rojo|uni\(0) & (!\c_rojo|uni\(1) & ((\c_rojo|uni\(2)) # (!\c_rojo|uni\(3))))) # (!\c_rojo|uni\(0) & (((\c_rojo|uni\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|uni\(0),
	datab => \c_rojo|uni\(2),
	datac => \c_rojo|uni\(1),
	datad => \c_rojo|uni\(3),
	combout => \c_rojo|uni~0_combout\);

-- Location: FF_X4_Y24_N7
\c_rojo|uni[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|uni~0_combout\,
	clrn => \rst~input_o\,
	ena => \comb~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|uni\(1));

-- Location: LCCOMB_X4_Y24_N20
\c_rojo|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|Equal0~0_combout\ = (!\c_rojo|uni\(1) & (!\c_rojo|uni\(2) & (\c_rojo|uni\(0) & \c_rojo|uni\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|uni\(1),
	datab => \c_rojo|uni\(2),
	datac => \c_rojo|uni\(0),
	datad => \c_rojo|uni\(3),
	combout => \c_rojo|Equal0~0_combout\);

-- Location: LCCOMB_X3_Y24_N2
\c_rojo|dec[3]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|dec[3]~5_combout\ = (\c_rojo|Equal0~0_combout\ & (!\sinc_r|d_sync2~q\ & (\sinc_r|d_sync1~q\ & \hab_conteo~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|Equal0~0_combout\,
	datab => \sinc_r|d_sync2~q\,
	datac => \sinc_r|d_sync1~q\,
	datad => \hab_conteo~0_combout\,
	combout => \c_rojo|dec[3]~5_combout\);

-- Location: FF_X3_Y24_N5
\c_rojo|dec[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|dec[0]~6_combout\,
	clrn => \rst~input_o\,
	ena => \c_rojo|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|dec\(0));

-- Location: LCCOMB_X3_Y24_N20
\c_rojo|dec~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|dec~4_combout\ = (\c_rojo|dec\(1) & (\c_rojo|dec\(3) $ (((\c_rojo|dec\(0) & \c_rojo|dec\(2)))))) # (!\c_rojo|dec\(1) & (\c_rojo|dec\(3) & ((\c_rojo|dec\(2)) # (!\c_rojo|dec\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|dec\(1),
	datab => \c_rojo|dec\(0),
	datac => \c_rojo|dec\(3),
	datad => \c_rojo|dec\(2),
	combout => \c_rojo|dec~4_combout\);

-- Location: FF_X3_Y24_N21
\c_rojo|dec[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|dec~4_combout\,
	clrn => \rst~input_o\,
	ena => \c_rojo|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|dec\(3));

-- Location: LCCOMB_X3_Y24_N12
\c_rojo|dec~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|dec~2_combout\ = (\c_rojo|dec\(0) & (!\c_rojo|dec\(1) & ((\c_rojo|dec\(2)) # (!\c_rojo|dec\(3))))) # (!\c_rojo|dec\(0) & (((\c_rojo|dec\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|dec\(3),
	datab => \c_rojo|dec\(0),
	datac => \c_rojo|dec\(1),
	datad => \c_rojo|dec\(2),
	combout => \c_rojo|dec~2_combout\);

-- Location: FF_X3_Y24_N13
\c_rojo|dec[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|dec~2_combout\,
	clrn => \rst~input_o\,
	ena => \c_rojo|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|dec\(1));

-- Location: LCCOMB_X3_Y24_N28
\c_rojo|dec[2]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_rojo|dec[2]~3_combout\ = \c_rojo|dec\(2) $ (((\c_rojo|dec\(1) & (\c_rojo|dec\(0) & \c_rojo|dec[3]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|dec\(1),
	datab => \c_rojo|dec\(0),
	datac => \c_rojo|dec\(2),
	datad => \c_rojo|dec[3]~5_combout\,
	combout => \c_rojo|dec[2]~3_combout\);

-- Location: FF_X3_Y24_N29
\c_rojo|dec[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_rojo|dec[2]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_rojo|dec\(2));

-- Location: LCCOMB_X4_Y23_N6
\bus_hex1[2]~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~18_combout\ = (!\u_gestor_rf5|timer\(0) & (!\u_gestor_rf5|timer\(1) & ((\u_gestor_rf5|t_dec\(2)) # (\sw_menu[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec\(2),
	datab => \sw_menu[1]~input_o\,
	datac => \u_gestor_rf5|timer\(0),
	datad => \u_gestor_rf5|timer\(1),
	combout => \bus_hex1[2]~18_combout\);

-- Location: LCCOMB_X3_Y24_N26
\bus_hex1[2]~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~22_combout\ = (\bus_hex1[2]~21_combout\ & ((\c_rojo|dec\(2)) # ((\bus_hex1[2]~1_combout\)))) # (!\bus_hex1[2]~21_combout\ & (((!\bus_hex1[2]~1_combout\ & \bus_hex1[2]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~21_combout\,
	datab => \c_rojo|dec\(2),
	datac => \bus_hex1[2]~1_combout\,
	datad => \bus_hex1[2]~18_combout\,
	combout => \bus_hex1[2]~22_combout\);

-- Location: LCCOMB_X4_Y23_N20
\bus_hex1[2]~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~12_combout\ = (!\sw_menu[2]~input_o\ & (\sw_menu[1]~input_o\ & (\bus_hex1[2]~0_combout\ & \sw_menu[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[2]~input_o\,
	datab => \sw_menu[1]~input_o\,
	datac => \bus_hex1[2]~0_combout\,
	datad => \sw_menu[0]~input_o\,
	combout => \bus_hex1[2]~12_combout\);

-- Location: LCCOMB_X4_Y23_N0
\bus_hex1[2]~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~14_combout\ = (\modo_cons~input_o\) # ((\bus_hex1[2]~12_combout\) # ((\u_gestor_rf5|color_activo\(0) & \bus_hex1[2]~13_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|color_activo\(0),
	datab => \modo_cons~input_o\,
	datac => \bus_hex1[2]~13_combout\,
	datad => \bus_hex1[2]~12_combout\,
	combout => \bus_hex1[2]~14_combout\);

-- Location: LCCOMB_X2_Y24_N30
\c_verde|dec[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|dec[0]~6_combout\ = !\c_verde|dec\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_verde|dec\(0),
	combout => \c_verde|dec[0]~6_combout\);

-- Location: LCCOMB_X5_Y24_N14
\c_verde|uni[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|uni[0]~3_combout\ = !\c_verde|uni\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \c_verde|uni\(0),
	combout => \c_verde|uni[0]~3_combout\);

-- Location: LCCOMB_X5_Y24_N6
\comb~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \comb~9_combout\ = (\sinc_v|d_sync1~q\ & (!\sinc_v|d_sync2~q\ & \hab_conteo~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sinc_v|d_sync1~q\,
	datab => \sinc_v|d_sync2~q\,
	datad => \hab_conteo~0_combout\,
	combout => \comb~9_combout\);

-- Location: FF_X5_Y24_N15
\c_verde|uni[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|uni[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \comb~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|uni\(0));

-- Location: LCCOMB_X5_Y24_N2
\c_verde|uni[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|uni[2]~1_combout\ = \c_verde|uni\(2) $ (((\c_verde|uni\(0) & (\c_verde|uni\(1) & \comb~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|uni\(0),
	datab => \c_verde|uni\(1),
	datac => \c_verde|uni\(2),
	datad => \comb~9_combout\,
	combout => \c_verde|uni[2]~1_combout\);

-- Location: FF_X5_Y24_N3
\c_verde|uni[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|uni[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|uni\(2));

-- Location: LCCOMB_X5_Y24_N0
\c_verde|uni~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|uni~0_combout\ = (\c_verde|uni\(0) & (!\c_verde|uni\(1) & ((\c_verde|uni\(2)) # (!\c_verde|uni\(3))))) # (!\c_verde|uni\(0) & (((\c_verde|uni\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|uni\(3),
	datab => \c_verde|uni\(0),
	datac => \c_verde|uni\(1),
	datad => \c_verde|uni\(2),
	combout => \c_verde|uni~0_combout\);

-- Location: FF_X5_Y24_N1
\c_verde|uni[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|uni~0_combout\,
	clrn => \rst~input_o\,
	ena => \comb~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|uni\(1));

-- Location: LCCOMB_X5_Y24_N12
\c_verde|uni~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|uni~2_combout\ = (\c_verde|uni\(0) & ((\c_verde|uni\(1) & (\c_verde|uni\(3) $ (\c_verde|uni\(2)))) # (!\c_verde|uni\(1) & (\c_verde|uni\(3) & \c_verde|uni\(2))))) # (!\c_verde|uni\(0) & (((\c_verde|uni\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|uni\(0),
	datab => \c_verde|uni\(1),
	datac => \c_verde|uni\(3),
	datad => \c_verde|uni\(2),
	combout => \c_verde|uni~2_combout\);

-- Location: FF_X5_Y24_N13
\c_verde|uni[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|uni~2_combout\,
	clrn => \rst~input_o\,
	ena => \comb~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|uni\(3));

-- Location: LCCOMB_X5_Y24_N24
\c_verde|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|Equal0~0_combout\ = (\c_verde|uni\(3) & (!\c_verde|uni\(1) & (\c_verde|uni\(0) & !\c_verde|uni\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|uni\(3),
	datab => \c_verde|uni\(1),
	datac => \c_verde|uni\(0),
	datad => \c_verde|uni\(2),
	combout => \c_verde|Equal0~0_combout\);

-- Location: LCCOMB_X2_Y24_N2
\c_verde|dec[3]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|dec[3]~5_combout\ = (!\sinc_v|d_sync2~q\ & (\sinc_v|d_sync1~q\ & (\hab_conteo~0_combout\ & \c_verde|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sinc_v|d_sync2~q\,
	datab => \sinc_v|d_sync1~q\,
	datac => \hab_conteo~0_combout\,
	datad => \c_verde|Equal0~0_combout\,
	combout => \c_verde|dec[3]~5_combout\);

-- Location: FF_X2_Y24_N31
\c_verde|dec[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|dec[0]~6_combout\,
	clrn => \rst~input_o\,
	ena => \c_verde|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|dec\(0));

-- Location: LCCOMB_X2_Y24_N0
\c_verde|dec~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|dec~4_combout\ = (\c_verde|dec\(0) & ((\c_verde|dec\(1) & (\c_verde|dec\(3) $ (\c_verde|dec\(2)))) # (!\c_verde|dec\(1) & (\c_verde|dec\(3) & \c_verde|dec\(2))))) # (!\c_verde|dec\(0) & (((\c_verde|dec\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|dec\(0),
	datab => \c_verde|dec\(1),
	datac => \c_verde|dec\(3),
	datad => \c_verde|dec\(2),
	combout => \c_verde|dec~4_combout\);

-- Location: FF_X2_Y24_N1
\c_verde|dec[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|dec~4_combout\,
	clrn => \rst~input_o\,
	ena => \c_verde|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|dec\(3));

-- Location: LCCOMB_X2_Y24_N20
\c_verde|dec~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|dec~2_combout\ = (\c_verde|dec\(0) & (!\c_verde|dec\(1) & ((\c_verde|dec\(2)) # (!\c_verde|dec\(3))))) # (!\c_verde|dec\(0) & (((\c_verde|dec\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|dec\(0),
	datab => \c_verde|dec\(3),
	datac => \c_verde|dec\(1),
	datad => \c_verde|dec\(2),
	combout => \c_verde|dec~2_combout\);

-- Location: FF_X2_Y24_N21
\c_verde|dec[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|dec~2_combout\,
	clrn => \rst~input_o\,
	ena => \c_verde|dec[3]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|dec\(1));

-- Location: LCCOMB_X2_Y24_N16
\c_verde|dec[2]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \c_verde|dec[2]~3_combout\ = \c_verde|dec\(2) $ (((\c_verde|dec\(0) & (\c_verde|dec\(1) & \c_verde|dec[3]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|dec\(0),
	datab => \c_verde|dec\(1),
	datac => \c_verde|dec\(2),
	datad => \c_verde|dec[3]~5_combout\,
	combout => \c_verde|dec[2]~3_combout\);

-- Location: FF_X2_Y24_N17
\c_verde|dec[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \c_verde|dec[2]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \c_verde|dec\(2));

-- Location: LCCOMB_X5_Y23_N4
\bus_hex1[2]~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~16_combout\ = (\sw_menu[1]~input_o\ & (!\sw_menu[2]~input_o\ & \bus_hex1[2]~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \sw_menu[2]~input_o\,
	datac => \bus_hex1[2]~1_combout\,
	combout => \bus_hex1[2]~16_combout\);

-- Location: LCCOMB_X4_Y23_N22
\bus_hex1[2]~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~15_combout\ = (\u_gestor_rf5|color_activo\(1) & (!\u_gestor_rf5|color_activo\(2) & (!\bus_hex1[2]~0_combout\ & \u_gestor_rf5|color_activo\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|color_activo\(1),
	datab => \u_gestor_rf5|color_activo\(2),
	datac => \bus_hex1[2]~0_combout\,
	datad => \u_gestor_rf5|color_activo\(0),
	combout => \bus_hex1[2]~15_combout\);

-- Location: LCCOMB_X4_Y23_N4
\bus_hex1[2]~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~17_combout\ = (\modo_cons~input_o\) # ((!\bus_hex1[2]~14_combout\ & ((\bus_hex1[2]~16_combout\) # (\bus_hex1[2]~15_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~16_combout\,
	datab => \modo_cons~input_o\,
	datac => \bus_hex1[2]~15_combout\,
	datad => \bus_hex1[2]~14_combout\,
	combout => \bus_hex1[2]~17_combout\);

-- Location: LCCOMB_X4_Y24_N30
\bus_hex1[2]~23\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~23_combout\ = (\bus_hex1[2]~14_combout\ & (((\bus_hex1[2]~17_combout\)))) # (!\bus_hex1[2]~14_combout\ & ((\bus_hex1[2]~17_combout\ & ((\c_verde|dec\(2)))) # (!\bus_hex1[2]~17_combout\ & (\bus_hex1[2]~22_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~22_combout\,
	datab => \bus_hex1[2]~14_combout\,
	datac => \c_verde|dec\(2),
	datad => \bus_hex1[2]~17_combout\,
	combout => \bus_hex1[2]~23_combout\);

-- Location: LCCOMB_X4_Y23_N26
\bus_hex1[2]~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~26_combout\ = (\bus_hex1[2]~23_combout\ & (((\bus_hex1[2]~25_combout\) # (!\bus_hex1[2]~14_combout\)))) # (!\bus_hex1[2]~23_combout\ & (\c_azul|dec\(2) & ((\bus_hex1[2]~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(2),
	datab => \bus_hex1[2]~25_combout\,
	datac => \bus_hex1[2]~23_combout\,
	datad => \bus_hex1[2]~14_combout\,
	combout => \bus_hex1[2]~26_combout\);

-- Location: LCCOMB_X2_Y24_N6
\u_gestor_rf5|hex1[1]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~5_combout\ = (\sw_menu[1]~input_o\ & (!\sw_menu[2]~input_o\ & ((\c_verde|dec\(1))))) # (!\sw_menu[1]~input_o\ & (\sw_menu[2]~input_o\ & (\sel_vel[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \sw_menu[2]~input_o\,
	datac => \sel_vel[1]~input_o\,
	datad => \c_verde|dec\(1),
	combout => \u_gestor_rf5|hex1[1]~5_combout\);

-- Location: LCCOMB_X2_Y24_N24
\u_gestor_rf5|hex1[1]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~6_combout\ = (\u_gestor_rf5|hex1[1]~5_combout\) # ((\c_total|dec\(1) & (\sw_menu[1]~input_o\ $ (!\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|hex1[1]~5_combout\,
	datab => \sw_menu[1]~input_o\,
	datac => \sw_menu[2]~input_o\,
	datad => \c_total|dec\(1),
	combout => \u_gestor_rf5|hex1[1]~6_combout\);

-- Location: LCCOMB_X2_Y24_N28
\u_gestor_rf5|hex1[1]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~3_combout\ = (\sw_menu[2]~input_o\ & (((\u_gestor_rf5|t_dec\(1)) # (\sw_menu[1]~input_o\)))) # (!\sw_menu[2]~input_o\ & (\c_rojo|dec\(1) & ((!\sw_menu[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|dec\(1),
	datab => \u_gestor_rf5|t_dec\(1),
	datac => \sw_menu[2]~input_o\,
	datad => \sw_menu[1]~input_o\,
	combout => \u_gestor_rf5|hex1[1]~3_combout\);

-- Location: LCCOMB_X3_Y24_N8
\u_gestor_rf5|hex1[1]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~4_combout\ = (\sw_menu[0]~input_o\ & ((\u_gestor_rf5|hex1[1]~3_combout\) # ((\c_azul|dec\(1) & \sw_menu[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(1),
	datab => \sw_menu[0]~input_o\,
	datac => \sw_menu[1]~input_o\,
	datad => \u_gestor_rf5|hex1[1]~3_combout\,
	combout => \u_gestor_rf5|hex1[1]~4_combout\);

-- Location: LCCOMB_X3_Y24_N18
\u_gestor_rf5|hex1[1]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~7_combout\ = (\bus_hex1[2]~0_combout\ & ((\u_gestor_rf5|hex1[1]~4_combout\) # ((\u_gestor_rf5|hex1[1]~6_combout\ & !\sw_menu[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~0_combout\,
	datab => \u_gestor_rf5|hex1[1]~6_combout\,
	datac => \u_gestor_rf5|hex1[1]~4_combout\,
	datad => \sw_menu[0]~input_o\,
	combout => \u_gestor_rf5|hex1[1]~7_combout\);

-- Location: LCCOMB_X5_Y24_N4
\u_gestor_rf5|hex1[1]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~0_combout\ = (!\u_gestor_rf5|color_activo\(1) & \u_gestor_rf5|color_activo\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|color_activo\(1),
	datad => \u_gestor_rf5|color_activo\(2),
	combout => \u_gestor_rf5|hex1[1]~0_combout\);

-- Location: LCCOMB_X3_Y24_N30
\u_gestor_rf5|hex1[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~1_combout\ = (\u_gestor_rf5|hex1[1]~0_combout\ & ((\u_gestor_rf5|color_activo\(0) & ((\c_azul|dec\(1)))) # (!\u_gestor_rf5|color_activo\(0) & (\c_rojo|dec\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|dec\(1),
	datab => \u_gestor_rf5|color_activo\(0),
	datac => \c_azul|dec\(1),
	datad => \u_gestor_rf5|hex1[1]~0_combout\,
	combout => \u_gestor_rf5|hex1[1]~1_combout\);

-- Location: LCCOMB_X3_Y24_N22
\bus_hex1[2]~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[2]~8_combout\ = (\u_gestor_rf5|color_activo\(1) & (\u_gestor_rf5|color_activo\(0) & !\u_gestor_rf5|color_activo\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_gestor_rf5|color_activo\(1),
	datac => \u_gestor_rf5|color_activo\(0),
	datad => \u_gestor_rf5|color_activo\(2),
	combout => \bus_hex1[2]~8_combout\);

-- Location: LCCOMB_X2_Y24_N22
\u_gestor_rf5|hex1[1]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_gestor_rf5|hex1[1]~2_combout\ = (!\bus_hex1[2]~0_combout\ & ((\u_gestor_rf5|hex1[1]~1_combout\) # ((\c_verde|dec\(1) & \bus_hex1[2]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|hex1[1]~1_combout\,
	datab => \c_verde|dec\(1),
	datac => \bus_hex1[2]~0_combout\,
	datad => \bus_hex1[2]~8_combout\,
	combout => \u_gestor_rf5|hex1[1]~2_combout\);

-- Location: FF_X1_Y24_N19
\u_mem_rf4|registros[0][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_dec\(1),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][5]~q\);

-- Location: FF_X1_Y24_N21
\u_mem_rf4|registros[1][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[0][5]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][5]~q\);

-- Location: LCCOMB_X1_Y24_N22
\u_mem_rf4|registros[2][5]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][5]~feeder_combout\ = \u_mem_rf4|registros[1][5]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][5]~q\,
	combout => \u_mem_rf4|registros[2][5]~feeder_combout\);

-- Location: FF_X1_Y24_N23
\u_mem_rf4|registros[2][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][5]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][5]~q\);

-- Location: LCCOMB_X1_Y24_N18
\u_mem_rf4|Mux9~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|Mux9~0_combout\ = (\sel_memoria[1]~input_o\ & ((\u_mem_rf4|registros[2][5]~q\) # ((\sel_memoria[0]~input_o\)))) # (!\sel_memoria[1]~input_o\ & (((\u_mem_rf4|registros[0][5]~q\ & !\sel_memoria[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][5]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[0][5]~q\,
	datad => \sel_memoria[0]~input_o\,
	combout => \u_mem_rf4|Mux9~0_combout\);

-- Location: FF_X1_Y24_N15
\u_mem_rf4|registros[3][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][5]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][5]~q\);

-- Location: LCCOMB_X1_Y24_N14
\u_mem_rf4|Mux9~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|Mux9~1_combout\ = (\sel_memoria[0]~input_o\ & ((\u_mem_rf4|Mux9~0_combout\ & (\u_mem_rf4|registros[3][5]~q\)) # (!\u_mem_rf4|Mux9~0_combout\ & ((\u_mem_rf4|registros[1][5]~q\))))) # (!\sel_memoria[0]~input_o\ & (\u_mem_rf4|Mux9~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \u_mem_rf4|Mux9~0_combout\,
	datac => \u_mem_rf4|registros[3][5]~q\,
	datad => \u_mem_rf4|registros[1][5]~q\,
	combout => \u_mem_rf4|Mux9~1_combout\);

-- Location: LCCOMB_X2_Y24_N26
\bus_hex1[1]~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[1]~11_combout\ = (\modo_cons~input_o\ & (((\u_mem_rf4|Mux9~1_combout\)))) # (!\modo_cons~input_o\ & ((\u_gestor_rf5|hex1[1]~7_combout\) # ((\u_gestor_rf5|hex1[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111001010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_cons~input_o\,
	datab => \u_gestor_rf5|hex1[1]~7_combout\,
	datac => \u_gestor_rf5|hex1[1]~2_combout\,
	datad => \u_mem_rf4|Mux9~1_combout\,
	combout => \bus_hex1[1]~11_combout\);

-- Location: FF_X1_Y24_N5
\u_mem_rf4|registros[0][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_dec\(0),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][4]~q\);

-- Location: LCCOMB_X1_Y24_N28
\u_mem_rf4|registros[1][4]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][4]~feeder_combout\ = \u_mem_rf4|registros[0][4]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][4]~q\,
	combout => \u_mem_rf4|registros[1][4]~feeder_combout\);

-- Location: FF_X1_Y24_N29
\u_mem_rf4|registros[1][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][4]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][4]~q\);

-- Location: LCCOMB_X1_Y24_N30
\u_mem_rf4|registros[2][4]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][4]~feeder_combout\ = \u_mem_rf4|registros[1][4]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][4]~q\,
	combout => \u_mem_rf4|registros[2][4]~feeder_combout\);

-- Location: FF_X1_Y24_N31
\u_mem_rf4|registros[2][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][4]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][4]~q\);

-- Location: LCCOMB_X1_Y24_N4
\u_mem_rf4|Mux10~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|Mux10~0_combout\ = (\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\) # ((\u_mem_rf4|registros[1][4]~q\)))) # (!\sel_memoria[0]~input_o\ & (!\sel_memoria[1]~input_o\ & (\u_mem_rf4|registros[0][4]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[0][4]~q\,
	datad => \u_mem_rf4|registros[1][4]~q\,
	combout => \u_mem_rf4|Mux10~0_combout\);

-- Location: FF_X1_Y24_N1
\u_mem_rf4|registros[3][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][4]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][4]~q\);

-- Location: LCCOMB_X1_Y24_N0
\u_mem_rf4|Mux10~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|Mux10~1_combout\ = (\u_mem_rf4|Mux10~0_combout\ & (((\u_mem_rf4|registros[3][4]~q\) # (!\sel_memoria[1]~input_o\)))) # (!\u_mem_rf4|Mux10~0_combout\ & (\u_mem_rf4|registros[2][4]~q\ & ((\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][4]~q\,
	datab => \u_mem_rf4|Mux10~0_combout\,
	datac => \u_mem_rf4|registros[3][4]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \u_mem_rf4|Mux10~1_combout\);

-- Location: LCCOMB_X3_Y24_N16
\bus_hex1[0]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~7_combout\ = (\u_gestor_rf5|hex1[1]~0_combout\ & ((\u_gestor_rf5|color_activo\(0) & (\c_azul|dec\(0))) # (!\u_gestor_rf5|color_activo\(0) & ((\c_rojo|dec\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(0),
	datab => \c_rojo|dec\(0),
	datac => \u_gestor_rf5|color_activo\(0),
	datad => \u_gestor_rf5|hex1[1]~0_combout\,
	combout => \bus_hex1[0]~7_combout\);

-- Location: LCCOMB_X2_Y24_N4
\bus_hex1[0]~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~9_combout\ = (!\bus_hex1[2]~0_combout\ & ((\bus_hex1[0]~7_combout\) # ((\c_verde|dec\(0) & \bus_hex1[2]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_verde|dec\(0),
	datab => \bus_hex1[0]~7_combout\,
	datac => \bus_hex1[2]~0_combout\,
	datad => \bus_hex1[2]~8_combout\,
	combout => \bus_hex1[0]~9_combout\);

-- Location: LCCOMB_X3_Y24_N6
\bus_hex1[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~2_combout\ = (\sw_menu[1]~input_o\ & ((\c_azul|dec\(0)) # ((\sw_menu[2]~input_o\)))) # (!\sw_menu[1]~input_o\ & (((\c_rojo|dec\(0) & !\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|dec\(0),
	datab => \c_rojo|dec\(0),
	datac => \sw_menu[1]~input_o\,
	datad => \sw_menu[2]~input_o\,
	combout => \bus_hex1[0]~2_combout\);

-- Location: LCCOMB_X2_Y24_N12
\bus_hex1[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~3_combout\ = (\sw_menu[0]~input_o\ & ((\bus_hex1[0]~2_combout\) # ((\u_gestor_rf5|t_dec\(0) & \sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_dec\(0),
	datab => \bus_hex1[0]~2_combout\,
	datac => \sw_menu[2]~input_o\,
	datad => \sw_menu[0]~input_o\,
	combout => \bus_hex1[0]~3_combout\);

-- Location: LCCOMB_X3_Y23_N4
\bus_hex1[0]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~4_combout\ = (\sw_menu[1]~input_o\ & (!\sw_menu[2]~input_o\ & ((\c_verde|dec\(0))))) # (!\sw_menu[1]~input_o\ & (\sw_menu[2]~input_o\ & (\sel_vel[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \sw_menu[2]~input_o\,
	datac => \sel_vel[0]~input_o\,
	datad => \c_verde|dec\(0),
	combout => \bus_hex1[0]~4_combout\);

-- Location: LCCOMB_X2_Y24_N8
\bus_hex1[0]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~5_combout\ = (\bus_hex1[0]~4_combout\) # ((\c_total|dec\(0) & (\sw_menu[1]~input_o\ $ (!\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_total|dec\(0),
	datab => \sw_menu[1]~input_o\,
	datac => \sw_menu[2]~input_o\,
	datad => \bus_hex1[0]~4_combout\,
	combout => \bus_hex1[0]~5_combout\);

-- Location: LCCOMB_X2_Y24_N10
\bus_hex1[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~6_combout\ = (\bus_hex1[2]~0_combout\ & ((\bus_hex1[0]~3_combout\) # ((\bus_hex1[0]~5_combout\ & !\sw_menu[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[0]~3_combout\,
	datab => \bus_hex1[0]~5_combout\,
	datac => \bus_hex1[2]~0_combout\,
	datad => \sw_menu[0]~input_o\,
	combout => \bus_hex1[0]~6_combout\);

-- Location: LCCOMB_X2_Y24_N18
\bus_hex1[0]~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[0]~10_combout\ = (\modo_cons~input_o\ & (\u_mem_rf4|Mux10~1_combout\)) # (!\modo_cons~input_o\ & (((\bus_hex1[0]~9_combout\) # (\bus_hex1[0]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|Mux10~1_combout\,
	datab => \bus_hex1[0]~9_combout\,
	datac => \modo_cons~input_o\,
	datad => \bus_hex1[0]~6_combout\,
	combout => \bus_hex1[0]~10_combout\);

-- Location: LCCOMB_X3_Y25_N12
\bus_hex1[3]~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~27_combout\ = (\sw_menu[1]~input_o\) # (\u_gestor_rf5|t_dec\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sw_menu[1]~input_o\,
	datad => \u_gestor_rf5|t_dec\(3),
	combout => \bus_hex1[3]~27_combout\);

-- Location: LCCOMB_X3_Y25_N30
\bus_hex1[3]~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~28_combout\ = (\bus_hex1[2]~0_combout\ & (\sw_menu[0]~input_o\ & ((\bus_hex1[3]~27_combout\) # (\bus_hex1[2]~20_combout\)))) # (!\bus_hex1[2]~0_combout\ & (((\bus_hex1[2]~20_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[3]~27_combout\,
	datab => \bus_hex1[2]~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \bus_hex1[2]~20_combout\,
	combout => \bus_hex1[3]~28_combout\);

-- Location: LCCOMB_X3_Y24_N14
\bus_hex1[3]~29\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~29_combout\ = (\bus_hex1[3]~28_combout\ & ((\c_rojo|dec\(3)) # ((!\bus_hex1[2]~20_combout\)))) # (!\bus_hex1[3]~28_combout\ & (((\bus_hex1[2]~20_combout\ & \c_total|dec\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[3]~28_combout\,
	datab => \c_rojo|dec\(3),
	datac => \bus_hex1[2]~20_combout\,
	datad => \c_total|dec\(3),
	combout => \bus_hex1[3]~29_combout\);

-- Location: LCCOMB_X5_Y24_N30
\bus_hex1[3]~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~30_combout\ = (\bus_hex1[2]~17_combout\ & (((\bus_hex1[2]~14_combout\)))) # (!\bus_hex1[2]~17_combout\ & ((\bus_hex1[2]~14_combout\ & (\c_azul|dec\(3))) # (!\bus_hex1[2]~14_combout\ & ((\bus_hex1[3]~29_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \c_azul|dec\(3),
	datac => \bus_hex1[3]~29_combout\,
	datad => \bus_hex1[2]~14_combout\,
	combout => \bus_hex1[3]~30_combout\);

-- Location: LCCOMB_X4_Y25_N6
\u_mem_rf4|registros[0][7]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[0][7]~feeder_combout\ = \u_gestor_rf5|t_dec\(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_gestor_rf5|t_dec\(3),
	combout => \u_mem_rf4|registros[0][7]~feeder_combout\);

-- Location: FF_X4_Y25_N7
\u_mem_rf4|registros[0][7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[0][7]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][7]~q\);

-- Location: LCCOMB_X4_Y25_N30
\u_mem_rf4|registros[1][7]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][7]~feeder_combout\ = \u_mem_rf4|registros[0][7]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][7]~q\,
	combout => \u_mem_rf4|registros[1][7]~feeder_combout\);

-- Location: FF_X4_Y25_N31
\u_mem_rf4|registros[1][7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][7]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][7]~q\);

-- Location: FF_X4_Y25_N27
\u_mem_rf4|registros[2][7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[1][7]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][7]~q\);

-- Location: FF_X4_Y25_N13
\u_mem_rf4|registros[3][7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][7]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][7]~q\);

-- Location: LCCOMB_X4_Y25_N10
\bus_hex1[3]~31\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~31_combout\ = (\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\) # ((\u_mem_rf4|registros[2][7]~q\)))) # (!\sel_memoria[1]~input_o\ & (!\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[0][7]~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[2][7]~q\,
	datad => \u_mem_rf4|registros[0][7]~q\,
	combout => \bus_hex1[3]~31_combout\);

-- Location: LCCOMB_X4_Y25_N12
\bus_hex1[3]~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~32_combout\ = (\sel_memoria[0]~input_o\ & ((\bus_hex1[3]~31_combout\ & ((\u_mem_rf4|registros[3][7]~q\))) # (!\bus_hex1[3]~31_combout\ & (\u_mem_rf4|registros[1][7]~q\)))) # (!\sel_memoria[0]~input_o\ & (((\bus_hex1[3]~31_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[1][7]~q\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[3][7]~q\,
	datad => \bus_hex1[3]~31_combout\,
	combout => \bus_hex1[3]~32_combout\);

-- Location: LCCOMB_X5_Y24_N20
\bus_hex1[3]~33\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex1[3]~33_combout\ = (\bus_hex1[2]~17_combout\ & ((\bus_hex1[3]~30_combout\ & ((\bus_hex1[3]~32_combout\))) # (!\bus_hex1[3]~30_combout\ & (\c_verde|dec\(3))))) # (!\bus_hex1[2]~17_combout\ & (((\bus_hex1[3]~30_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \c_verde|dec\(3),
	datac => \bus_hex1[3]~30_combout\,
	datad => \bus_hex1[3]~32_combout\,
	combout => \bus_hex1[3]~33_combout\);

-- Location: LCCOMB_X23_Y28_N0
\d1|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux6~0_combout\ = (\bus_hex1[2]~26_combout\ & ((\bus_hex1[0]~10_combout\ & (!\bus_hex1[1]~11_combout\)) # (!\bus_hex1[0]~10_combout\ & ((!\bus_hex1[3]~33_combout\))))) # (!\bus_hex1[2]~26_combout\ & ((\bus_hex1[1]~11_combout\) # 
-- ((\bus_hex1[3]~33_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111010101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux6~0_combout\);

-- Location: LCCOMB_X23_Y28_N14
\d1|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux5~0_combout\ = (\bus_hex1[1]~11_combout\ & ((\bus_hex1[0]~10_combout\) # (\bus_hex1[2]~26_combout\ $ (!\bus_hex1[3]~33_combout\)))) # (!\bus_hex1[1]~11_combout\ & (\bus_hex1[0]~10_combout\ & (\bus_hex1[2]~26_combout\ $ 
-- (!\bus_hex1[3]~33_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100011010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux5~0_combout\);

-- Location: LCCOMB_X23_Y28_N24
\d1|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux4~0_combout\ = (\bus_hex1[2]~26_combout\ & ((\bus_hex1[0]~10_combout\) # (\bus_hex1[1]~11_combout\ $ (!\bus_hex1[3]~33_combout\)))) # (!\bus_hex1[2]~26_combout\ & (\bus_hex1[0]~10_combout\ & ((!\bus_hex1[3]~33_combout\) # 
-- (!\bus_hex1[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux4~0_combout\);

-- Location: LCCOMB_X23_Y28_N22
\d1|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux3~0_combout\ = (\bus_hex1[1]~11_combout\ & ((\bus_hex1[3]~33_combout\) # ((\bus_hex1[2]~26_combout\ & \bus_hex1[0]~10_combout\)))) # (!\bus_hex1[1]~11_combout\ & ((\bus_hex1[2]~26_combout\ & (\bus_hex1[0]~10_combout\ $ (!\bus_hex1[3]~33_combout\))) 
-- # (!\bus_hex1[2]~26_combout\ & (\bus_hex1[0]~10_combout\ & !\bus_hex1[3]~33_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux3~0_combout\);

-- Location: LCCOMB_X23_Y28_N8
\d1|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux2~0_combout\ = (\bus_hex1[2]~26_combout\ & (\bus_hex1[3]~33_combout\ & ((\bus_hex1[1]~11_combout\) # (\bus_hex1[0]~10_combout\)))) # (!\bus_hex1[2]~26_combout\ & (\bus_hex1[1]~11_combout\ & (\bus_hex1[0]~10_combout\ $ (!\bus_hex1[3]~33_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux2~0_combout\);

-- Location: LCCOMB_X23_Y28_N6
\d1|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux1~0_combout\ = (\bus_hex1[2]~26_combout\ & ((\bus_hex1[3]~33_combout\) # (\bus_hex1[1]~11_combout\ $ (\bus_hex1[0]~10_combout\)))) # (!\bus_hex1[2]~26_combout\ & (\bus_hex1[1]~11_combout\ & (\bus_hex1[0]~10_combout\ & \bus_hex1[3]~33_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux1~0_combout\);

-- Location: LCCOMB_X23_Y28_N12
\d1|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d1|Mux0~0_combout\ = (\bus_hex1[2]~26_combout\ & (\bus_hex1[3]~33_combout\ $ (((!\bus_hex1[1]~11_combout\ & !\bus_hex1[0]~10_combout\))))) # (!\bus_hex1[2]~26_combout\ & (\bus_hex1[0]~10_combout\ & (\bus_hex1[1]~11_combout\ $ 
-- (!\bus_hex1[3]~33_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~26_combout\,
	datab => \bus_hex1[1]~11_combout\,
	datac => \bus_hex1[0]~10_combout\,
	datad => \bus_hex1[3]~33_combout\,
	combout => \d1|Mux0~0_combout\);

-- Location: FF_X2_Y25_N19
\u_mem_rf4|registros[0][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_uni\(2),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][2]~q\);

-- Location: FF_X2_Y25_N13
\u_mem_rf4|registros[1][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[0][2]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][2]~q\);

-- Location: LCCOMB_X2_Y25_N8
\u_mem_rf4|registros[2][2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][2]~feeder_combout\ = \u_mem_rf4|registros[1][2]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][2]~q\,
	combout => \u_mem_rf4|registros[2][2]~feeder_combout\);

-- Location: FF_X2_Y25_N9
\u_mem_rf4|registros[2][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][2]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][2]~q\);

-- Location: FF_X2_Y25_N31
\u_mem_rf4|registros[3][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][2]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][2]~q\);

-- Location: LCCOMB_X2_Y25_N18
\bus_hex0[2]~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~18_combout\ = (\sel_memoria[1]~input_o\ & (\sel_memoria[0]~input_o\)) # (!\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\ & ((\u_mem_rf4|registros[1][2]~q\))) # (!\sel_memoria[0]~input_o\ & (\u_mem_rf4|registros[0][2]~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \sel_memoria[0]~input_o\,
	datac => \u_mem_rf4|registros[0][2]~q\,
	datad => \u_mem_rf4|registros[1][2]~q\,
	combout => \bus_hex0[2]~18_combout\);

-- Location: LCCOMB_X2_Y25_N30
\bus_hex0[2]~19\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~19_combout\ = (\sel_memoria[1]~input_o\ & ((\bus_hex0[2]~18_combout\ & ((\u_mem_rf4|registros[3][2]~q\))) # (!\bus_hex0[2]~18_combout\ & (\u_mem_rf4|registros[2][2]~q\)))) # (!\sel_memoria[1]~input_o\ & (((\bus_hex0[2]~18_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \u_mem_rf4|registros[2][2]~q\,
	datac => \u_mem_rf4|registros[3][2]~q\,
	datad => \bus_hex0[2]~18_combout\,
	combout => \bus_hex0[2]~19_combout\);

-- Location: LCCOMB_X4_Y24_N10
\bus_hex0[2]~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~15_combout\ = (\bus_hex1[2]~20_combout\ & (((\c_total|uni\(2))) # (!\bus_hex1[2]~1_combout\))) # (!\bus_hex1[2]~20_combout\ & (\bus_hex1[2]~1_combout\ & ((!\u_gestor_rf5|Equal11~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001011100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~20_combout\,
	datab => \bus_hex1[2]~1_combout\,
	datac => \c_total|uni\(2),
	datad => \u_gestor_rf5|Equal11~0_combout\,
	combout => \bus_hex0[2]~15_combout\);

-- Location: LCCOMB_X4_Y24_N28
\bus_hex0[2]~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~14_combout\ = (!\u_gestor_rf5|timer\(0) & (!\u_gestor_rf5|timer\(1) & ((\u_gestor_rf5|t_uni\(2)) # (\sw_menu[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_uni\(2),
	datab => \u_gestor_rf5|timer\(0),
	datac => \sw_menu[1]~input_o\,
	datad => \u_gestor_rf5|timer\(1),
	combout => \bus_hex0[2]~14_combout\);

-- Location: LCCOMB_X4_Y24_N26
\bus_hex0[2]~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~16_combout\ = (\bus_hex0[2]~15_combout\ & (((\c_rojo|uni\(2)) # (\bus_hex1[2]~1_combout\)))) # (!\bus_hex0[2]~15_combout\ & (\bus_hex0[2]~14_combout\ & ((!\bus_hex1[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~15_combout\,
	datab => \bus_hex0[2]~14_combout\,
	datac => \c_rojo|uni\(2),
	datad => \bus_hex1[2]~1_combout\,
	combout => \bus_hex0[2]~16_combout\);

-- Location: LCCOMB_X5_Y24_N8
\bus_hex0[2]~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~17_combout\ = (\bus_hex1[2]~17_combout\ & ((\bus_hex1[2]~14_combout\) # ((\c_verde|uni\(2))))) # (!\bus_hex1[2]~17_combout\ & (!\bus_hex1[2]~14_combout\ & (\bus_hex0[2]~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \bus_hex1[2]~14_combout\,
	datac => \bus_hex0[2]~16_combout\,
	datad => \c_verde|uni\(2),
	combout => \bus_hex0[2]~17_combout\);

-- Location: LCCOMB_X5_Y24_N10
\bus_hex0[2]~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[2]~20_combout\ = (\bus_hex1[2]~14_combout\ & ((\bus_hex0[2]~17_combout\ & (\bus_hex0[2]~19_combout\)) # (!\bus_hex0[2]~17_combout\ & ((\c_azul|uni\(2)))))) # (!\bus_hex1[2]~14_combout\ & (((\bus_hex0[2]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110010110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~19_combout\,
	datab => \bus_hex1[2]~14_combout\,
	datac => \bus_hex0[2]~17_combout\,
	datad => \c_azul|uni\(2),
	combout => \bus_hex0[2]~20_combout\);

-- Location: LCCOMB_X3_Y25_N20
\bus_hex0[3]~21\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~21_combout\ = (\u_gestor_rf5|t_uni\(3)) # (\sw_menu[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_gestor_rf5|t_uni\(3),
	datad => \sw_menu[1]~input_o\,
	combout => \bus_hex0[3]~21_combout\);

-- Location: LCCOMB_X3_Y25_N18
\bus_hex0[3]~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~22_combout\ = (\bus_hex1[2]~0_combout\ & (\sw_menu[0]~input_o\ & ((\bus_hex0[3]~21_combout\) # (\bus_hex1[2]~20_combout\)))) # (!\bus_hex1[2]~0_combout\ & (((\bus_hex1[2]~20_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[0]~input_o\,
	datab => \bus_hex0[3]~21_combout\,
	datac => \bus_hex1[2]~0_combout\,
	datad => \bus_hex1[2]~20_combout\,
	combout => \bus_hex0[3]~22_combout\);

-- Location: LCCOMB_X3_Y24_N0
\bus_hex0[3]~23\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~23_combout\ = (\bus_hex0[3]~22_combout\ & (((\c_rojo|uni\(3))) # (!\bus_hex1[2]~20_combout\))) # (!\bus_hex0[3]~22_combout\ & (\bus_hex1[2]~20_combout\ & ((\c_total|uni\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011010100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[3]~22_combout\,
	datab => \bus_hex1[2]~20_combout\,
	datac => \c_rojo|uni\(3),
	datad => \c_total|uni\(3),
	combout => \bus_hex0[3]~23_combout\);

-- Location: LCCOMB_X4_Y24_N22
\bus_hex0[3]~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~24_combout\ = (\bus_hex1[2]~17_combout\ & (\bus_hex1[2]~14_combout\)) # (!\bus_hex1[2]~17_combout\ & ((\bus_hex1[2]~14_combout\ & ((\c_azul|uni\(3)))) # (!\bus_hex1[2]~14_combout\ & (\bus_hex0[3]~23_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \bus_hex1[2]~14_combout\,
	datac => \bus_hex0[3]~23_combout\,
	datad => \c_azul|uni\(3),
	combout => \bus_hex0[3]~24_combout\);

-- Location: FF_X2_Y25_N29
\u_mem_rf4|registros[0][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_uni\(3),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][3]~q\);

-- Location: LCCOMB_X2_Y25_N2
\u_mem_rf4|registros[1][3]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[1][3]~feeder_combout\ = \u_mem_rf4|registros[0][3]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[0][3]~q\,
	combout => \u_mem_rf4|registros[1][3]~feeder_combout\);

-- Location: FF_X2_Y25_N3
\u_mem_rf4|registros[1][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[1][3]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][3]~q\);

-- Location: LCCOMB_X2_Y25_N14
\u_mem_rf4|registros[2][3]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][3]~feeder_combout\ = \u_mem_rf4|registros[1][3]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][3]~q\,
	combout => \u_mem_rf4|registros[2][3]~feeder_combout\);

-- Location: FF_X2_Y25_N15
\u_mem_rf4|registros[2][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][3]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][3]~q\);

-- Location: FF_X2_Y25_N23
\u_mem_rf4|registros[3][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][3]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][3]~q\);

-- Location: LCCOMB_X2_Y25_N28
\bus_hex0[3]~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~25_combout\ = (\sel_memoria[1]~input_o\ & ((\u_mem_rf4|registros[2][3]~q\) # ((\sel_memoria[0]~input_o\)))) # (!\sel_memoria[1]~input_o\ & (((\u_mem_rf4|registros[0][3]~q\ & !\sel_memoria[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[1]~input_o\,
	datab => \u_mem_rf4|registros[2][3]~q\,
	datac => \u_mem_rf4|registros[0][3]~q\,
	datad => \sel_memoria[0]~input_o\,
	combout => \bus_hex0[3]~25_combout\);

-- Location: LCCOMB_X2_Y25_N22
\bus_hex0[3]~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~26_combout\ = (\sel_memoria[0]~input_o\ & ((\bus_hex0[3]~25_combout\ & ((\u_mem_rf4|registros[3][3]~q\))) # (!\bus_hex0[3]~25_combout\ & (\u_mem_rf4|registros[1][3]~q\)))) # (!\sel_memoria[0]~input_o\ & (((\bus_hex0[3]~25_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \u_mem_rf4|registros[1][3]~q\,
	datac => \u_mem_rf4|registros[3][3]~q\,
	datad => \bus_hex0[3]~25_combout\,
	combout => \bus_hex0[3]~26_combout\);

-- Location: LCCOMB_X5_Y24_N22
\bus_hex0[3]~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[3]~27_combout\ = (\bus_hex1[2]~17_combout\ & ((\bus_hex0[3]~24_combout\ & (\bus_hex0[3]~26_combout\)) # (!\bus_hex0[3]~24_combout\ & ((\c_verde|uni\(3)))))) # (!\bus_hex1[2]~17_combout\ & (\bus_hex0[3]~24_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \bus_hex0[3]~24_combout\,
	datac => \bus_hex0[3]~26_combout\,
	datad => \c_verde|uni\(3),
	combout => \bus_hex0[3]~27_combout\);

-- Location: LCCOMB_X3_Y25_N22
\bus_hex0[1]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~7_combout\ = (\sw_menu[1]~input_o\) # (\u_gestor_rf5|t_uni\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sw_menu[1]~input_o\,
	datad => \u_gestor_rf5|t_uni\(1),
	combout => \bus_hex0[1]~7_combout\);

-- Location: LCCOMB_X3_Y25_N28
\bus_hex0[1]~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~8_combout\ = (\bus_hex1[2]~0_combout\ & (\sw_menu[0]~input_o\ & ((\bus_hex0[1]~7_combout\) # (\bus_hex1[2]~20_combout\)))) # (!\bus_hex1[2]~0_combout\ & (((\bus_hex1[2]~20_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[1]~7_combout\,
	datab => \bus_hex1[2]~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \bus_hex1[2]~20_combout\,
	combout => \bus_hex0[1]~8_combout\);

-- Location: LCCOMB_X3_Y24_N10
\bus_hex0[1]~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~9_combout\ = (\bus_hex0[1]~8_combout\ & ((\c_rojo|uni\(1)) # ((!\bus_hex1[2]~20_combout\)))) # (!\bus_hex0[1]~8_combout\ & (((\bus_hex1[2]~20_combout\ & \c_total|uni\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110010001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_rojo|uni\(1),
	datab => \bus_hex0[1]~8_combout\,
	datac => \bus_hex1[2]~20_combout\,
	datad => \c_total|uni\(1),
	combout => \bus_hex0[1]~9_combout\);

-- Location: LCCOMB_X5_Y24_N26
\bus_hex0[1]~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~10_combout\ = (\bus_hex1[2]~17_combout\ & (\bus_hex1[2]~14_combout\)) # (!\bus_hex1[2]~17_combout\ & ((\bus_hex1[2]~14_combout\ & ((\c_azul|uni\(1)))) # (!\bus_hex1[2]~14_combout\ & (\bus_hex0[1]~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \bus_hex1[2]~14_combout\,
	datac => \bus_hex0[1]~9_combout\,
	datad => \c_azul|uni\(1),
	combout => \bus_hex0[1]~10_combout\);

-- Location: FF_X1_Y24_N11
\u_mem_rf4|registros[0][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_uni\(1),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][1]~q\);

-- Location: FF_X1_Y24_N17
\u_mem_rf4|registros[1][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[0][1]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][1]~q\);

-- Location: LCCOMB_X1_Y24_N8
\u_mem_rf4|registros[2][1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][1]~feeder_combout\ = \u_mem_rf4|registros[1][1]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][1]~q\,
	combout => \u_mem_rf4|registros[2][1]~feeder_combout\);

-- Location: FF_X1_Y24_N9
\u_mem_rf4|registros[2][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][1]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][1]~q\);

-- Location: FF_X1_Y24_N7
\u_mem_rf4|registros[3][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][1]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][1]~q\);

-- Location: LCCOMB_X1_Y24_N10
\bus_hex0[1]~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~11_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\ & (\u_mem_rf4|registros[2][1]~q\)) # (!\sel_memoria[1]~input_o\ & ((\u_mem_rf4|registros[0][1]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \u_mem_rf4|registros[2][1]~q\,
	datac => \u_mem_rf4|registros[0][1]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \bus_hex0[1]~11_combout\);

-- Location: LCCOMB_X1_Y24_N6
\bus_hex0[1]~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~12_combout\ = (\sel_memoria[0]~input_o\ & ((\bus_hex0[1]~11_combout\ & ((\u_mem_rf4|registros[3][1]~q\))) # (!\bus_hex0[1]~11_combout\ & (\u_mem_rf4|registros[1][1]~q\)))) # (!\sel_memoria[0]~input_o\ & (((\bus_hex0[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \u_mem_rf4|registros[1][1]~q\,
	datac => \u_mem_rf4|registros[3][1]~q\,
	datad => \bus_hex0[1]~11_combout\,
	combout => \bus_hex0[1]~12_combout\);

-- Location: LCCOMB_X5_Y24_N16
\bus_hex0[1]~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[1]~13_combout\ = (\bus_hex1[2]~17_combout\ & ((\bus_hex0[1]~10_combout\ & ((\bus_hex0[1]~12_combout\))) # (!\bus_hex0[1]~10_combout\ & (\c_verde|uni\(1))))) # (!\bus_hex1[2]~17_combout\ & (((\bus_hex0[1]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \c_verde|uni\(1),
	datac => \bus_hex0[1]~10_combout\,
	datad => \bus_hex0[1]~12_combout\,
	combout => \bus_hex0[1]~13_combout\);

-- Location: FF_X1_Y24_N13
\u_mem_rf4|registros[0][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_gestor_rf5|t_uni\(0),
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[0][0]~q\);

-- Location: FF_X1_Y24_N3
\u_mem_rf4|registros[1][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[0][0]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[1][0]~q\);

-- Location: LCCOMB_X1_Y24_N26
\u_mem_rf4|registros[2][0]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u_mem_rf4|registros[2][0]~feeder_combout\ = \u_mem_rf4|registros[1][0]~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_mem_rf4|registros[1][0]~q\,
	combout => \u_mem_rf4|registros[2][0]~feeder_combout\);

-- Location: FF_X1_Y24_N27
\u_mem_rf4|registros[2][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \u_mem_rf4|registros[2][0]~feeder_combout\,
	clrn => \rst~input_o\,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[2][0]~q\);

-- Location: FF_X1_Y24_N25
\u_mem_rf4|registros[3][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \u_mem_rf4|registros[2][0]~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	ena => \hab_conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_mem_rf4|registros[3][0]~q\);

-- Location: LCCOMB_X1_Y24_N12
\bus_hex0[0]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~4_combout\ = (\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\) # ((\u_mem_rf4|registros[1][0]~q\)))) # (!\sel_memoria[0]~input_o\ & (!\sel_memoria[1]~input_o\ & (\u_mem_rf4|registros[0][0]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[0][0]~q\,
	datad => \u_mem_rf4|registros[1][0]~q\,
	combout => \bus_hex0[0]~4_combout\);

-- Location: LCCOMB_X1_Y24_N24
\bus_hex0[0]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~5_combout\ = (\sel_memoria[1]~input_o\ & ((\bus_hex0[0]~4_combout\ & ((\u_mem_rf4|registros[3][0]~q\))) # (!\bus_hex0[0]~4_combout\ & (\u_mem_rf4|registros[2][0]~q\)))) # (!\sel_memoria[1]~input_o\ & (((\bus_hex0[0]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_mem_rf4|registros[2][0]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \u_mem_rf4|registros[3][0]~q\,
	datad => \bus_hex0[0]~4_combout\,
	combout => \bus_hex0[0]~5_combout\);

-- Location: LCCOMB_X3_Y23_N24
\bus_hex0[0]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~0_combout\ = (!\u_gestor_rf5|timer\(1) & (!\u_gestor_rf5|timer\(0) & ((\sw_menu[1]~input_o\) # (\u_gestor_rf5|t_uni\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \u_gestor_rf5|timer\(1),
	datac => \u_gestor_rf5|timer\(0),
	datad => \u_gestor_rf5|t_uni\(0),
	combout => \bus_hex0[0]~0_combout\);

-- Location: LCCOMB_X4_Y24_N16
\bus_hex0[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~1_combout\ = (\bus_hex1[2]~20_combout\ & (((\c_total|uni\(0))) # (!\bus_hex1[2]~1_combout\))) # (!\bus_hex1[2]~20_combout\ & (\bus_hex1[2]~1_combout\ & ((!\u_gestor_rf5|Equal11~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001011100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~20_combout\,
	datab => \bus_hex1[2]~1_combout\,
	datac => \c_total|uni\(0),
	datad => \u_gestor_rf5|Equal11~0_combout\,
	combout => \bus_hex0[0]~1_combout\);

-- Location: LCCOMB_X4_Y24_N24
\bus_hex0[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~2_combout\ = (\bus_hex0[0]~1_combout\ & (((\c_rojo|uni\(0)) # (\bus_hex1[2]~1_combout\)))) # (!\bus_hex0[0]~1_combout\ & (\bus_hex0[0]~0_combout\ & ((!\bus_hex1[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[0]~0_combout\,
	datab => \bus_hex0[0]~1_combout\,
	datac => \c_rojo|uni\(0),
	datad => \bus_hex1[2]~1_combout\,
	combout => \bus_hex0[0]~2_combout\);

-- Location: LCCOMB_X5_Y24_N28
\bus_hex0[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~3_combout\ = (\bus_hex1[2]~17_combout\ & ((\bus_hex1[2]~14_combout\) # ((\c_verde|uni\(0))))) # (!\bus_hex1[2]~17_combout\ & (!\bus_hex1[2]~14_combout\ & ((\bus_hex0[0]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex1[2]~17_combout\,
	datab => \bus_hex1[2]~14_combout\,
	datac => \c_verde|uni\(0),
	datad => \bus_hex0[0]~2_combout\,
	combout => \bus_hex0[0]~3_combout\);

-- Location: LCCOMB_X5_Y24_N18
\bus_hex0[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \bus_hex0[0]~6_combout\ = (\bus_hex1[2]~14_combout\ & ((\bus_hex0[0]~3_combout\ & ((\bus_hex0[0]~5_combout\))) # (!\bus_hex0[0]~3_combout\ & (\c_azul|uni\(0))))) # (!\bus_hex1[2]~14_combout\ & (((\bus_hex0[0]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \c_azul|uni\(0),
	datab => \bus_hex1[2]~14_combout\,
	datac => \bus_hex0[0]~5_combout\,
	datad => \bus_hex0[0]~3_combout\,
	combout => \bus_hex0[0]~6_combout\);

-- Location: LCCOMB_X21_Y28_N16
\d0|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux6~0_combout\ = (\bus_hex0[2]~20_combout\ & ((\bus_hex0[0]~6_combout\ & ((!\bus_hex0[1]~13_combout\))) # (!\bus_hex0[0]~6_combout\ & (!\bus_hex0[3]~27_combout\)))) # (!\bus_hex0[2]~20_combout\ & ((\bus_hex0[3]~27_combout\) # 
-- ((\bus_hex0[1]~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111001110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux6~0_combout\);

-- Location: LCCOMB_X21_Y28_N14
\d0|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux5~0_combout\ = (\bus_hex0[1]~13_combout\ & ((\bus_hex0[0]~6_combout\) # (\bus_hex0[2]~20_combout\ $ (!\bus_hex0[3]~27_combout\)))) # (!\bus_hex0[1]~13_combout\ & (\bus_hex0[0]~6_combout\ & (\bus_hex0[2]~20_combout\ $ (!\bus_hex0[3]~27_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100110010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux5~0_combout\);

-- Location: LCCOMB_X21_Y28_N4
\d0|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux4~0_combout\ = (\bus_hex0[2]~20_combout\ & ((\bus_hex0[0]~6_combout\) # (\bus_hex0[3]~27_combout\ $ (!\bus_hex0[1]~13_combout\)))) # (!\bus_hex0[2]~20_combout\ & (\bus_hex0[0]~6_combout\ & ((!\bus_hex0[1]~13_combout\) # 
-- (!\bus_hex0[3]~27_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux4~0_combout\);

-- Location: LCCOMB_X21_Y28_N10
\d0|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux3~0_combout\ = (\bus_hex0[3]~27_combout\ & ((\bus_hex0[1]~13_combout\) # ((\bus_hex0[2]~20_combout\ & \bus_hex0[0]~6_combout\)))) # (!\bus_hex0[3]~27_combout\ & ((\bus_hex0[2]~20_combout\ & (\bus_hex0[1]~13_combout\ $ (!\bus_hex0[0]~6_combout\))) # 
-- (!\bus_hex0[2]~20_combout\ & (!\bus_hex0[1]~13_combout\ & \bus_hex0[0]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100111000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux3~0_combout\);

-- Location: LCCOMB_X21_Y28_N0
\d0|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux2~0_combout\ = (\bus_hex0[2]~20_combout\ & (\bus_hex0[3]~27_combout\ & ((\bus_hex0[1]~13_combout\) # (\bus_hex0[0]~6_combout\)))) # (!\bus_hex0[2]~20_combout\ & (\bus_hex0[1]~13_combout\ & (\bus_hex0[3]~27_combout\ $ (!\bus_hex0[0]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux2~0_combout\);

-- Location: LCCOMB_X21_Y28_N2
\d0|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux1~0_combout\ = (\bus_hex0[2]~20_combout\ & ((\bus_hex0[3]~27_combout\) # (\bus_hex0[1]~13_combout\ $ (\bus_hex0[0]~6_combout\)))) # (!\bus_hex0[2]~20_combout\ & (\bus_hex0[3]~27_combout\ & (\bus_hex0[1]~13_combout\ & \bus_hex0[0]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux1~0_combout\);

-- Location: LCCOMB_X21_Y28_N12
\d0|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \d0|Mux0~0_combout\ = (\bus_hex0[2]~20_combout\ & (\bus_hex0[3]~27_combout\ $ (((!\bus_hex0[1]~13_combout\ & !\bus_hex0[0]~6_combout\))))) # (!\bus_hex0[2]~20_combout\ & (\bus_hex0[0]~6_combout\ & (\bus_hex0[3]~27_combout\ $ (!\bus_hex0[1]~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bus_hex0[2]~20_combout\,
	datab => \bus_hex0[3]~27_combout\,
	datac => \bus_hex0[1]~13_combout\,
	datad => \bus_hex0[0]~6_combout\,
	combout => \d0|Mux0~0_combout\);

ww_leds_salida(0) <= \leds_salida[0]~output_o\;

ww_leds_salida(1) <= \leds_salida[1]~output_o\;

ww_leds_salida(2) <= \leds_salida[2]~output_o\;

ww_leds_salida(3) <= \leds_salida[3]~output_o\;

ww_leds_salida(4) <= \leds_salida[4]~output_o\;

ww_leds_salida(5) <= \leds_salida[5]~output_o\;

ww_leds_salida(6) <= \leds_salida[6]~output_o\;

ww_leds_salida(7) <= \leds_salida[7]~output_o\;

ww_led_frec <= \led_frec~output_o\;

ww_hex3(0) <= \hex3[0]~output_o\;

ww_hex3(1) <= \hex3[1]~output_o\;

ww_hex3(2) <= \hex3[2]~output_o\;

ww_hex3(3) <= \hex3[3]~output_o\;

ww_hex3(4) <= \hex3[4]~output_o\;

ww_hex3(5) <= \hex3[5]~output_o\;

ww_hex3(6) <= \hex3[6]~output_o\;

ww_hex2(0) <= \hex2[0]~output_o\;

ww_hex2(1) <= \hex2[1]~output_o\;

ww_hex2(2) <= \hex2[2]~output_o\;

ww_hex2(3) <= \hex2[3]~output_o\;

ww_hex2(4) <= \hex2[4]~output_o\;

ww_hex2(5) <= \hex2[5]~output_o\;

ww_hex2(6) <= \hex2[6]~output_o\;

ww_hex1(0) <= \hex1[0]~output_o\;

ww_hex1(1) <= \hex1[1]~output_o\;

ww_hex1(2) <= \hex1[2]~output_o\;

ww_hex1(3) <= \hex1[3]~output_o\;

ww_hex1(4) <= \hex1[4]~output_o\;

ww_hex1(5) <= \hex1[5]~output_o\;

ww_hex1(6) <= \hex1[6]~output_o\;

ww_hex0(0) <= \hex0[0]~output_o\;

ww_hex0(1) <= \hex0[1]~output_o\;

ww_hex0(2) <= \hex0[2]~output_o\;

ww_hex0(3) <= \hex0[3]~output_o\;

ww_hex0(4) <= \hex0[4]~output_o\;

ww_hex0(5) <= \hex0[5]~output_o\;

ww_hex0(6) <= \hex0[6]~output_o\;
END structure;


