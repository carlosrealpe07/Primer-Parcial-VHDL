library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;



entity SystemBeta is

	port
	
	(
		clk_50mhz   : in std_logic;
		rst         : in std_logic;
		btn_r       : in std_logic;
		btn_v       : in std_logic;
		btn_a       : in std_logic;
		sel_vel     : in std_logic_vector(1 downto 0);
		sw_tamano   : in std_logic;
		sw_menu     : in std_logic_vector(2 downto 0);
		sel_memoria : in std_logic_vector(1 downto 0);
		modo_cons   : in std_logic;
		
		leds_salida : out std_logic_vector(7 downto 0);
		led_frec    : out std_logic;
		
		hex3        : out std_logic_vector(6 downto 0);
		hex2        : out std_logic_vector(6 downto 0);
		hex1        : out std_logic_vector(6 downto 0);
		hex0        : out std_logic_vector(6 downto 0)
	);
	
end SystemBeta;



architecture arch_systembeta of SystemBeta is


	component D_FF
		port(Clock, Reset, Preset, D, EN : in std_logic; Q, Qn : out std_logic);
	end component;

	
	component divisor
		port(clk_50mhz : in std_logic; rst : in std_logic; clk_1hz : out std_logic);
	end component;

	
	component divisor_var
		port(clk_50mhz : in std_logic; rst : in std_logic; sel : in std_logic_vector(1 downto 0); clk_out : out std_logic);
	end component;

	
	component Contador
		port(clk : in std_logic; reset : in std_logic; enable : in std_logic; count : out std_logic_vector(7 downto 0));
	end component;

	
	component direccionamiento_rf3
		port(clk : in std_logic; rst : in std_logic; pulso_captura : in std_logic; pieza_valida : in std_logic; tamano : in std_logic; color : in std_logic_vector(1 downto 0); leds_compuertas : out std_logic_vector(7 downto 0));
	end component;

	
	component memoria_rf4
		port(clk_sistema : in std_logic; rst : in std_logic; guardar_dato : in std_logic; color_pieza : in std_logic_vector(1 downto 0); tamano_pieza : in std_logic; in_t_cen : in std_logic_vector(3 downto 0); in_t_dec : in std_logic_vector(3 downto 0); in_t_uni : in std_logic_vector(3 downto 0); modo_consulta : in std_logic; sel_memoria : in std_logic_vector(1 downto 0); salida_color : out std_logic_vector(1 downto 0); salida_tamano : out std_logic; salida_cen : out std_logic_vector(3 downto 0); salida_dec : out std_logic_vector(3 downto 0); salida_uni : out std_logic_vector(3 downto 0));
	end component;

	
	component gestor_visual_rf5
		port(clk : in std_logic; rst : in std_logic; clk_1hz : in std_logic; pulso_valido : in std_logic; pausa : in std_logic; cod_color : in std_logic_vector(1 downto 0); sw_menu : in std_logic_vector(2 downto 0); datos_total : in std_logic_vector(7 downto 0); datos_r : in std_logic_vector(7 downto 0); datos_v : in std_logic_vector(7 downto 0); datos_a : in std_logic_vector(7 downto 0); velocidad_linea : in std_logic_vector(3 downto 0); out_t_cen : out std_logic_vector(3 downto 0); out_t_dec : out std_logic_vector(3 downto 0); out_t_uni : out std_logic_vector(3 downto 0); hex3 : out std_logic_vector(3 downto 0); hex2 : out std_logic_vector(3 downto 0); hex1 : out std_logic_vector(3 downto 0); hex0 : out std_logic_vector(3 downto 0));
	end component;

	
	component deco7seg_4bits
		port(a : in std_logic_vector(3 downto 0); d : out std_logic_vector(6 downto 0));
	end component;

	
	signal clk_1hz, clk_transp : std_logic;
	signal pulso_r, pulso_v, pulso_a : std_logic;
	signal trampa, pulso_cualquiera, hab_conteo, valida_color, sys_pausa : std_logic;
	signal cod_color : std_logic_vector(1 downto 0);

	signal cnt_r_u, cnt_v_u, cnt_a_u, cnt_tot_u : std_logic_vector(7 downto 0);
	
	signal bus_tot, bus_r, bus_v, bus_a : std_logic_vector(7 downto 0);
	signal bus_vel : std_logic_vector(3 downto 0);

	signal gestor_h3, gestor_h2, gestor_h1, gestor_h0 : std_logic_vector(3 downto 0);
	
	signal time_cen, time_dec, time_uni : std_logic_vector(3 downto 0);
	
	signal mem_color : std_logic_vector(1 downto 0);
	signal mem_tamano: std_logic;
	signal mem_cen, mem_dec, mem_uni : std_logic_vector(3 downto 0);

	signal bus_hex3, bus_hex2, bus_hex1, bus_hex0 : std_logic_vector(3 downto 0);
	signal leds_mecanismo : std_logic_vector(7 downto 0);

begin

	sinc_r : D_FF port map (clock => clk_50mhz, reset => rst, preset => '1', d => btn_r, en => '1', q => pulso_r, qn => open);
	sinc_v : D_FF port map (clock => clk_50mhz, reset => rst, preset => '1', d => btn_v, en => '1', q => pulso_v, qn => open);
	sinc_a : D_FF port map (clock => clk_50mhz, reset => rst, preset => '1', d => btn_a, en => '1', q => pulso_a, qn => open);

	u_div_rtc : divisor port map (clk_50mhz => clk_50mhz, rst => rst, clk_1hz => clk_1hz);
	u_div_var : divisor_var port map (clk_50mhz => clk_50mhz, rst => rst, sel => sel_vel, clk_out => clk_transp);

	sys_pausa <= '1' when sw_menu = "110" else '0';
	led_frec <= clk_transp when sys_pausa = '0' else '0';

	trampa <= '1' when (btn_r = '0' and btn_v = '0') or (btn_r = '0' and btn_a = '0') or (btn_v = '0' and btn_a = '0') else '0';
	pulso_cualquiera <= pulso_r or pulso_v or pulso_a;

	cod_color <= "00" when trampa = '1' else
	             "01" when pulso_r = '1' else
	             "10" when pulso_v = '1' else
	             "11" when pulso_a = '1' else "00";

	valida_color <= '1' when cod_color /= "00" else '0';
	
	hab_conteo <= pulso_cualquiera and valida_color and (not sys_pausa);

	c_rojo  : Contador port map (clk => clk_50mhz, reset => rst, enable => pulso_r and hab_conteo, count => cnt_r_u);
	c_verde : Contador port map (clk => clk_50mhz, reset => rst, enable => pulso_v and hab_conteo, count => cnt_v_u);
	c_azul  : Contador port map (clk => clk_50mhz, reset => rst, enable => pulso_a and hab_conteo, count => cnt_a_u);
	c_total : Contador port map (clk => clk_50mhz, reset => rst, enable => pulso_cualquiera and hab_conteo, count => cnt_tot_u);


	bus_r   <= cnt_r_u; 
	bus_v   <= cnt_v_u;
	bus_a   <= cnt_a_u; 
	bus_tot <= cnt_tot_u;
	
	bus_vel <= "00" & sel_vel;

	u_dir_rf3 : direccionamiento_rf3
	port map (clk => clk_50mhz, rst => rst, pulso_captura => pulso_cualquiera, pieza_valida => valida_color, tamano => sw_tamano, color => cod_color, leds_compuertas => leds_mecanismo);

	u_gestor_rf5 : gestor_visual_rf5
	port map (clk => clk_50mhz, rst => rst, clk_1hz => clk_1hz, pulso_valido => hab_conteo, pausa => sys_pausa, cod_color => cod_color, sw_menu => sw_menu, datos_total => bus_tot, datos_r => bus_r, datos_v => bus_v, datos_a => bus_a, velocidad_linea => bus_vel, out_t_cen => time_cen, out_t_dec => time_dec, out_t_uni => time_uni, hex3 => gestor_h3, hex2 => gestor_h2, hex1 => gestor_h1, hex0 => gestor_h0);

	u_mem_rf4 : memoria_rf4
	port map (clk_sistema => clk_50mhz, rst => rst, guardar_dato => hab_conteo, color_pieza => cod_color, tamano_pieza => sw_tamano, in_t_cen => time_cen, in_t_dec => time_dec, in_t_uni => time_uni, modo_consulta => modo_cons, sel_memoria => sel_memoria, salida_color => mem_color, salida_tamano => mem_tamano, salida_cen => mem_cen, salida_dec => mem_dec, salida_uni => mem_uni);

	process(modo_cons, gestor_h3, gestor_h2, gestor_h1, gestor_h0, mem_color, mem_tamano, mem_cen, mem_dec, mem_uni, leds_mecanismo)
	begin
		if (modo_cons = '1') then
			if (mem_color = "01") then bus_hex3 <= "1011";
			elsif (mem_color = "10") then bus_hex3 <= "1100";
			elsif (mem_color = "11") then bus_hex3 <= "1010";
			else bus_hex3 <= "1111"; 
			end if;
			
			bus_hex2 <= mem_cen;
			bus_hex1 <= mem_dec;
			bus_hex0 <= mem_uni;
			
			leds_salida <= "00000000";
			
			if (mem_color = "01") then leds_salida(5) <= '1';
			elsif (mem_color = "10") then leds_salida(6) <= '1';
			elsif (mem_color = "11") then leds_salida(7) <= '1';
			end if;
			
			if (mem_tamano = '1') then leds_salida(1) <= '1';
			else leds_salida(0) <= '1';
			end if;
		else
			bus_hex3 <= gestor_h3;
			bus_hex2 <= gestor_h2;
			bus_hex1 <= gestor_h1;
			bus_hex0 <= gestor_h0;
			
			leds_salida <= leds_mecanismo;
		end if;
		
	end process;

	d3 : deco7seg_4bits port map (a => bus_hex3, d => hex3);
	d2 : deco7seg_4bits port map (a => bus_hex2, d => hex2);
	d1 : deco7seg_4bits port map (a => bus_hex1, d => hex1);
	d0 : deco7seg_4bits port map (a => bus_hex0, d => hex0);

	
end arch_systembeta;