-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/15/2026 21:39:56"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	divisor_var IS
    PORT (
	clk_50mhz : IN std_logic;
	sel : IN std_logic_vector(1 DOWNTO 0);
	clk_out : OUT std_logic
	);
END divisor_var;

-- Design Ports Information
-- clk_out	=>  Location: PIN_M22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[0]	=>  Location: PIN_N17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[1]	=>  Location: PIN_N20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_50mhz	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF divisor_var IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_50mhz : std_logic;
SIGNAL ww_sel : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_clk_out : std_logic;
SIGNAL \clk_50mhz~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk_out~output_o\ : std_logic;
SIGNAL \clk_50mhz~input_o\ : std_logic;
SIGNAL \clk_50mhz~inputclkctrl_outclk\ : std_logic;
SIGNAL \sel[1]~input_o\ : std_logic;
SIGNAL \sel[0]~input_o\ : std_logic;
SIGNAL \conteo[0]~26_combout\ : std_logic;
SIGNAL \conteo[0]~27\ : std_logic;
SIGNAL \conteo[1]~28_combout\ : std_logic;
SIGNAL \conteo[1]~29\ : std_logic;
SIGNAL \conteo[2]~30_combout\ : std_logic;
SIGNAL \conteo[2]~31\ : std_logic;
SIGNAL \conteo[3]~32_combout\ : std_logic;
SIGNAL \conteo[3]~33\ : std_logic;
SIGNAL \conteo[4]~34_combout\ : std_logic;
SIGNAL \conteo[4]~35\ : std_logic;
SIGNAL \conteo[5]~36_combout\ : std_logic;
SIGNAL \conteo[5]~37\ : std_logic;
SIGNAL \conteo[6]~38_combout\ : std_logic;
SIGNAL \conteo[6]~39\ : std_logic;
SIGNAL \conteo[7]~40_combout\ : std_logic;
SIGNAL \conteo[7]~41\ : std_logic;
SIGNAL \conteo[8]~42_combout\ : std_logic;
SIGNAL \conteo[8]~43\ : std_logic;
SIGNAL \conteo[9]~44_combout\ : std_logic;
SIGNAL \conteo[9]~45\ : std_logic;
SIGNAL \conteo[10]~46_combout\ : std_logic;
SIGNAL \conteo[10]~47\ : std_logic;
SIGNAL \conteo[11]~48_combout\ : std_logic;
SIGNAL \conteo[11]~49\ : std_logic;
SIGNAL \conteo[12]~50_combout\ : std_logic;
SIGNAL \conteo[12]~51\ : std_logic;
SIGNAL \conteo[13]~52_combout\ : std_logic;
SIGNAL \conteo[13]~53\ : std_logic;
SIGNAL \conteo[14]~54_combout\ : std_logic;
SIGNAL \conteo[14]~55\ : std_logic;
SIGNAL \conteo[15]~56_combout\ : std_logic;
SIGNAL \conteo[15]~57\ : std_logic;
SIGNAL \conteo[16]~58_combout\ : std_logic;
SIGNAL \conteo[16]~59\ : std_logic;
SIGNAL \conteo[17]~60_combout\ : std_logic;
SIGNAL \conteo[17]~61\ : std_logic;
SIGNAL \conteo[18]~62_combout\ : std_logic;
SIGNAL \conteo[18]~63\ : std_logic;
SIGNAL \conteo[19]~64_combout\ : std_logic;
SIGNAL \conteo[19]~65\ : std_logic;
SIGNAL \conteo[20]~66_combout\ : std_logic;
SIGNAL \conteo[20]~67\ : std_logic;
SIGNAL \conteo[21]~68_combout\ : std_logic;
SIGNAL \conteo[21]~69\ : std_logic;
SIGNAL \conteo[22]~70_combout\ : std_logic;
SIGNAL \conteo[22]~71\ : std_logic;
SIGNAL \conteo[23]~72_combout\ : std_logic;
SIGNAL \conteo[23]~73\ : std_logic;
SIGNAL \conteo[24]~74_combout\ : std_logic;
SIGNAL \conteo[24]~75\ : std_logic;
SIGNAL \conteo[25]~76_combout\ : std_logic;
SIGNAL \LessThan0~1_combout\ : std_logic;
SIGNAL \LessThan0~0_combout\ : std_logic;
SIGNAL \LessThan0~2_combout\ : std_logic;
SIGNAL \LessThan0~21_combout\ : std_logic;
SIGNAL \LessThan0~22_combout\ : std_logic;
SIGNAL \LessThan0~20_combout\ : std_logic;
SIGNAL \LessThan0~23_combout\ : std_logic;
SIGNAL \LessThan0~18_combout\ : std_logic;
SIGNAL \LessThan0~19_combout\ : std_logic;
SIGNAL \LessThan0~24_combout\ : std_logic;
SIGNAL \LessThan0~26_combout\ : std_logic;
SIGNAL \LessThan0~11_combout\ : std_logic;
SIGNAL \LessThan0~3_combout\ : std_logic;
SIGNAL \LessThan0~4_combout\ : std_logic;
SIGNAL \LessThan0~5_combout\ : std_logic;
SIGNAL \LessThan0~6_combout\ : std_logic;
SIGNAL \LessThan0~7_combout\ : std_logic;
SIGNAL \LessThan0~8_combout\ : std_logic;
SIGNAL \LessThan0~9_combout\ : std_logic;
SIGNAL \LessThan0~10_combout\ : std_logic;
SIGNAL \LessThan0~12_combout\ : std_logic;
SIGNAL \LessThan0~15_combout\ : std_logic;
SIGNAL \LessThan0~13_combout\ : std_logic;
SIGNAL \LessThan0~14_combout\ : std_logic;
SIGNAL \LessThan0~16_combout\ : std_logic;
SIGNAL \LessThan0~28_combout\ : std_logic;
SIGNAL \LessThan0~29_combout\ : std_logic;
SIGNAL \LessThan0~17_combout\ : std_logic;
SIGNAL \LessThan0~27_combout\ : std_logic;
SIGNAL \LessThan0~25_combout\ : std_logic;
SIGNAL \estado~0_combout\ : std_logic;
SIGNAL \estado~q\ : std_logic;
SIGNAL conteo : std_logic_vector(25 DOWNTO 0);
SIGNAL \ALT_INV_LessThan0~25_combout\ : std_logic;

BEGIN

ww_clk_50mhz <= clk_50mhz;
ww_sel <= sel;
clk_out <= ww_clk_out;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk_50mhz~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk_50mhz~input_o\);
\ALT_INV_LessThan0~25_combout\ <= NOT \LessThan0~25_combout\;

-- Location: IOOBUF_X41_Y13_N2
\clk_out~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \estado~q\,
	devoe => ww_devoe,
	o => \clk_out~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\clk_50mhz~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_50mhz,
	o => \clk_50mhz~input_o\);

-- Location: CLKCTRL_G4
\clk_50mhz~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk_50mhz~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk_50mhz~inputclkctrl_outclk\);

-- Location: IOIBUF_X41_Y12_N15
\sel[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel(1),
	o => \sel[1]~input_o\);

-- Location: IOIBUF_X41_Y12_N1
\sel[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel(0),
	o => \sel[0]~input_o\);

-- Location: LCCOMB_X29_Y13_N6
\conteo[0]~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[0]~26_combout\ = conteo(0) $ (VCC)
-- \conteo[0]~27\ = CARRY(conteo(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(0),
	datad => VCC,
	combout => \conteo[0]~26_combout\,
	cout => \conteo[0]~27\);

-- Location: FF_X29_Y13_N7
\conteo[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[0]~26_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(0));

-- Location: LCCOMB_X29_Y13_N8
\conteo[1]~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[1]~28_combout\ = (conteo(1) & (!\conteo[0]~27\)) # (!conteo(1) & ((\conteo[0]~27\) # (GND)))
-- \conteo[1]~29\ = CARRY((!\conteo[0]~27\) # (!conteo(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(1),
	datad => VCC,
	cin => \conteo[0]~27\,
	combout => \conteo[1]~28_combout\,
	cout => \conteo[1]~29\);

-- Location: FF_X29_Y13_N9
\conteo[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[1]~28_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(1));

-- Location: LCCOMB_X29_Y13_N10
\conteo[2]~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[2]~30_combout\ = (conteo(2) & (\conteo[1]~29\ $ (GND))) # (!conteo(2) & (!\conteo[1]~29\ & VCC))
-- \conteo[2]~31\ = CARRY((conteo(2) & !\conteo[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(2),
	datad => VCC,
	cin => \conteo[1]~29\,
	combout => \conteo[2]~30_combout\,
	cout => \conteo[2]~31\);

-- Location: FF_X29_Y13_N11
\conteo[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[2]~30_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(2));

-- Location: LCCOMB_X29_Y13_N12
\conteo[3]~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[3]~32_combout\ = (conteo(3) & (!\conteo[2]~31\)) # (!conteo(3) & ((\conteo[2]~31\) # (GND)))
-- \conteo[3]~33\ = CARRY((!\conteo[2]~31\) # (!conteo(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(3),
	datad => VCC,
	cin => \conteo[2]~31\,
	combout => \conteo[3]~32_combout\,
	cout => \conteo[3]~33\);

-- Location: FF_X29_Y13_N13
\conteo[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[3]~32_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(3));

-- Location: LCCOMB_X29_Y13_N14
\conteo[4]~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[4]~34_combout\ = (conteo(4) & (\conteo[3]~33\ $ (GND))) # (!conteo(4) & (!\conteo[3]~33\ & VCC))
-- \conteo[4]~35\ = CARRY((conteo(4) & !\conteo[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(4),
	datad => VCC,
	cin => \conteo[3]~33\,
	combout => \conteo[4]~34_combout\,
	cout => \conteo[4]~35\);

-- Location: FF_X29_Y13_N15
\conteo[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[4]~34_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(4));

-- Location: LCCOMB_X29_Y13_N16
\conteo[5]~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[5]~36_combout\ = (conteo(5) & (!\conteo[4]~35\)) # (!conteo(5) & ((\conteo[4]~35\) # (GND)))
-- \conteo[5]~37\ = CARRY((!\conteo[4]~35\) # (!conteo(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(5),
	datad => VCC,
	cin => \conteo[4]~35\,
	combout => \conteo[5]~36_combout\,
	cout => \conteo[5]~37\);

-- Location: FF_X29_Y13_N17
\conteo[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[5]~36_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(5));

-- Location: LCCOMB_X29_Y13_N18
\conteo[6]~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[6]~38_combout\ = (conteo(6) & (\conteo[5]~37\ $ (GND))) # (!conteo(6) & (!\conteo[5]~37\ & VCC))
-- \conteo[6]~39\ = CARRY((conteo(6) & !\conteo[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(6),
	datad => VCC,
	cin => \conteo[5]~37\,
	combout => \conteo[6]~38_combout\,
	cout => \conteo[6]~39\);

-- Location: FF_X29_Y13_N19
\conteo[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[6]~38_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(6));

-- Location: LCCOMB_X29_Y13_N20
\conteo[7]~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[7]~40_combout\ = (conteo(7) & (!\conteo[6]~39\)) # (!conteo(7) & ((\conteo[6]~39\) # (GND)))
-- \conteo[7]~41\ = CARRY((!\conteo[6]~39\) # (!conteo(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(7),
	datad => VCC,
	cin => \conteo[6]~39\,
	combout => \conteo[7]~40_combout\,
	cout => \conteo[7]~41\);

-- Location: FF_X29_Y13_N21
\conteo[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[7]~40_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(7));

-- Location: LCCOMB_X29_Y13_N22
\conteo[8]~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[8]~42_combout\ = (conteo(8) & (\conteo[7]~41\ $ (GND))) # (!conteo(8) & (!\conteo[7]~41\ & VCC))
-- \conteo[8]~43\ = CARRY((conteo(8) & !\conteo[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(8),
	datad => VCC,
	cin => \conteo[7]~41\,
	combout => \conteo[8]~42_combout\,
	cout => \conteo[8]~43\);

-- Location: FF_X29_Y13_N23
\conteo[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[8]~42_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(8));

-- Location: LCCOMB_X29_Y13_N24
\conteo[9]~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[9]~44_combout\ = (conteo(9) & (!\conteo[8]~43\)) # (!conteo(9) & ((\conteo[8]~43\) # (GND)))
-- \conteo[9]~45\ = CARRY((!\conteo[8]~43\) # (!conteo(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(9),
	datad => VCC,
	cin => \conteo[8]~43\,
	combout => \conteo[9]~44_combout\,
	cout => \conteo[9]~45\);

-- Location: FF_X29_Y13_N25
\conteo[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[9]~44_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(9));

-- Location: LCCOMB_X29_Y13_N26
\conteo[10]~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[10]~46_combout\ = (conteo(10) & (\conteo[9]~45\ $ (GND))) # (!conteo(10) & (!\conteo[9]~45\ & VCC))
-- \conteo[10]~47\ = CARRY((conteo(10) & !\conteo[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(10),
	datad => VCC,
	cin => \conteo[9]~45\,
	combout => \conteo[10]~46_combout\,
	cout => \conteo[10]~47\);

-- Location: FF_X29_Y13_N27
\conteo[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[10]~46_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(10));

-- Location: LCCOMB_X29_Y13_N28
\conteo[11]~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[11]~48_combout\ = (conteo(11) & (!\conteo[10]~47\)) # (!conteo(11) & ((\conteo[10]~47\) # (GND)))
-- \conteo[11]~49\ = CARRY((!\conteo[10]~47\) # (!conteo(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(11),
	datad => VCC,
	cin => \conteo[10]~47\,
	combout => \conteo[11]~48_combout\,
	cout => \conteo[11]~49\);

-- Location: FF_X29_Y13_N29
\conteo[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[11]~48_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(11));

-- Location: LCCOMB_X29_Y13_N30
\conteo[12]~50\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[12]~50_combout\ = (conteo(12) & (\conteo[11]~49\ $ (GND))) # (!conteo(12) & (!\conteo[11]~49\ & VCC))
-- \conteo[12]~51\ = CARRY((conteo(12) & !\conteo[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(12),
	datad => VCC,
	cin => \conteo[11]~49\,
	combout => \conteo[12]~50_combout\,
	cout => \conteo[12]~51\);

-- Location: FF_X29_Y13_N31
\conteo[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[12]~50_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(12));

-- Location: LCCOMB_X29_Y12_N0
\conteo[13]~52\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[13]~52_combout\ = (conteo(13) & (!\conteo[12]~51\)) # (!conteo(13) & ((\conteo[12]~51\) # (GND)))
-- \conteo[13]~53\ = CARRY((!\conteo[12]~51\) # (!conteo(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(13),
	datad => VCC,
	cin => \conteo[12]~51\,
	combout => \conteo[13]~52_combout\,
	cout => \conteo[13]~53\);

-- Location: FF_X29_Y12_N1
\conteo[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[13]~52_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(13));

-- Location: LCCOMB_X29_Y12_N2
\conteo[14]~54\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[14]~54_combout\ = (conteo(14) & (\conteo[13]~53\ $ (GND))) # (!conteo(14) & (!\conteo[13]~53\ & VCC))
-- \conteo[14]~55\ = CARRY((conteo(14) & !\conteo[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(14),
	datad => VCC,
	cin => \conteo[13]~53\,
	combout => \conteo[14]~54_combout\,
	cout => \conteo[14]~55\);

-- Location: FF_X30_Y13_N17
\conteo[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \conteo[14]~54_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(14));

-- Location: LCCOMB_X29_Y12_N4
\conteo[15]~56\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[15]~56_combout\ = (conteo(15) & (!\conteo[14]~55\)) # (!conteo(15) & ((\conteo[14]~55\) # (GND)))
-- \conteo[15]~57\ = CARRY((!\conteo[14]~55\) # (!conteo(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(15),
	datad => VCC,
	cin => \conteo[14]~55\,
	combout => \conteo[15]~56_combout\,
	cout => \conteo[15]~57\);

-- Location: FF_X30_Y13_N21
\conteo[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \conteo[15]~56_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(15));

-- Location: LCCOMB_X29_Y12_N6
\conteo[16]~58\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[16]~58_combout\ = (conteo(16) & (\conteo[15]~57\ $ (GND))) # (!conteo(16) & (!\conteo[15]~57\ & VCC))
-- \conteo[16]~59\ = CARRY((conteo(16) & !\conteo[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(16),
	datad => VCC,
	cin => \conteo[15]~57\,
	combout => \conteo[16]~58_combout\,
	cout => \conteo[16]~59\);

-- Location: FF_X30_Y13_N31
\conteo[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \conteo[16]~58_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(16));

-- Location: LCCOMB_X29_Y12_N8
\conteo[17]~60\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[17]~60_combout\ = (conteo(17) & (!\conteo[16]~59\)) # (!conteo(17) & ((\conteo[16]~59\) # (GND)))
-- \conteo[17]~61\ = CARRY((!\conteo[16]~59\) # (!conteo(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(17),
	datad => VCC,
	cin => \conteo[16]~59\,
	combout => \conteo[17]~60_combout\,
	cout => \conteo[17]~61\);

-- Location: FF_X29_Y12_N9
\conteo[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[17]~60_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(17));

-- Location: LCCOMB_X29_Y12_N10
\conteo[18]~62\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[18]~62_combout\ = (conteo(18) & (\conteo[17]~61\ $ (GND))) # (!conteo(18) & (!\conteo[17]~61\ & VCC))
-- \conteo[18]~63\ = CARRY((conteo(18) & !\conteo[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(18),
	datad => VCC,
	cin => \conteo[17]~61\,
	combout => \conteo[18]~62_combout\,
	cout => \conteo[18]~63\);

-- Location: FF_X29_Y12_N11
\conteo[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[18]~62_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(18));

-- Location: LCCOMB_X29_Y12_N12
\conteo[19]~64\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[19]~64_combout\ = (conteo(19) & (!\conteo[18]~63\)) # (!conteo(19) & ((\conteo[18]~63\) # (GND)))
-- \conteo[19]~65\ = CARRY((!\conteo[18]~63\) # (!conteo(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(19),
	datad => VCC,
	cin => \conteo[18]~63\,
	combout => \conteo[19]~64_combout\,
	cout => \conteo[19]~65\);

-- Location: FF_X29_Y12_N13
\conteo[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[19]~64_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(19));

-- Location: LCCOMB_X29_Y12_N14
\conteo[20]~66\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[20]~66_combout\ = (conteo(20) & (\conteo[19]~65\ $ (GND))) # (!conteo(20) & (!\conteo[19]~65\ & VCC))
-- \conteo[20]~67\ = CARRY((conteo(20) & !\conteo[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(20),
	datad => VCC,
	cin => \conteo[19]~65\,
	combout => \conteo[20]~66_combout\,
	cout => \conteo[20]~67\);

-- Location: FF_X29_Y12_N15
\conteo[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[20]~66_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(20));

-- Location: LCCOMB_X29_Y12_N16
\conteo[21]~68\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[21]~68_combout\ = (conteo(21) & (!\conteo[20]~67\)) # (!conteo(21) & ((\conteo[20]~67\) # (GND)))
-- \conteo[21]~69\ = CARRY((!\conteo[20]~67\) # (!conteo(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(21),
	datad => VCC,
	cin => \conteo[20]~67\,
	combout => \conteo[21]~68_combout\,
	cout => \conteo[21]~69\);

-- Location: FF_X29_Y12_N17
\conteo[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[21]~68_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(21));

-- Location: LCCOMB_X29_Y12_N18
\conteo[22]~70\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[22]~70_combout\ = (conteo(22) & (\conteo[21]~69\ $ (GND))) # (!conteo(22) & (!\conteo[21]~69\ & VCC))
-- \conteo[22]~71\ = CARRY((conteo(22) & !\conteo[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(22),
	datad => VCC,
	cin => \conteo[21]~69\,
	combout => \conteo[22]~70_combout\,
	cout => \conteo[22]~71\);

-- Location: FF_X29_Y12_N19
\conteo[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[22]~70_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(22));

-- Location: LCCOMB_X29_Y12_N20
\conteo[23]~72\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[23]~72_combout\ = (conteo(23) & (!\conteo[22]~71\)) # (!conteo(23) & ((\conteo[22]~71\) # (GND)))
-- \conteo[23]~73\ = CARRY((!\conteo[22]~71\) # (!conteo(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => conteo(23),
	datad => VCC,
	cin => \conteo[22]~71\,
	combout => \conteo[23]~72_combout\,
	cout => \conteo[23]~73\);

-- Location: FF_X28_Y13_N29
\conteo[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	asdata => \conteo[23]~72_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(23));

-- Location: LCCOMB_X29_Y12_N22
\conteo[24]~74\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[24]~74_combout\ = (conteo(24) & (\conteo[23]~73\ $ (GND))) # (!conteo(24) & (!\conteo[23]~73\ & VCC))
-- \conteo[24]~75\ = CARRY((conteo(24) & !\conteo[23]~73\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => conteo(24),
	datad => VCC,
	cin => \conteo[23]~73\,
	combout => \conteo[24]~74_combout\,
	cout => \conteo[24]~75\);

-- Location: FF_X29_Y12_N23
\conteo[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[24]~74_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(24));

-- Location: LCCOMB_X29_Y12_N24
\conteo[25]~76\ : cycloneiii_lcell_comb
-- Equation(s):
-- \conteo[25]~76_combout\ = \conteo[24]~75\ $ (conteo(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => conteo(25),
	cin => \conteo[24]~75\,
	combout => \conteo[25]~76_combout\);

-- Location: FF_X29_Y12_N25
\conteo[25]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \conteo[25]~76_combout\,
	sclr => \ALT_INV_LessThan0~25_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => conteo(25));

-- Location: LCCOMB_X28_Y13_N0
\LessThan0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~1_combout\ = (\sel[1]~input_o\ & (!conteo(24) & (\sel[0]~input_o\ $ (!conteo(25))))) # (!\sel[1]~input_o\ & (!conteo(25) & (\sel[0]~input_o\ $ (!conteo(24)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010010000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => \sel[0]~input_o\,
	datac => conteo(25),
	datad => conteo(24),
	combout => \LessThan0~1_combout\);

-- Location: LCCOMB_X28_Y13_N18
\LessThan0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~0_combout\ = (\sel[0]~input_o\ & (!conteo(25) & ((\sel[1]~input_o\) # (!conteo(24)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => \sel[0]~input_o\,
	datac => conteo(25),
	datad => conteo(24),
	combout => \LessThan0~0_combout\);

-- Location: LCCOMB_X28_Y13_N2
\LessThan0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~2_combout\ = (\sel[1]~input_o\ & (conteo(22) & (conteo(23) $ (!\sel[0]~input_o\)))) # (!\sel[1]~input_o\ & ((conteo(23) & (!\sel[0]~input_o\ & !conteo(22))) # (!conteo(23) & (\sel[0]~input_o\ & conteo(22)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001001000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => conteo(23),
	datac => \sel[0]~input_o\,
	datad => conteo(22),
	combout => \LessThan0~2_combout\);

-- Location: LCCOMB_X28_Y13_N12
\LessThan0~21\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~21_combout\ = (\sel[1]~input_o\ & (!\sel[0]~input_o\)) # (!\sel[1]~input_o\ & ((\sel[0]~input_o\) # (conteo(22))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111101011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datac => \sel[0]~input_o\,
	datad => conteo(22),
	combout => \LessThan0~21_combout\);

-- Location: LCCOMB_X29_Y12_N28
\LessThan0~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~22_combout\ = (\sel[0]~input_o\ & (conteo(22) & ((\sel[1]~input_o\) # (conteo(18))))) # (!\sel[0]~input_o\ & (conteo(18) & (conteo(22) $ (!\sel[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[0]~input_o\,
	datab => conteo(22),
	datac => \sel[1]~input_o\,
	datad => conteo(18),
	combout => \LessThan0~22_combout\);

-- Location: LCCOMB_X29_Y12_N30
\LessThan0~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~20_combout\ = (conteo(20) & conteo(21))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => conteo(20),
	datad => conteo(21),
	combout => \LessThan0~20_combout\);

-- Location: LCCOMB_X28_Y13_N30
\LessThan0~23\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~23_combout\ = (\LessThan0~21_combout\ & (!conteo(23) & ((!\LessThan0~20_combout\) # (!\LessThan0~22_combout\)))) # (!\LessThan0~21_combout\ & (((!\LessThan0~20_combout\) # (!\LessThan0~22_combout\)) # (!conteo(23))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001011101110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~21_combout\,
	datab => conteo(23),
	datac => \LessThan0~22_combout\,
	datad => \LessThan0~20_combout\,
	combout => \LessThan0~23_combout\);

-- Location: LCCOMB_X28_Y13_N8
\LessThan0~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~18_combout\ = (\sel[0]~input_o\ & (\sel[1]~input_o\ & (conteo(23) & !conteo(18)))) # (!\sel[0]~input_o\ & (conteo(18) & (\sel[1]~input_o\ $ (conteo(23)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => conteo(23),
	datac => \sel[0]~input_o\,
	datad => conteo(18),
	combout => \LessThan0~18_combout\);

-- Location: LCCOMB_X28_Y13_N6
\LessThan0~19\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~19_combout\ = (\LessThan0~18_combout\ & (!conteo(17) & (\sel[1]~input_o\ $ (!conteo(22)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => conteo(22),
	datac => \LessThan0~18_combout\,
	datad => conteo(17),
	combout => \LessThan0~19_combout\);

-- Location: LCCOMB_X28_Y13_N4
\LessThan0~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~24_combout\ = (\LessThan0~23_combout\) # ((\LessThan0~19_combout\) # ((!conteo(19) & \LessThan0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(19),
	datab => \LessThan0~2_combout\,
	datac => \LessThan0~23_combout\,
	datad => \LessThan0~19_combout\,
	combout => \LessThan0~24_combout\);

-- Location: LCCOMB_X29_Y12_N26
\LessThan0~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~26_combout\ = (\sel[1]~input_o\ & (conteo(17) & (\sel[0]~input_o\ $ (conteo(18))))) # (!\sel[1]~input_o\ & (conteo(18) & (\sel[0]~input_o\ $ (conteo(17)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101001010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[0]~input_o\,
	datab => \sel[1]~input_o\,
	datac => conteo(17),
	datad => conteo(18),
	combout => \LessThan0~26_combout\);

-- Location: LCCOMB_X30_Y13_N20
\LessThan0~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~11_combout\ = (\sel[1]~input_o\) # (\sel[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sel[1]~input_o\,
	datad => \sel[0]~input_o\,
	combout => \LessThan0~11_combout\);

-- Location: LCCOMB_X30_Y13_N4
\LessThan0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~3_combout\ = (conteo(11) & ((conteo(16) & (!conteo(15) & \sel[1]~input_o\)) # (!conteo(16) & (conteo(15) & !\sel[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(16),
	datab => conteo(15),
	datac => \sel[1]~input_o\,
	datad => conteo(11),
	combout => \LessThan0~3_combout\);

-- Location: LCCOMB_X30_Y13_N14
\LessThan0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~4_combout\ = (conteo(15) & (\sel[1]~input_o\ & (!conteo(16) & !conteo(11)))) # (!conteo(15) & (((conteo(16) & conteo(11)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => conteo(15),
	datac => conteo(16),
	datad => conteo(11),
	combout => \LessThan0~4_combout\);

-- Location: LCCOMB_X30_Y13_N0
\LessThan0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~5_combout\ = (conteo(14) & (\LessThan0~4_combout\ & conteo(12))) # (!conteo(14) & (\LessThan0~4_combout\ $ (conteo(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => conteo(14),
	datac => \LessThan0~4_combout\,
	datad => conteo(12),
	combout => \LessThan0~5_combout\);

-- Location: LCCOMB_X30_Y13_N10
\LessThan0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~6_combout\ = (\LessThan0~5_combout\ & ((\sel[0]~input_o\ & (conteo(14) & !\LessThan0~3_combout\)) # (!\sel[0]~input_o\ & (!conteo(14) & \LessThan0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[0]~input_o\,
	datab => conteo(14),
	datac => \LessThan0~3_combout\,
	datad => \LessThan0~5_combout\,
	combout => \LessThan0~6_combout\);

-- Location: LCCOMB_X28_Y13_N20
\LessThan0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~7_combout\ = (!conteo(3) & (((!conteo(0) & !conteo(1))) # (!conteo(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(0),
	datab => conteo(2),
	datac => conteo(3),
	datad => conteo(1),
	combout => \LessThan0~7_combout\);

-- Location: LCCOMB_X28_Y13_N10
\LessThan0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~8_combout\ = (conteo(5)) # ((\sel[1]~input_o\ & (conteo(4) & !\LessThan0~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => conteo(5),
	datac => conteo(4),
	datad => \LessThan0~7_combout\,
	combout => \LessThan0~8_combout\);

-- Location: LCCOMB_X28_Y13_N24
\LessThan0~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~9_combout\ = (conteo(6) & (\sel[1]~input_o\ & (\sel[0]~input_o\))) # (!conteo(6) & (((\sel[0]~input_o\) # (!\LessThan0~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[1]~input_o\,
	datab => conteo(6),
	datac => \sel[0]~input_o\,
	datad => \LessThan0~8_combout\,
	combout => \LessThan0~9_combout\);

-- Location: LCCOMB_X28_Y13_N14
\LessThan0~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~10_combout\ = (!conteo(7) & (!conteo(9) & (!conteo(8) & \LessThan0~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(7),
	datab => conteo(9),
	datac => conteo(8),
	datad => \LessThan0~9_combout\,
	combout => \LessThan0~10_combout\);

-- Location: LCCOMB_X29_Y13_N4
\LessThan0~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~12_combout\ = (\LessThan0~6_combout\ & ((conteo(10) & (!\LessThan0~11_combout\ & \LessThan0~10_combout\)) # (!conteo(10) & ((\LessThan0~10_combout\) # (!\LessThan0~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(10),
	datab => \LessThan0~11_combout\,
	datac => \LessThan0~6_combout\,
	datad => \LessThan0~10_combout\,
	combout => \LessThan0~12_combout\);

-- Location: LCCOMB_X30_Y13_N12
\LessThan0~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~15_combout\ = (\sel[0]~input_o\ & (conteo(15) & (!conteo(16) & conteo(14)))) # (!\sel[0]~input_o\ & (!conteo(15) & (conteo(16) & !conteo(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[0]~input_o\,
	datab => conteo(15),
	datac => conteo(16),
	datad => conteo(14),
	combout => \LessThan0~15_combout\);

-- Location: LCCOMB_X30_Y13_N28
\LessThan0~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~13_combout\ = (conteo(14) & (conteo(15) & (\sel[0]~input_o\ $ (\sel[1]~input_o\)))) # (!conteo(14) & ((\sel[1]~input_o\ & ((conteo(15)))) # (!\sel[1]~input_o\ & (\sel[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111101000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[0]~input_o\,
	datab => conteo(14),
	datac => \sel[1]~input_o\,
	datad => conteo(15),
	combout => \LessThan0~13_combout\);

-- Location: LCCOMB_X30_Y13_N18
\LessThan0~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~14_combout\ = (conteo(15) & (!conteo(16) & \LessThan0~13_combout\)) # (!conteo(15) & ((\LessThan0~13_combout\) # (!conteo(16))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => conteo(15),
	datac => conteo(16),
	datad => \LessThan0~13_combout\,
	combout => \LessThan0~14_combout\);

-- Location: LCCOMB_X30_Y13_N22
\LessThan0~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~16_combout\ = (\sel[0]~input_o\ & (conteo(14) & (conteo(15) $ (conteo(16))))) # (!\sel[0]~input_o\ & (conteo(15) & (!conteo(16) & !conteo(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel[0]~input_o\,
	datab => conteo(15),
	datac => conteo(16),
	datad => conteo(14),
	combout => \LessThan0~16_combout\);

-- Location: LCCOMB_X30_Y13_N6
\LessThan0~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~28_combout\ = (conteo(13) & ((conteo(11) & ((!conteo(12)) # (!\LessThan0~16_combout\))) # (!conteo(11) & ((conteo(12)))))) # (!conteo(13) & (conteo(11) & (\LessThan0~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => conteo(13),
	datab => conteo(11),
	datac => \LessThan0~16_combout\,
	datad => conteo(12),
	combout => \LessThan0~28_combout\);

-- Location: LCCOMB_X30_Y13_N24
\LessThan0~29\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~29_combout\ = (\sel[1]~input_o\ & (\LessThan0~28_combout\ $ (((\LessThan0~16_combout\ & conteo(11)))))) # (!\sel[1]~input_o\ & (\LessThan0~16_combout\ & ((\LessThan0~28_combout\) # (!conteo(11)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111101010000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~16_combout\,
	datab => conteo(11),
	datac => \sel[1]~input_o\,
	datad => \LessThan0~28_combout\,
	combout => \LessThan0~29_combout\);

-- Location: LCCOMB_X30_Y13_N8
\LessThan0~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~17_combout\ = (\LessThan0~14_combout\) # ((\LessThan0~15_combout\ & (\sel[1]~input_o\ & !\LessThan0~29_combout\)) # (!\LessThan0~15_combout\ & (!\sel[1]~input_o\ & \LessThan0~29_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~15_combout\,
	datab => \LessThan0~14_combout\,
	datac => \sel[1]~input_o\,
	datad => \LessThan0~29_combout\,
	combout => \LessThan0~17_combout\);

-- Location: LCCOMB_X29_Y13_N0
\LessThan0~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~27_combout\ = (\LessThan0~2_combout\ & (\LessThan0~26_combout\ & ((\LessThan0~12_combout\) # (\LessThan0~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~2_combout\,
	datab => \LessThan0~26_combout\,
	datac => \LessThan0~12_combout\,
	datad => \LessThan0~17_combout\,
	combout => \LessThan0~27_combout\);

-- Location: LCCOMB_X29_Y13_N2
\LessThan0~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~25_combout\ = (\LessThan0~0_combout\) # ((\LessThan0~1_combout\ & ((\LessThan0~24_combout\) # (\LessThan0~27_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~1_combout\,
	datab => \LessThan0~0_combout\,
	datac => \LessThan0~24_combout\,
	datad => \LessThan0~27_combout\,
	combout => \LessThan0~25_combout\);

-- Location: LCCOMB_X30_Y13_N26
\estado~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \estado~0_combout\ = \estado~q\ $ (!\LessThan0~25_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \estado~q\,
	datad => \LessThan0~25_combout\,
	combout => \estado~0_combout\);

-- Location: FF_X30_Y13_N27
estado : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_50mhz~inputclkctrl_outclk\,
	d => \estado~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado~q\);

ww_clk_out <= \clk_out~output_o\;
END structure;


