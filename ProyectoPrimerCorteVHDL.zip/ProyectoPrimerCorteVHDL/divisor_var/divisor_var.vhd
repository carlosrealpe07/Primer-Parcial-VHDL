library ieee;
use ieee.std_logic_1164.all;



entity divisor_var is

	port
	
	(
		clk_50mhz : in std_logic;
		rst       : in std_logic;
		sel       : in std_logic_vector(1 downto 0);
		clk_out   : out std_logic
	);
	
end divisor_var;



architecture arch_divisor_var of divisor_var is

	signal conteo : integer range 0 to 50000000 := 0;
	signal estado : std_logic := '0';
	signal limite : integer range 0 to 50000000;
	
begin

	limite <= 50000000 when sel = "00" else
	          25000000 when sel = "01" else
	          12500000 when sel = "10" else
	           8333333 when sel = "11" else
	          50000000;

	process(clk_50mhz, rst)
	
	begin
	
		if (rst = '0') then
			conteo <= 0;
			estado <= '0';
		elsif (clk_50mhz'event and clk_50mhz = '1') then
			if (conteo >= limite) then
				estado <= not estado;
				conteo <= 0;
			else
				conteo <= conteo + 1;
			end if;
		end if;
		
	end process;
	
	clk_out <= estado;
	
end arch_divisor_var;