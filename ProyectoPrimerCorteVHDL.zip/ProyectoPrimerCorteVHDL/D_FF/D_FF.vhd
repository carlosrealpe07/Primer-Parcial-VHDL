library ieee;
use ieee.std_logic_1164.all;



	entity D_FF is

		port
		(
			clock, reset, preset, d, en : in  std_logic;
			q, qn                       : out std_logic
		);
		
	end D_FF;



	architecture arch_D_ff of D_FF is

		signal d_sync1, d_sync2 : std_logic;

	begin

		process (clock, reset)
		
		begin
		
			if (reset = '0') then
				d_sync1 <= '0';
				d_sync2 <= '0';
				
			elsif (clock'event and clock = '1') then
				d_sync1 <= not d; -- 'not d' pq los botones de la fpga son activos en bajo
				d_sync2 <= d_sync1;
			end if;
			
		end process;

		
		q  <= d_sync1 and not d_sync2;  -- genera un pulso de un solo ciclo de reloj 
		qn <= not (d_sync1 and not d_sync2);

	end arch_D_ff;