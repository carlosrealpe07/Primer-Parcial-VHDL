-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/12/2026 14:58:13"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	D_FF IS
    PORT (
	Clock : IN std_logic;
	Reset : IN std_logic;
	Preset : IN std_logic;
	D : IN std_logic;
	EN : IN std_logic;
	Q : OUT std_logic;
	Qn : OUT std_logic
	);
END D_FF;

-- Design Ports Information
-- Q	=>  Location: PIN_Y1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Qn	=>  Location: PIN_Y3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Reset	=>  Location: PIN_AA3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D	=>  Location: PIN_M4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Clock	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- EN	=>  Location: PIN_N6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Preset	=>  Location: PIN_R1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF D_FF IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_Clock : std_logic;
SIGNAL ww_Reset : std_logic;
SIGNAL ww_Preset : std_logic;
SIGNAL ww_D : std_logic;
SIGNAL ww_EN : std_logic;
SIGNAL ww_Q : std_logic;
SIGNAL ww_Qn : std_logic;
SIGNAL \Clock~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \Q~output_o\ : std_logic;
SIGNAL \Qn~output_o\ : std_logic;
SIGNAL \Preset~input_o\ : std_logic;
SIGNAL \Reset~input_o\ : std_logic;
SIGNAL \Q~5_combout\ : std_logic;
SIGNAL \Q~1_combout\ : std_logic;
SIGNAL \Clock~input_o\ : std_logic;
SIGNAL \Clock~inputclkctrl_outclk\ : std_logic;
SIGNAL \D~input_o\ : std_logic;
SIGNAL \Q~3_combout\ : std_logic;
SIGNAL \Q~0_combout\ : std_logic;
SIGNAL \EN~input_o\ : std_logic;
SIGNAL \Q~reg0_emulated_q\ : std_logic;
SIGNAL \Q~2_combout\ : std_logic;
SIGNAL \Qn~1_combout\ : std_logic;
SIGNAL \Qn~3_combout\ : std_logic;
SIGNAL \Qn~0_combout\ : std_logic;
SIGNAL \Qn~reg0_emulated_q\ : std_logic;
SIGNAL \Qn~2_combout\ : std_logic;
SIGNAL \ALT_INV_Qn~0_combout\ : std_logic;
SIGNAL \ALT_INV_Q~0_combout\ : std_logic;

BEGIN

ww_Clock <= Clock;
ww_Reset <= Reset;
ww_Preset <= Preset;
ww_D <= D;
ww_EN <= EN;
Q <= ww_Q;
Qn <= ww_Qn;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\Clock~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \Clock~input_o\);
\ALT_INV_Qn~0_combout\ <= NOT \Qn~0_combout\;
\ALT_INV_Q~0_combout\ <= NOT \Q~0_combout\;

-- Location: IOOBUF_X0_Y6_N9
\Q~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Q~2_combout\,
	devoe => ww_devoe,
	o => \Q~output_o\);

-- Location: IOOBUF_X5_Y0_N23
\Qn~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Qn~2_combout\,
	devoe => ww_devoe,
	o => \Qn~output_o\);

-- Location: IOIBUF_X0_Y10_N8
\Preset~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Preset,
	o => \Preset~input_o\);

-- Location: IOIBUF_X5_Y0_N1
\Reset~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Reset,
	o => \Reset~input_o\);

-- Location: LCCOMB_X6_Y8_N10
\Q~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Q~5_combout\ = (!\Preset~input_o\ & \Reset~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Preset~input_o\,
	datad => \Reset~input_o\,
	combout => \Q~5_combout\);

-- Location: LCCOMB_X6_Y8_N6
\Q~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Q~1_combout\ = (\Reset~input_o\ & ((\Q~5_combout\) # (\Q~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Q~5_combout\,
	datab => \Reset~input_o\,
	datad => \Q~1_combout\,
	combout => \Q~1_combout\);

-- Location: IOIBUF_X0_Y14_N1
\Clock~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Clock,
	o => \Clock~input_o\);

-- Location: CLKCTRL_G4
\Clock~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \Clock~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \Clock~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y12_N1
\D~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D,
	o => \D~input_o\);

-- Location: LCCOMB_X6_Y8_N8
\Q~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Q~3_combout\ = \Q~1_combout\ $ (\D~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Q~1_combout\,
	datad => \D~input_o\,
	combout => \Q~3_combout\);

-- Location: LCCOMB_X6_Y8_N0
\Q~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Q~0_combout\ = (\Q~5_combout\) # (!\Reset~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Reset~input_o\,
	datad => \Q~5_combout\,
	combout => \Q~0_combout\);

-- Location: IOIBUF_X0_Y8_N15
\EN~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_EN,
	o => \EN~input_o\);

-- Location: FF_X6_Y8_N9
\Q~reg0_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \Clock~inputclkctrl_outclk\,
	d => \Q~3_combout\,
	clrn => \ALT_INV_Q~0_combout\,
	ena => \EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \Q~reg0_emulated_q\);

-- Location: LCCOMB_X6_Y8_N2
\Q~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Q~2_combout\ = (\Reset~input_o\ & ((\Q~5_combout\) # (\Q~1_combout\ $ (\Q~reg0_emulated_q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Q~1_combout\,
	datab => \Reset~input_o\,
	datac => \Q~reg0_emulated_q\,
	datad => \Q~5_combout\,
	combout => \Q~2_combout\);

-- Location: LCCOMB_X6_Y8_N24
\Qn~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Qn~1_combout\ = (!\Q~5_combout\ & ((\Qn~1_combout\) # (!\Reset~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Q~5_combout\,
	datab => \Reset~input_o\,
	datad => \Qn~1_combout\,
	combout => \Qn~1_combout\);

-- Location: LCCOMB_X6_Y8_N12
\Qn~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Qn~3_combout\ = \Qn~1_combout\ $ (!\D~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Qn~1_combout\,
	datad => \D~input_o\,
	combout => \Qn~3_combout\);

-- Location: LCCOMB_X6_Y8_N4
\Qn~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Qn~0_combout\ = (\Q~5_combout\) # (!\Reset~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Reset~input_o\,
	datad => \Q~5_combout\,
	combout => \Qn~0_combout\);

-- Location: FF_X6_Y8_N13
\Qn~reg0_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \Clock~inputclkctrl_outclk\,
	d => \Qn~3_combout\,
	clrn => \ALT_INV_Qn~0_combout\,
	ena => \EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \Qn~reg0_emulated_q\);

-- Location: LCCOMB_X6_Y8_N14
\Qn~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Qn~2_combout\ = (!\Q~5_combout\ & ((\Qn~1_combout\ $ (\Qn~reg0_emulated_q\)) # (!\Reset~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010101010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Q~5_combout\,
	datab => \Reset~input_o\,
	datac => \Qn~1_combout\,
	datad => \Qn~reg0_emulated_q\,
	combout => \Qn~2_combout\);

ww_Q <= \Q~output_o\;

ww_Qn <= \Qn~output_o\;
END structure;


