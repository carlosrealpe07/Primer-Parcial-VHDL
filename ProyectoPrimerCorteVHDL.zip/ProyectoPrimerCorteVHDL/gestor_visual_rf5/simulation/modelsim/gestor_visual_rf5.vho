-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/16/2026 15:21:10"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	gestor_visual_rf5 IS
    PORT (
	clk : IN std_logic;
	rst : IN std_logic;
	clk_1hz : IN std_logic;
	btn_r : IN std_logic;
	btn_v : IN std_logic;
	btn_a : IN std_logic;
	sw_menu : IN std_logic_vector(2 DOWNTO 0);
	datos_total : IN std_logic_vector(7 DOWNTO 0);
	datos_r : IN std_logic_vector(7 DOWNTO 0);
	datos_v : IN std_logic_vector(7 DOWNTO 0);
	datos_a : IN std_logic_vector(7 DOWNTO 0);
	velocidad_linea : IN std_logic_vector(3 DOWNTO 0);
	conteo_valido : OUT std_logic;
	hex3 : OUT std_logic_vector(3 DOWNTO 0);
	hex2 : OUT std_logic_vector(3 DOWNTO 0);
	hex1 : OUT std_logic_vector(3 DOWNTO 0);
	hex0 : OUT std_logic_vector(3 DOWNTO 0)
	);
END gestor_visual_rf5;

-- Design Ports Information
-- conteo_valido	=>  Location: PIN_Y6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[0]	=>  Location: PIN_AA3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[1]	=>  Location: PIN_AB4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[2]	=>  Location: PIN_V8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex3[3]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[0]	=>  Location: PIN_B1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[1]	=>  Location: PIN_T9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[2]	=>  Location: PIN_H15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex2[3]	=>  Location: PIN_AB16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[0]	=>  Location: PIN_R5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[1]	=>  Location: PIN_V6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[2]	=>  Location: PIN_R10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex1[3]	=>  Location: PIN_T8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[0]	=>  Location: PIN_AB5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[1]	=>  Location: PIN_V9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[2]	=>  Location: PIN_AA5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hex0[3]	=>  Location: PIN_W6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_r	=>  Location: PIN_P8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_v	=>  Location: PIN_Y3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_a	=>  Location: PIN_R12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_menu[1]	=>  Location: PIN_U7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_menu[2]	=>  Location: PIN_T10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_menu[0]	=>  Location: PIN_R9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[4]	=>  Location: PIN_R7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[4]	=>  Location: PIN_AA2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[4]	=>  Location: PIN_P7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[4]	=>  Location: PIN_V4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[5]	=>  Location: PIN_T4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[5]	=>  Location: PIN_R11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[5]	=>  Location: PIN_T5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[5]	=>  Location: PIN_Y1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[6]	=>  Location: PIN_R6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[6]	=>  Location: PIN_T7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[6]	=>  Location: PIN_V3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[6]	=>  Location: PIN_Y4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[7]	=>  Location: PIN_P6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[7]	=>  Location: PIN_R8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[7]	=>  Location: PIN_U8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[7]	=>  Location: PIN_V5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[0]	=>  Location: PIN_AA9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[0]	=>  Location: PIN_V7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[0]	=>  Location: PIN_V10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[0]	=>  Location: PIN_U11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- velocidad_linea[0]	=>  Location: PIN_W7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[1]	=>  Location: PIN_AB8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[1]	=>  Location: PIN_Y8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[1]	=>  Location: PIN_AB3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[1]	=>  Location: PIN_AB9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- velocidad_linea[1]	=>  Location: PIN_U10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[2]	=>  Location: PIN_Y7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[2]	=>  Location: PIN_AA7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[2]	=>  Location: PIN_W8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[2]	=>  Location: PIN_U9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- velocidad_linea[2]	=>  Location: PIN_V11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_r[3]	=>  Location: PIN_AB7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_v[3]	=>  Location: PIN_AA8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_total[3]	=>  Location: PIN_AA1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_a[3]	=>  Location: PIN_T11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- velocidad_linea[3]	=>  Location: PIN_AA4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_1hz	=>  Location: PIN_AA11,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF gestor_visual_rf5 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_clk_1hz : std_logic;
SIGNAL ww_btn_r : std_logic;
SIGNAL ww_btn_v : std_logic;
SIGNAL ww_btn_a : std_logic;
SIGNAL ww_sw_menu : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_datos_total : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_datos_r : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_datos_v : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_datos_a : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_velocidad_linea : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_conteo_valido : std_logic;
SIGNAL ww_hex3 : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_hex2 : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_hex1 : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_hex0 : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \conteo_valido~output_o\ : std_logic;
SIGNAL \hex3[0]~output_o\ : std_logic;
SIGNAL \hex3[1]~output_o\ : std_logic;
SIGNAL \hex3[2]~output_o\ : std_logic;
SIGNAL \hex3[3]~output_o\ : std_logic;
SIGNAL \hex2[0]~output_o\ : std_logic;
SIGNAL \hex2[1]~output_o\ : std_logic;
SIGNAL \hex2[2]~output_o\ : std_logic;
SIGNAL \hex2[3]~output_o\ : std_logic;
SIGNAL \hex1[0]~output_o\ : std_logic;
SIGNAL \hex1[1]~output_o\ : std_logic;
SIGNAL \hex1[2]~output_o\ : std_logic;
SIGNAL \hex1[3]~output_o\ : std_logic;
SIGNAL \hex0[0]~output_o\ : std_logic;
SIGNAL \hex0[1]~output_o\ : std_logic;
SIGNAL \hex0[2]~output_o\ : std_logic;
SIGNAL \hex0[3]~output_o\ : std_logic;
SIGNAL \btn_r~input_o\ : std_logic;
SIGNAL \btn_v~input_o\ : std_logic;
SIGNAL \btn_a~input_o\ : std_logic;
SIGNAL \pulso_limpio~0_combout\ : std_logic;
SIGNAL \sw_menu[1]~input_o\ : std_logic;
SIGNAL \sw_menu[2]~input_o\ : std_logic;
SIGNAL \hex3~4_combout\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \color_activo[0]~1_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \timer[1]~1_combout\ : std_logic;
SIGNAL \clk_1hz~input_o\ : std_logic;
SIGNAL \paso1~feeder_combout\ : std_logic;
SIGNAL \paso1~q\ : std_logic;
SIGNAL \paso2~q\ : std_logic;
SIGNAL \timer[1]~0_combout\ : std_logic;
SIGNAL \timer[0]~2_combout\ : std_logic;
SIGNAL \hex3~7_combout\ : std_logic;
SIGNAL \color_activo~0_combout\ : std_logic;
SIGNAL \color_activo[1]~2_combout\ : std_logic;
SIGNAL \LessThan0~0_combout\ : std_logic;
SIGNAL \sw_menu[0]~input_o\ : std_logic;
SIGNAL \hex3~5_combout\ : std_logic;
SIGNAL \hex3~6_combout\ : std_logic;
SIGNAL \hex1~0_combout\ : std_logic;
SIGNAL \datos_a[4]~input_o\ : std_logic;
SIGNAL \datos_v[4]~input_o\ : std_logic;
SIGNAL \datos_activos[4]~0_combout\ : std_logic;
SIGNAL \datos_r[4]~input_o\ : std_logic;
SIGNAL \datos_activos[4]~8_combout\ : std_logic;
SIGNAL \datos_total[4]~input_o\ : std_logic;
SIGNAL \hex1~1_combout\ : std_logic;
SIGNAL \hex1~2_combout\ : std_logic;
SIGNAL \hex1~3_combout\ : std_logic;
SIGNAL \datos_a[5]~input_o\ : std_logic;
SIGNAL \datos_v[5]~input_o\ : std_logic;
SIGNAL \datos_activos[5]~1_combout\ : std_logic;
SIGNAL \datos_r[5]~input_o\ : std_logic;
SIGNAL \datos_total[5]~input_o\ : std_logic;
SIGNAL \hex1~4_combout\ : std_logic;
SIGNAL \hex1~5_combout\ : std_logic;
SIGNAL \hex1~6_combout\ : std_logic;
SIGNAL \datos_a[6]~input_o\ : std_logic;
SIGNAL \datos_v[6]~input_o\ : std_logic;
SIGNAL \datos_activos[6]~2_combout\ : std_logic;
SIGNAL \datos_r[6]~input_o\ : std_logic;
SIGNAL \datos_total[6]~input_o\ : std_logic;
SIGNAL \hex1~7_combout\ : std_logic;
SIGNAL \hex1~8_combout\ : std_logic;
SIGNAL \hex1~9_combout\ : std_logic;
SIGNAL \datos_v[7]~input_o\ : std_logic;
SIGNAL \datos_a[7]~input_o\ : std_logic;
SIGNAL \datos_activos[7]~3_combout\ : std_logic;
SIGNAL \datos_r[7]~input_o\ : std_logic;
SIGNAL \datos_total[7]~input_o\ : std_logic;
SIGNAL \hex1~10_combout\ : std_logic;
SIGNAL \hex1~11_combout\ : std_logic;
SIGNAL \hex1~12_combout\ : std_logic;
SIGNAL \hex0~3_combout\ : std_logic;
SIGNAL \velocidad_linea[0]~input_o\ : std_logic;
SIGNAL \datos_a[0]~input_o\ : std_logic;
SIGNAL \datos_r[0]~input_o\ : std_logic;
SIGNAL \datos_total[0]~input_o\ : std_logic;
SIGNAL \hex0~0_combout\ : std_logic;
SIGNAL \datos_v[0]~input_o\ : std_logic;
SIGNAL \hex0~1_combout\ : std_logic;
SIGNAL \datos_activos[0]~4_combout\ : std_logic;
SIGNAL \hex0~2_combout\ : std_logic;
SIGNAL \hex0~4_combout\ : std_logic;
SIGNAL \datos_a[1]~input_o\ : std_logic;
SIGNAL \datos_r[1]~input_o\ : std_logic;
SIGNAL \datos_total[1]~input_o\ : std_logic;
SIGNAL \datos_v[1]~input_o\ : std_logic;
SIGNAL \hex0~5_combout\ : std_logic;
SIGNAL \hex0~6_combout\ : std_logic;
SIGNAL \datos_activos[1]~5_combout\ : std_logic;
SIGNAL \hex0~7_combout\ : std_logic;
SIGNAL \velocidad_linea[1]~input_o\ : std_logic;
SIGNAL \hex0~8_combout\ : std_logic;
SIGNAL \velocidad_linea[2]~input_o\ : std_logic;
SIGNAL \datos_a[2]~input_o\ : std_logic;
SIGNAL \datos_v[2]~input_o\ : std_logic;
SIGNAL \datos_activos[2]~6_combout\ : std_logic;
SIGNAL \datos_r[2]~input_o\ : std_logic;
SIGNAL \datos_total[2]~input_o\ : std_logic;
SIGNAL \hex0~9_combout\ : std_logic;
SIGNAL \hex0~10_combout\ : std_logic;
SIGNAL \hex0~11_combout\ : std_logic;
SIGNAL \hex0~12_combout\ : std_logic;
SIGNAL \datos_r[3]~input_o\ : std_logic;
SIGNAL \datos_total[3]~input_o\ : std_logic;
SIGNAL \datos_v[3]~input_o\ : std_logic;
SIGNAL \hex0~13_combout\ : std_logic;
SIGNAL \datos_a[3]~input_o\ : std_logic;
SIGNAL \hex0~14_combout\ : std_logic;
SIGNAL \datos_activos[3]~7_combout\ : std_logic;
SIGNAL \hex0~15_combout\ : std_logic;
SIGNAL \velocidad_linea[3]~input_o\ : std_logic;
SIGNAL \hex0~16_combout\ : std_logic;
SIGNAL timer : std_logic_vector(1 DOWNTO 0);
SIGNAL datos_activos : std_logic_vector(7 DOWNTO 0);
SIGNAL color_activo : std_logic_vector(3 DOWNTO 0);
SIGNAL \ALT_INV_LessThan0~0_combout\ : std_logic;

BEGIN

ww_clk <= clk;
ww_rst <= rst;
ww_clk_1hz <= clk_1hz;
ww_btn_r <= btn_r;
ww_btn_v <= btn_v;
ww_btn_a <= btn_a;
ww_sw_menu <= sw_menu;
ww_datos_total <= datos_total;
ww_datos_r <= datos_r;
ww_datos_v <= datos_v;
ww_datos_a <= datos_a;
ww_velocidad_linea <= velocidad_linea;
conteo_valido <= ww_conteo_valido;
hex3 <= ww_hex3;
hex2 <= ww_hex2;
hex1 <= ww_hex1;
hex0 <= ww_hex0;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);
\ALT_INV_LessThan0~0_combout\ <= NOT \LessThan0~0_combout\;

-- Location: IOOBUF_X5_Y0_N9
\conteo_valido~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pulso_limpio~0_combout\,
	devoe => ww_devoe,
	o => \conteo_valido~output_o\);

-- Location: IOOBUF_X5_Y0_N2
\hex3[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex3~7_combout\,
	devoe => ww_devoe,
	o => \hex3[0]~output_o\);

-- Location: IOOBUF_X7_Y0_N2
\hex3[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex3~5_combout\,
	devoe => ww_devoe,
	o => \hex3[1]~output_o\);

-- Location: IOOBUF_X11_Y0_N30
\hex3[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex3~6_combout\,
	devoe => ww_devoe,
	o => \hex3[2]~output_o\);

-- Location: IOOBUF_X21_Y29_N2
\hex3[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \hex3[3]~output_o\);

-- Location: IOOBUF_X0_Y27_N16
\hex2[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \hex2[0]~output_o\);

-- Location: IOOBUF_X1_Y0_N9
\hex2[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_LessThan0~0_combout\,
	devoe => ww_devoe,
	o => \hex2[1]~output_o\);

-- Location: IOOBUF_X35_Y29_N23
\hex2[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \hex2[2]~output_o\);

-- Location: IOOBUF_X28_Y0_N16
\hex2[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \hex2[3]~output_o\);

-- Location: IOOBUF_X0_Y4_N16
\hex1[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex1~3_combout\,
	devoe => ww_devoe,
	o => \hex1[0]~output_o\);

-- Location: IOOBUF_X1_Y0_N2
\hex1[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex1~6_combout\,
	devoe => ww_devoe,
	o => \hex1[1]~output_o\);

-- Location: IOOBUF_X1_Y0_N16
\hex1[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex1~9_combout\,
	devoe => ww_devoe,
	o => \hex1[2]~output_o\);

-- Location: IOOBUF_X1_Y0_N23
\hex1[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex1~12_combout\,
	devoe => ww_devoe,
	o => \hex1[3]~output_o\);

-- Location: IOOBUF_X9_Y0_N23
\hex0[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex0~4_combout\,
	devoe => ww_devoe,
	o => \hex0[0]~output_o\);

-- Location: IOOBUF_X14_Y0_N23
\hex0[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex0~8_combout\,
	devoe => ww_devoe,
	o => \hex0[1]~output_o\);

-- Location: IOOBUF_X9_Y0_N30
\hex0[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex0~12_combout\,
	devoe => ww_devoe,
	o => \hex0[2]~output_o\);

-- Location: IOOBUF_X7_Y0_N23
\hex0[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hex0~16_combout\,
	devoe => ww_devoe,
	o => \hex0[3]~output_o\);

-- Location: IOIBUF_X0_Y2_N15
\btn_r~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_r,
	o => \btn_r~input_o\);

-- Location: IOIBUF_X5_Y0_N22
\btn_v~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_v,
	o => \btn_v~input_o\);

-- Location: IOIBUF_X5_Y0_N29
\btn_a~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_a,
	o => \btn_a~input_o\);

-- Location: LCCOMB_X6_Y1_N24
\pulso_limpio~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \pulso_limpio~0_combout\ = (\btn_r~input_o\ & (!\btn_v~input_o\ & !\btn_a~input_o\)) # (!\btn_r~input_o\ & (\btn_v~input_o\ $ (\btn_a~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010101011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_r~input_o\,
	datac => \btn_v~input_o\,
	datad => \btn_a~input_o\,
	combout => \pulso_limpio~0_combout\);

-- Location: IOIBUF_X3_Y0_N22
\sw_menu[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_menu(1),
	o => \sw_menu[1]~input_o\);

-- Location: IOIBUF_X14_Y0_N8
\sw_menu[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_menu(2),
	o => \sw_menu[2]~input_o\);

-- Location: LCCOMB_X7_Y1_N12
\hex3~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex3~4_combout\ = (\sw_menu[1]~input_o\ & !\sw_menu[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datac => \sw_menu[2]~input_o\,
	combout => \hex3~4_combout\);

-- Location: IOIBUF_X0_Y14_N1
\clk~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G4
\clk~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X7_Y1_N26
\color_activo[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \color_activo[0]~1_combout\ = !\btn_r~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \btn_r~input_o\,
	combout => \color_activo[0]~1_combout\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: FF_X7_Y1_N27
\color_activo[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \color_activo[0]~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \pulso_limpio~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => color_activo(0));

-- Location: LCCOMB_X7_Y1_N16
\timer[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \timer[1]~1_combout\ = (\pulso_limpio~0_combout\) # (timer(1) $ (((!timer(0) & !\timer[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011101101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => timer(0),
	datab => \pulso_limpio~0_combout\,
	datac => timer(1),
	datad => \timer[1]~0_combout\,
	combout => \timer[1]~1_combout\);

-- Location: FF_X7_Y1_N17
\timer[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \timer[1]~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => timer(1));

-- Location: IOIBUF_X21_Y0_N22
\clk_1hz~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_1hz,
	o => \clk_1hz~input_o\);

-- Location: LCCOMB_X7_Y1_N18
\paso1~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \paso1~feeder_combout\ = \clk_1hz~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \clk_1hz~input_o\,
	combout => \paso1~feeder_combout\);

-- Location: FF_X7_Y1_N19
paso1 : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \paso1~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \paso1~q\);

-- Location: FF_X7_Y1_N3
paso2 : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \paso1~q\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \paso2~q\);

-- Location: LCCOMB_X7_Y1_N2
\timer[1]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \timer[1]~0_combout\ = (\paso2~q\) # (((!timer(1) & !timer(0))) # (!\paso1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => timer(1),
	datab => timer(0),
	datac => \paso2~q\,
	datad => \paso1~q\,
	combout => \timer[1]~0_combout\);

-- Location: LCCOMB_X7_Y1_N20
\timer[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \timer[0]~2_combout\ = (\pulso_limpio~0_combout\) # (timer(0) $ (!\timer[1]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \pulso_limpio~0_combout\,
	datac => timer(0),
	datad => \timer[1]~0_combout\,
	combout => \timer[0]~2_combout\);

-- Location: FF_X7_Y1_N21
\timer[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \timer[0]~2_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => timer(0));

-- Location: LCCOMB_X7_Y1_N10
\hex3~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex3~7_combout\ = (timer(0) & (((!color_activo(0))))) # (!timer(0) & ((timer(1) & ((!color_activo(0)))) # (!timer(1) & (!\hex3~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex3~4_combout\,
	datab => color_activo(0),
	datac => timer(0),
	datad => timer(1),
	combout => \hex3~7_combout\);

-- Location: LCCOMB_X7_Y1_N22
\color_activo~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \color_activo~0_combout\ = (\btn_r~input_o\) # (!\btn_v~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \btn_r~input_o\,
	datad => \btn_v~input_o\,
	combout => \color_activo~0_combout\);

-- Location: LCCOMB_X7_Y1_N6
\color_activo[1]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \color_activo[1]~2_combout\ = !\color_activo~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \color_activo~0_combout\,
	combout => \color_activo[1]~2_combout\);

-- Location: FF_X7_Y1_N7
\color_activo[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \color_activo[1]~2_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \pulso_limpio~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => color_activo(1));

-- Location: LCCOMB_X7_Y1_N4
\LessThan0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \LessThan0~0_combout\ = (timer(0)) # (timer(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => timer(0),
	datad => timer(1),
	combout => \LessThan0~0_combout\);

-- Location: IOIBUF_X1_Y0_N29
\sw_menu[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_menu(0),
	o => \sw_menu[0]~input_o\);

-- Location: LCCOMB_X7_Y1_N28
\hex3~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex3~5_combout\ = (\LessThan0~0_combout\ & (!color_activo(1))) # (!\LessThan0~0_combout\ & (((\sw_menu[0]~input_o\) # (!\hex3~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111010001110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => color_activo(1),
	datab => \LessThan0~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \hex3~4_combout\,
	combout => \hex3~5_combout\);

-- Location: FF_X7_Y1_N15
\color_activo[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \color_activo~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \pulso_limpio~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => color_activo(2));

-- Location: LCCOMB_X8_Y1_N28
\hex3~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex3~6_combout\ = (\LessThan0~0_combout\ & (!color_activo(2))) # (!\LessThan0~0_combout\ & (((\sw_menu[2]~input_o\) # (!\sw_menu[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011101000111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => color_activo(2),
	datab => \LessThan0~0_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \sw_menu[2]~input_o\,
	combout => \hex3~6_combout\);

-- Location: LCCOMB_X7_Y1_N8
\hex1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~0_combout\ = (\sw_menu[2]~input_o\ & (!timer(0) & !timer(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[2]~input_o\,
	datac => timer(0),
	datad => timer(1),
	combout => \hex1~0_combout\);

-- Location: IOIBUF_X0_Y5_N22
\datos_a[4]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(4),
	o => \datos_a[4]~input_o\);

-- Location: IOIBUF_X0_Y2_N1
\datos_v[4]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(4),
	o => \datos_v[4]~input_o\);

-- Location: LCCOMB_X3_Y1_N8
\datos_activos[4]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[4]~0_combout\ = (\btn_v~input_o\ & ((\datos_v[4]~input_o\))) # (!\btn_v~input_o\ & (\datos_a[4]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_a[4]~input_o\,
	datab => \btn_v~input_o\,
	datad => \datos_v[4]~input_o\,
	combout => \datos_activos[4]~0_combout\);

-- Location: IOIBUF_X0_Y5_N8
\datos_r[4]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(4),
	o => \datos_r[4]~input_o\);

-- Location: LCCOMB_X6_Y1_N2
\datos_activos[4]~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[4]~8_combout\ = (\rst~input_o\ & ((\btn_r~input_o\ & (!\btn_v~input_o\ & !\btn_a~input_o\)) # (!\btn_r~input_o\ & (\btn_v~input_o\ $ (\btn_a~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_r~input_o\,
	datab => \btn_v~input_o\,
	datac => \rst~input_o\,
	datad => \btn_a~input_o\,
	combout => \datos_activos[4]~8_combout\);

-- Location: FF_X3_Y1_N9
\datos_activos[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[4]~0_combout\,
	asdata => \datos_r[4]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(4));

-- Location: IOIBUF_X0_Y5_N1
\datos_total[4]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(4),
	o => \datos_total[4]~input_o\);

-- Location: LCCOMB_X3_Y1_N0
\hex1~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~1_combout\ = (\sw_menu[1]~input_o\ & (((\sw_menu[0]~input_o\)))) # (!\sw_menu[1]~input_o\ & ((\sw_menu[0]~input_o\ & ((\datos_r[4]~input_o\))) # (!\sw_menu[0]~input_o\ & (\datos_total[4]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_total[4]~input_o\,
	datab => \sw_menu[1]~input_o\,
	datac => \sw_menu[0]~input_o\,
	datad => \datos_r[4]~input_o\,
	combout => \hex1~1_combout\);

-- Location: LCCOMB_X3_Y1_N2
\hex1~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~2_combout\ = (\sw_menu[1]~input_o\ & ((\hex1~1_combout\ & (\datos_a[4]~input_o\)) # (!\hex1~1_combout\ & ((\datos_v[4]~input_o\))))) # (!\sw_menu[1]~input_o\ & (((\hex1~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_a[4]~input_o\,
	datab => \sw_menu[1]~input_o\,
	datac => \datos_v[4]~input_o\,
	datad => \hex1~1_combout\,
	combout => \hex1~2_combout\);

-- Location: LCCOMB_X3_Y1_N4
\hex1~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~3_combout\ = (\hex1~0_combout\) # ((\LessThan0~0_combout\ & (datos_activos(4))) # (!\LessThan0~0_combout\ & ((\hex1~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex1~0_combout\,
	datab => datos_activos(4),
	datac => \LessThan0~0_combout\,
	datad => \hex1~2_combout\,
	combout => \hex1~3_combout\);

-- Location: IOIBUF_X0_Y6_N8
\datos_a[5]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(5),
	o => \datos_a[5]~input_o\);

-- Location: IOIBUF_X3_Y0_N1
\datos_v[5]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(5),
	o => \datos_v[5]~input_o\);

-- Location: LCCOMB_X3_Y1_N22
\datos_activos[5]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[5]~1_combout\ = (\btn_v~input_o\ & ((\datos_v[5]~input_o\))) # (!\btn_v~input_o\ & (\datos_a[5]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_v~input_o\,
	datab => \datos_a[5]~input_o\,
	datad => \datos_v[5]~input_o\,
	combout => \datos_activos[5]~1_combout\);

-- Location: IOIBUF_X0_Y4_N22
\datos_r[5]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(5),
	o => \datos_r[5]~input_o\);

-- Location: FF_X3_Y1_N23
\datos_activos[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[5]~1_combout\,
	asdata => \datos_r[5]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(5));

-- Location: IOIBUF_X0_Y3_N1
\datos_total[5]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(5),
	o => \datos_total[5]~input_o\);

-- Location: LCCOMB_X3_Y1_N18
\hex1~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~4_combout\ = (\sw_menu[0]~input_o\ & (((\sw_menu[1]~input_o\)))) # (!\sw_menu[0]~input_o\ & ((\sw_menu[1]~input_o\ & (\datos_v[5]~input_o\)) # (!\sw_menu[1]~input_o\ & ((\datos_total[5]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_v[5]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \sw_menu[1]~input_o\,
	datad => \datos_total[5]~input_o\,
	combout => \hex1~4_combout\);

-- Location: LCCOMB_X3_Y1_N24
\hex1~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~5_combout\ = (\sw_menu[0]~input_o\ & ((\hex1~4_combout\ & (\datos_a[5]~input_o\)) # (!\hex1~4_combout\ & ((\datos_r[5]~input_o\))))) # (!\sw_menu[0]~input_o\ & (((\hex1~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_a[5]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \datos_r[5]~input_o\,
	datad => \hex1~4_combout\,
	combout => \hex1~5_combout\);

-- Location: LCCOMB_X3_Y1_N30
\hex1~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~6_combout\ = (\hex1~0_combout\) # ((\LessThan0~0_combout\ & (datos_activos(5))) # (!\LessThan0~0_combout\ & ((\hex1~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex1~0_combout\,
	datab => \LessThan0~0_combout\,
	datac => datos_activos(5),
	datad => \hex1~5_combout\,
	combout => \hex1~6_combout\);

-- Location: IOIBUF_X3_Y0_N8
\datos_a[6]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(6),
	o => \datos_a[6]~input_o\);

-- Location: IOIBUF_X0_Y3_N8
\datos_v[6]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(6),
	o => \datos_v[6]~input_o\);

-- Location: LCCOMB_X3_Y1_N16
\datos_activos[6]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[6]~2_combout\ = (\btn_v~input_o\ & ((\datos_v[6]~input_o\))) # (!\btn_v~input_o\ & (\datos_a[6]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_v~input_o\,
	datab => \datos_a[6]~input_o\,
	datad => \datos_v[6]~input_o\,
	combout => \datos_activos[6]~2_combout\);

-- Location: IOIBUF_X0_Y2_N8
\datos_r[6]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(6),
	o => \datos_r[6]~input_o\);

-- Location: FF_X3_Y1_N17
\datos_activos[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[6]~2_combout\,
	asdata => \datos_r[6]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(6));

-- Location: IOIBUF_X0_Y4_N1
\datos_total[6]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(6),
	o => \datos_total[6]~input_o\);

-- Location: LCCOMB_X3_Y1_N12
\hex1~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~7_combout\ = (\sw_menu[1]~input_o\ & (((\sw_menu[0]~input_o\)))) # (!\sw_menu[1]~input_o\ & ((\sw_menu[0]~input_o\ & (\datos_r[6]~input_o\)) # (!\sw_menu[0]~input_o\ & ((\datos_total[6]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_r[6]~input_o\,
	datab => \sw_menu[1]~input_o\,
	datac => \sw_menu[0]~input_o\,
	datad => \datos_total[6]~input_o\,
	combout => \hex1~7_combout\);

-- Location: LCCOMB_X3_Y1_N6
\hex1~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~8_combout\ = (\hex1~7_combout\ & ((\datos_a[6]~input_o\) # ((!\sw_menu[1]~input_o\)))) # (!\hex1~7_combout\ & (((\sw_menu[1]~input_o\ & \datos_v[6]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex1~7_combout\,
	datab => \datos_a[6]~input_o\,
	datac => \sw_menu[1]~input_o\,
	datad => \datos_v[6]~input_o\,
	combout => \hex1~8_combout\);

-- Location: LCCOMB_X3_Y1_N28
\hex1~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~9_combout\ = (\hex1~0_combout\) # ((\LessThan0~0_combout\ & (datos_activos(6))) # (!\LessThan0~0_combout\ & ((\hex1~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex1~0_combout\,
	datab => datos_activos(6),
	datac => \LessThan0~0_combout\,
	datad => \hex1~8_combout\,
	combout => \hex1~9_combout\);

-- Location: IOIBUF_X0_Y2_N22
\datos_v[7]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(7),
	o => \datos_v[7]~input_o\);

-- Location: IOIBUF_X3_Y0_N29
\datos_a[7]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(7),
	o => \datos_a[7]~input_o\);

-- Location: LCCOMB_X3_Y1_N26
\datos_activos[7]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[7]~3_combout\ = (\btn_v~input_o\ & (\datos_v[7]~input_o\)) # (!\btn_v~input_o\ & ((\datos_a[7]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_v~input_o\,
	datab => \datos_v[7]~input_o\,
	datad => \datos_a[7]~input_o\,
	combout => \datos_activos[7]~3_combout\);

-- Location: IOIBUF_X0_Y4_N8
\datos_r[7]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(7),
	o => \datos_r[7]~input_o\);

-- Location: FF_X3_Y1_N27
\datos_activos[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[7]~3_combout\,
	asdata => \datos_r[7]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(7));

-- Location: IOIBUF_X3_Y0_N15
\datos_total[7]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(7),
	o => \datos_total[7]~input_o\);

-- Location: LCCOMB_X3_Y1_N10
\hex1~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~10_combout\ = (\sw_menu[0]~input_o\ & (((\sw_menu[1]~input_o\)))) # (!\sw_menu[0]~input_o\ & ((\sw_menu[1]~input_o\ & (\datos_v[7]~input_o\)) # (!\sw_menu[1]~input_o\ & ((\datos_total[7]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_v[7]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \sw_menu[1]~input_o\,
	datad => \datos_total[7]~input_o\,
	combout => \hex1~10_combout\);

-- Location: LCCOMB_X3_Y1_N20
\hex1~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~11_combout\ = (\sw_menu[0]~input_o\ & ((\hex1~10_combout\ & (\datos_a[7]~input_o\)) # (!\hex1~10_combout\ & ((\datos_r[7]~input_o\))))) # (!\sw_menu[0]~input_o\ & (((\hex1~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_a[7]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \datos_r[7]~input_o\,
	datad => \hex1~10_combout\,
	combout => \hex1~11_combout\);

-- Location: LCCOMB_X2_Y1_N28
\hex1~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex1~12_combout\ = (\hex1~0_combout\) # ((\LessThan0~0_combout\ & (datos_activos(7))) # (!\LessThan0~0_combout\ & ((\hex1~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~0_combout\,
	datab => datos_activos(7),
	datac => \hex1~11_combout\,
	datad => \hex1~0_combout\,
	combout => \hex1~12_combout\);

-- Location: LCCOMB_X7_Y1_N24
\hex0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~3_combout\ = (!\sw_menu[0]~input_o\ & !\sw_menu[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \sw_menu[0]~input_o\,
	datad => \sw_menu[1]~input_o\,
	combout => \hex0~3_combout\);

-- Location: IOIBUF_X9_Y0_N15
\velocidad_linea[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_velocidad_linea(0),
	o => \velocidad_linea[0]~input_o\);

-- Location: IOIBUF_X19_Y0_N29
\datos_a[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(0),
	o => \datos_a[0]~input_o\);

-- Location: IOIBUF_X7_Y0_N15
\datos_r[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(0),
	o => \datos_r[0]~input_o\);

-- Location: IOIBUF_X14_Y0_N15
\datos_total[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(0),
	o => \datos_total[0]~input_o\);

-- Location: LCCOMB_X8_Y1_N30
\hex0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~0_combout\ = (\sw_menu[1]~input_o\ & (\sw_menu[0]~input_o\)) # (!\sw_menu[1]~input_o\ & ((\sw_menu[0]~input_o\ & (\datos_r[0]~input_o\)) # (!\sw_menu[0]~input_o\ & ((\datos_total[0]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \datos_r[0]~input_o\,
	datad => \datos_total[0]~input_o\,
	combout => \hex0~0_combout\);

-- Location: IOIBUF_X16_Y0_N8
\datos_v[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(0),
	o => \datos_v[0]~input_o\);

-- Location: LCCOMB_X8_Y1_N12
\hex0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~1_combout\ = (\sw_menu[1]~input_o\ & ((\hex0~0_combout\ & (\datos_a[0]~input_o\)) # (!\hex0~0_combout\ & ((\datos_v[0]~input_o\))))) # (!\sw_menu[1]~input_o\ & (((\hex0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \datos_a[0]~input_o\,
	datac => \hex0~0_combout\,
	datad => \datos_v[0]~input_o\,
	combout => \hex0~1_combout\);

-- Location: LCCOMB_X8_Y1_N4
\datos_activos[0]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[0]~4_combout\ = (\btn_v~input_o\ & (\datos_v[0]~input_o\)) # (!\btn_v~input_o\ & ((\datos_a[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_v[0]~input_o\,
	datab => \datos_a[0]~input_o\,
	datad => \btn_v~input_o\,
	combout => \datos_activos[0]~4_combout\);

-- Location: FF_X8_Y1_N5
\datos_activos[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[0]~4_combout\,
	asdata => \datos_r[0]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(0));

-- Location: LCCOMB_X8_Y1_N14
\hex0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~2_combout\ = (\LessThan0~0_combout\ & (((datos_activos(0))))) # (!\LessThan0~0_combout\ & (\hex0~1_combout\ & ((!\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex0~1_combout\,
	datab => \LessThan0~0_combout\,
	datac => datos_activos(0),
	datad => \sw_menu[2]~input_o\,
	combout => \hex0~2_combout\);

-- Location: LCCOMB_X9_Y1_N28
\hex0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~4_combout\ = (\hex0~2_combout\) # ((\hex1~0_combout\ & ((\velocidad_linea[0]~input_o\) # (!\hex0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex0~3_combout\,
	datab => \velocidad_linea[0]~input_o\,
	datac => \hex1~0_combout\,
	datad => \hex0~2_combout\,
	combout => \hex0~4_combout\);

-- Location: IOIBUF_X16_Y0_N1
\datos_a[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(1),
	o => \datos_a[1]~input_o\);

-- Location: IOIBUF_X16_Y0_N22
\datos_r[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(1),
	o => \datos_r[1]~input_o\);

-- Location: IOIBUF_X7_Y0_N29
\datos_total[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(1),
	o => \datos_total[1]~input_o\);

-- Location: IOIBUF_X11_Y0_N1
\datos_v[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(1),
	o => \datos_v[1]~input_o\);

-- Location: LCCOMB_X8_Y1_N20
\hex0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~5_combout\ = (\sw_menu[1]~input_o\ & (((\sw_menu[0]~input_o\) # (\datos_v[1]~input_o\)))) # (!\sw_menu[1]~input_o\ & (\datos_total[1]~input_o\ & (!\sw_menu[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \datos_total[1]~input_o\,
	datac => \sw_menu[0]~input_o\,
	datad => \datos_v[1]~input_o\,
	combout => \hex0~5_combout\);

-- Location: LCCOMB_X8_Y1_N10
\hex0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~6_combout\ = (\sw_menu[0]~input_o\ & ((\hex0~5_combout\ & (\datos_a[1]~input_o\)) # (!\hex0~5_combout\ & ((\datos_r[1]~input_o\))))) # (!\sw_menu[0]~input_o\ & (((\hex0~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_a[1]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \datos_r[1]~input_o\,
	datad => \hex0~5_combout\,
	combout => \hex0~6_combout\);

-- Location: LCCOMB_X8_Y1_N26
\datos_activos[1]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[1]~5_combout\ = (\btn_v~input_o\ & (\datos_v[1]~input_o\)) # (!\btn_v~input_o\ & ((\datos_a[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_v[1]~input_o\,
	datab => \btn_v~input_o\,
	datad => \datos_a[1]~input_o\,
	combout => \datos_activos[1]~5_combout\);

-- Location: FF_X8_Y1_N27
\datos_activos[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[1]~5_combout\,
	asdata => \datos_r[1]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(1));

-- Location: LCCOMB_X8_Y1_N24
\hex0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~7_combout\ = (\LessThan0~0_combout\ & (((datos_activos(1))))) # (!\LessThan0~0_combout\ & (\hex0~6_combout\ & ((!\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex0~6_combout\,
	datab => \LessThan0~0_combout\,
	datac => datos_activos(1),
	datad => \sw_menu[2]~input_o\,
	combout => \hex0~7_combout\);

-- Location: IOIBUF_X14_Y0_N1
\velocidad_linea[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_velocidad_linea(1),
	o => \velocidad_linea[1]~input_o\);

-- Location: LCCOMB_X9_Y1_N26
\hex0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~8_combout\ = (\hex0~7_combout\) # ((\hex1~0_combout\ & ((\velocidad_linea[1]~input_o\) # (!\hex0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex0~3_combout\,
	datab => \hex0~7_combout\,
	datac => \hex1~0_combout\,
	datad => \velocidad_linea[1]~input_o\,
	combout => \hex0~8_combout\);

-- Location: IOIBUF_X19_Y0_N22
\velocidad_linea[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_velocidad_linea(2),
	o => \velocidad_linea[2]~input_o\);

-- Location: IOIBUF_X9_Y0_N1
\datos_a[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(2),
	o => \datos_a[2]~input_o\);

-- Location: IOIBUF_X9_Y0_N8
\datos_v[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(2),
	o => \datos_v[2]~input_o\);

-- Location: LCCOMB_X8_Y1_N16
\datos_activos[2]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[2]~6_combout\ = (\btn_v~input_o\ & ((\datos_v[2]~input_o\))) # (!\btn_v~input_o\ & (\datos_a[2]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_a[2]~input_o\,
	datab => \datos_v[2]~input_o\,
	datad => \btn_v~input_o\,
	combout => \datos_activos[2]~6_combout\);

-- Location: IOIBUF_X11_Y0_N15
\datos_r[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(2),
	o => \datos_r[2]~input_o\);

-- Location: FF_X8_Y1_N17
\datos_activos[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[2]~6_combout\,
	asdata => \datos_r[2]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(2));

-- Location: IOIBUF_X11_Y0_N22
\datos_total[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(2),
	o => \datos_total[2]~input_o\);

-- Location: LCCOMB_X8_Y1_N22
\hex0~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~9_combout\ = (\sw_menu[1]~input_o\ & (\sw_menu[0]~input_o\)) # (!\sw_menu[1]~input_o\ & ((\sw_menu[0]~input_o\ & (\datos_r[2]~input_o\)) # (!\sw_menu[0]~input_o\ & ((\datos_total[2]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \datos_r[2]~input_o\,
	datad => \datos_total[2]~input_o\,
	combout => \hex0~9_combout\);

-- Location: LCCOMB_X8_Y1_N8
\hex0~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~10_combout\ = (\sw_menu[1]~input_o\ & ((\hex0~9_combout\ & ((\datos_a[2]~input_o\))) # (!\hex0~9_combout\ & (\datos_v[2]~input_o\)))) # (!\sw_menu[1]~input_o\ & (((\hex0~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \datos_v[2]~input_o\,
	datac => \hex0~9_combout\,
	datad => \datos_a[2]~input_o\,
	combout => \hex0~10_combout\);

-- Location: LCCOMB_X8_Y1_N2
\hex0~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~11_combout\ = (\LessThan0~0_combout\ & (datos_activos(2))) # (!\LessThan0~0_combout\ & (((\hex0~10_combout\ & !\sw_menu[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan0~0_combout\,
	datab => datos_activos(2),
	datac => \hex0~10_combout\,
	datad => \sw_menu[2]~input_o\,
	combout => \hex0~11_combout\);

-- Location: LCCOMB_X9_Y1_N4
\hex0~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~12_combout\ = (\hex0~11_combout\) # ((\hex1~0_combout\ & ((\velocidad_linea[2]~input_o\) # (!\hex0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex0~3_combout\,
	datab => \velocidad_linea[2]~input_o\,
	datac => \hex1~0_combout\,
	datad => \hex0~11_combout\,
	combout => \hex0~12_combout\);

-- Location: IOIBUF_X11_Y0_N8
\datos_r[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_r(3),
	o => \datos_r[3]~input_o\);

-- Location: IOIBUF_X0_Y5_N15
\datos_total[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_total(3),
	o => \datos_total[3]~input_o\);

-- Location: IOIBUF_X16_Y0_N29
\datos_v[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_v(3),
	o => \datos_v[3]~input_o\);

-- Location: LCCOMB_X8_Y1_N0
\hex0~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~13_combout\ = (\sw_menu[1]~input_o\ & ((\sw_menu[0]~input_o\) # ((\datos_v[3]~input_o\)))) # (!\sw_menu[1]~input_o\ & (!\sw_menu[0]~input_o\ & (\datos_total[3]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_menu[1]~input_o\,
	datab => \sw_menu[0]~input_o\,
	datac => \datos_total[3]~input_o\,
	datad => \datos_v[3]~input_o\,
	combout => \hex0~13_combout\);

-- Location: IOIBUF_X16_Y0_N15
\datos_a[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_a(3),
	o => \datos_a[3]~input_o\);

-- Location: LCCOMB_X8_Y1_N6
\hex0~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~14_combout\ = (\hex0~13_combout\ & (((\datos_a[3]~input_o\) # (!\sw_menu[0]~input_o\)))) # (!\hex0~13_combout\ & (\datos_r[3]~input_o\ & (\sw_menu[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_r[3]~input_o\,
	datab => \hex0~13_combout\,
	datac => \sw_menu[0]~input_o\,
	datad => \datos_a[3]~input_o\,
	combout => \hex0~14_combout\);

-- Location: LCCOMB_X8_Y1_N18
\datos_activos[3]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \datos_activos[3]~7_combout\ = (\btn_v~input_o\ & ((\datos_v[3]~input_o\))) # (!\btn_v~input_o\ & (\datos_a[3]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \btn_v~input_o\,
	datab => \datos_a[3]~input_o\,
	datad => \datos_v[3]~input_o\,
	combout => \datos_activos[3]~7_combout\);

-- Location: FF_X8_Y1_N19
\datos_activos[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \datos_activos[3]~7_combout\,
	asdata => \datos_r[3]~input_o\,
	sload => \btn_r~input_o\,
	ena => \datos_activos[4]~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => datos_activos(3));

-- Location: LCCOMB_X7_Y1_N0
\hex0~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~15_combout\ = (\LessThan0~0_combout\ & (((datos_activos(3))))) # (!\LessThan0~0_combout\ & (\hex0~14_combout\ & (!\sw_menu[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex0~14_combout\,
	datab => \LessThan0~0_combout\,
	datac => \sw_menu[2]~input_o\,
	datad => datos_activos(3),
	combout => \hex0~15_combout\);

-- Location: IOIBUF_X7_Y0_N8
\velocidad_linea[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_velocidad_linea(3),
	o => \velocidad_linea[3]~input_o\);

-- Location: LCCOMB_X7_Y1_N30
\hex0~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \hex0~16_combout\ = (\hex0~15_combout\) # ((\hex1~0_combout\ & ((\velocidad_linea[3]~input_o\) # (!\hex0~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hex1~0_combout\,
	datab => \hex0~15_combout\,
	datac => \velocidad_linea[3]~input_o\,
	datad => \hex0~3_combout\,
	combout => \hex0~16_combout\);

ww_conteo_valido <= \conteo_valido~output_o\;

ww_hex3(0) <= \hex3[0]~output_o\;

ww_hex3(1) <= \hex3[1]~output_o\;

ww_hex3(2) <= \hex3[2]~output_o\;

ww_hex3(3) <= \hex3[3]~output_o\;

ww_hex2(0) <= \hex2[0]~output_o\;

ww_hex2(1) <= \hex2[1]~output_o\;

ww_hex2(2) <= \hex2[2]~output_o\;

ww_hex2(3) <= \hex2[3]~output_o\;

ww_hex1(0) <= \hex1[0]~output_o\;

ww_hex1(1) <= \hex1[1]~output_o\;

ww_hex1(2) <= \hex1[2]~output_o\;

ww_hex1(3) <= \hex1[3]~output_o\;

ww_hex0(0) <= \hex0[0]~output_o\;

ww_hex0(1) <= \hex0[1]~output_o\;

ww_hex0(2) <= \hex0[2]~output_o\;

ww_hex0(3) <= \hex0[3]~output_o\;
END structure;


