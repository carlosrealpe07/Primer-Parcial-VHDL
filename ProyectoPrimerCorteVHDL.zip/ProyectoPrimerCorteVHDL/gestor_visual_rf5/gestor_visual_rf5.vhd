library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;



entity gestor_visual_rf5 is

	port
	
	(
		clk             : in std_logic;
		rst             : in std_logic;
		clk_1hz         : in std_logic;
		pulso_valido    : in std_logic;
		pausa           : in std_logic;
		cod_color       : in std_logic_vector(1 downto 0);
		sw_menu         : in std_logic_vector(2 downto 0);
		datos_total     : in std_logic_vector(7 downto 0);
		datos_r         : in std_logic_vector(7 downto 0);
		datos_v         : in std_logic_vector(7 downto 0);
		datos_a         : in std_logic_vector(7 downto 0);
		velocidad_linea : in std_logic_vector(3 downto 0);
		
		out_t_cen       : out std_logic_vector(3 downto 0);
		out_t_dec       : out std_logic_vector(3 downto 0);
		out_t_uni       : out std_logic_vector(3 downto 0);
		
		hex3            : out std_logic_vector(3 downto 0);
		hex2            : out std_logic_vector(3 downto 0);
		hex1            : out std_logic_vector(3 downto 0);
		hex0            : out std_logic_vector(3 downto 0)
	);
	
end gestor_visual_rf5;



architecture arch_gestor of gestor_visual_rf5 is

	signal timer         : integer range 0 to 3 := 0;
	signal color_activo  : std_logic_vector(3 downto 0) := "1111";
	signal paso1, paso2  : std_logic := '0';
	signal tick_1hz      : std_logic;

	signal t_uni : unsigned(3 downto 0) := "0000";
	signal t_dec : unsigned(3 downto 0) := "0000";
	signal t_cen : unsigned(3 downto 0) := "0000";

begin

	process(clk, rst)
	
	begin
	
		if (rst = '0') then
			paso1 <= '0';
			paso2 <= '0';
		elsif (clk'event and clk = '1') then
			paso1 <= clk_1hz;
			paso2 <= paso1;
		end if;
		
	end process;
	
	tick_1hz <= paso1 and (not paso2);

	
	process(clk, rst)
	
	begin
	
		if (rst = '0') then
			timer <= 0;
			color_activo <= "1111";
		elsif (clk'event and clk = '1') then
			if (pulso_valido = '1' and pausa = '0') then
				timer <= 3;
				if (cod_color = "01") then color_activo <= "1011";
				elsif (cod_color = "10") then color_activo <= "1100";
				elsif (cod_color = "11") then color_activo <= "1010";
				end if;
			elsif (tick_1hz = '1' and pausa = '0') then
				if (timer > 0) then timer <= timer - 1; end if;
			end if;
		end if;
		
	end process;

	
	process(clk, rst)
	
	begin
	
		if (rst = '0') then
			t_uni <= "0000";
			t_dec <= "0000";
			t_cen <= "0000";
		elsif (clk'event and clk = '1') then
			if (tick_1hz = '1' and pausa = '0') then
				if (t_cen = 1 and t_dec = 8 and t_uni = 0) then
					t_uni <= "0000"; t_dec <= "0000"; t_cen <= "0000";
				else
					if (t_uni = 9) then
						t_uni <= "0000";
						if (t_dec = 9) then
							t_dec <= "0000"; 
							t_cen <= t_cen + 1;
						else
							t_dec <= t_dec + 1;
						end if;
					else
						t_uni <= t_uni + 1;
					end if;
				end if;
			end if;
		end if;
		
	end process;

	out_t_cen <= std_logic_vector(t_cen);
	out_t_dec <= std_logic_vector(t_dec);
	out_t_uni <= std_logic_vector(t_uni);

	
	process(timer, sw_menu, color_activo, datos_total, datos_r, datos_v, datos_a, velocidad_linea, t_uni, t_dec, t_cen)
	
	begin
	
		if (timer > 0) then
			hex3 <= color_activo;
			hex2 <= "1101";
			if (color_activo = "1011") then
				hex1 <= datos_r(7 downto 4); 
				hex0 <= datos_r(3 downto 0);
			elsif (color_activo = "1100") then
				hex1 <= datos_v(7 downto 4); 
				hex0 <= datos_v(3 downto 0);
			elsif (color_activo = "1010") then
				hex1 <= datos_a(7 downto 4); 
				hex0 <= datos_a(3 downto 0);
			else
				hex1 <= "0000"; hex0 <= "0000";
			end if;
			
		else
		
			case sw_menu is
			
				when "000" => 
					hex3 <= "0000"; 
					hex2 <= "0000"; 
					hex1 <= datos_total(7 downto 4); 
					hex0 <= datos_total(3 downto 0);
				when "001" => 
					hex3 <= "1011"; 
					hex2 <= "1101";
					hex1 <= datos_r(7 downto 4); 
					hex0 <= datos_r(3 downto 0);
				when "010" => 
					hex3 <= "1100"; 
					hex2 <= "1101";
					hex1 <= datos_v(7 downto 4); 
					hex0 <= datos_v(3 downto 0);
				when "011" => 
					hex3 <= "1010"; 
					hex2 <= "1101";
					hex1 <= datos_a(7 downto 4); 
					hex0 <= datos_a(3 downto 0);
				when "100" => 
					hex3 <= "1111"; 
					hex2 <= "1111";
					if (velocidad_linea(1 downto 0) = "00") then    
						hex1 <= "0000"; 
						hex0 <= "0101"; 
					elsif (velocidad_linea(1 downto 0) = "01") then 
						hex1 <= "0001"; 
						hex0 <= "0000"; 
					elsif (velocidad_linea(1 downto 0) = "10") then 
						hex1 <= "0010"; 
						hex0 <= "0000"; 
					elsif (velocidad_linea(1 downto 0) = "11") then 
						hex1 <= "0011"; 
						hex0 <= "0000"; 
					else
						hex1 <= "1111"; 
						hex0 <= "1111";
					end if;
				when "101" => 
					hex3 <= "1111"; 
					hex2 <= std_logic_vector(t_cen);
					hex1 <= std_logic_vector(t_dec);
					hex0 <= std_logic_vector(t_uni);
				when "110" => 
					hex3 <= "0000"; 
					hex2 <= "0000"; 
					hex1 <= datos_total(7 downto 4); 
					hex0 <= datos_total(3 downto 0);
				when others =>
					hex3 <= "1111"; 
					hex2 <= "1111"; 
					hex1 <= "1111"; 
					hex0 <= "1111";
					
			end case;
			
		end if;
		
	end process;

	
end arch_gestor;