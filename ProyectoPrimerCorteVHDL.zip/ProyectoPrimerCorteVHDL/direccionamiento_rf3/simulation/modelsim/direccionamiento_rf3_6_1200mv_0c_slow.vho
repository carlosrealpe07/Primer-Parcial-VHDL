-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/15/2026 22:30:21"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	direccionamiento_rf3 IS
    PORT (
	clk : IN std_logic;
	rst : IN std_logic;
	pulso_captura : IN std_logic;
	pieza_valida : IN std_logic;
	tamano : IN std_logic;
	color : IN std_logic_vector(1 DOWNTO 0);
	leds_compuertas : OUT std_logic_vector(3 DOWNTO 0)
	);
END direccionamiento_rf3;

-- Design Ports Information
-- color[0]	=>  Location: PIN_AB5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- color[1]	=>  Location: PIN_U8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_compuertas[0]	=>  Location: PIN_R11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_compuertas[1]	=>  Location: PIN_P4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_compuertas[2]	=>  Location: PIN_M1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_compuertas[3]	=>  Location: PIN_M3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tamano	=>  Location: PIN_P1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pieza_valida	=>  Location: PIN_L6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pulso_captura	=>  Location: PIN_P2,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF direccionamiento_rf3 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_pulso_captura : std_logic;
SIGNAL ww_pieza_valida : std_logic;
SIGNAL ww_tamano : std_logic;
SIGNAL ww_color : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_leds_compuertas : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \color[0]~input_o\ : std_logic;
SIGNAL \color[1]~input_o\ : std_logic;
SIGNAL \leds_compuertas[0]~output_o\ : std_logic;
SIGNAL \leds_compuertas[1]~output_o\ : std_logic;
SIGNAL \leds_compuertas[2]~output_o\ : std_logic;
SIGNAL \leds_compuertas[3]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \tamano~input_o\ : std_logic;
SIGNAL \pieza_valida~input_o\ : std_logic;
SIGNAL \salidas_reg~0_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \pulso_captura~input_o\ : std_logic;
SIGNAL \salidas_reg~1_combout\ : std_logic;
SIGNAL \salidas_reg[3]~3_combout\ : std_logic;
SIGNAL salidas_reg : std_logic_vector(3 DOWNTO 0);

BEGIN

ww_clk <= clk;
ww_rst <= rst;
ww_pulso_captura <= pulso_captura;
ww_pieza_valida <= pieza_valida;
ww_tamano <= tamano;
ww_color <= color;
leds_compuertas <= ww_leds_compuertas;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);

-- Location: IOOBUF_X3_Y0_N2
\leds_compuertas[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => salidas_reg(0),
	devoe => ww_devoe,
	o => \leds_compuertas[0]~output_o\);

-- Location: IOOBUF_X0_Y10_N23
\leds_compuertas[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => salidas_reg(1),
	devoe => ww_devoe,
	o => \leds_compuertas[1]~output_o\);

-- Location: IOOBUF_X0_Y13_N23
\leds_compuertas[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \leds_compuertas[2]~output_o\);

-- Location: IOOBUF_X0_Y12_N9
\leds_compuertas[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => salidas_reg(3),
	devoe => ww_devoe,
	o => \leds_compuertas[3]~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\clk~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G4
\clk~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y11_N22
\tamano~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tamano,
	o => \tamano~input_o\);

-- Location: IOIBUF_X0_Y13_N1
\pieza_valida~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_pieza_valida,
	o => \pieza_valida~input_o\);

-- Location: LCCOMB_X1_Y10_N8
\salidas_reg~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \salidas_reg~0_combout\ = (!\tamano~input_o\ & \pieza_valida~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \tamano~input_o\,
	datad => \pieza_valida~input_o\,
	combout => \salidas_reg~0_combout\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y11_N15
\pulso_captura~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_pulso_captura,
	o => \pulso_captura~input_o\);

-- Location: FF_X1_Y10_N9
\salidas_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \salidas_reg~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \pulso_captura~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => salidas_reg(0));

-- Location: LCCOMB_X1_Y10_N18
\salidas_reg~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \salidas_reg~1_combout\ = (\tamano~input_o\ & \pieza_valida~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \tamano~input_o\,
	datad => \pieza_valida~input_o\,
	combout => \salidas_reg~1_combout\);

-- Location: FF_X1_Y10_N19
\salidas_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \salidas_reg~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \pulso_captura~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => salidas_reg(1));

-- Location: LCCOMB_X1_Y10_N12
\salidas_reg[3]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \salidas_reg[3]~3_combout\ = !\pieza_valida~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \pieza_valida~input_o\,
	combout => \salidas_reg[3]~3_combout\);

-- Location: FF_X1_Y10_N13
\salidas_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \salidas_reg[3]~3_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \pulso_captura~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => salidas_reg(3));

-- Location: IOIBUF_X9_Y0_N22
\color[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_color(0),
	o => \color[0]~input_o\);

-- Location: IOIBUF_X3_Y0_N15
\color[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_color(1),
	o => \color[1]~input_o\);

ww_leds_compuertas(0) <= \leds_compuertas[0]~output_o\;

ww_leds_compuertas(1) <= \leds_compuertas[1]~output_o\;

ww_leds_compuertas(2) <= \leds_compuertas[2]~output_o\;

ww_leds_compuertas(3) <= \leds_compuertas[3]~output_o\;
END structure;


