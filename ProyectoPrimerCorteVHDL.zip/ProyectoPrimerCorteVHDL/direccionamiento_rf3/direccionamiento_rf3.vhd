library ieee;
use ieee.std_logic_1164.all;



entity direccionamiento_rf3 is

	port
	
	(
		clk             : in std_logic;
		rst             : in std_logic;
		pulso_captura   : in std_logic;
		pieza_valida    : in std_logic;
		tamano          : in std_logic;
		color           : in std_logic_vector(1 downto 0);
		leds_compuertas : out std_logic_vector(7 downto 0) 
	);
	
end direccionamiento_rf3;



architecture arch_dir of direccionamiento_rf3 is

	signal leds_temp : std_logic_vector(7 downto 0) := (others => '0');
	
begin

	process(clk, rst)
	
	begin
	
		if (rst = '0') then
			leds_temp <= (others => '0');
		elsif (clk'event and clk = '1') then
			if (pulso_captura = '1') then
				leds_temp <= (others => '0'); 
				if (pieza_valida = '1') then
					if (tamano = '1') then leds_temp(1) <= '1'; -- grande
					else leds_temp(0) <= '1'; -- pequeña
					end if;
					
					-- contenedor
					if (color = "01") then leds_temp(5) <= '1'; -- rojo
					elsif (color = "10") then leds_temp(6) <= '1'; -- verde
					elsif (color = "11") then leds_temp(7) <= '1'; -- azul
					end if;
				else
					leds_temp(3) <= '1'; -- rechazo
				end if;
				
			end if;
			
		end if;
		
	end process;
	
	leds_compuertas <= leds_temp;
	
end arch_dir;