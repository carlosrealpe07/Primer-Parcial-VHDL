-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/15/2026 22:12:11"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	clasificador_rf2 IS
    PORT (
	clk : IN std_logic;
	rst : IN std_logic;
	presencia_real : IN std_logic;
	sw_tamano : IN std_logic;
	sw_color : IN std_logic_vector(1 DOWNTO 0);
	pulso_captura : OUT std_logic;
	tamano_out : OUT std_logic;
	color_out : OUT std_logic_vector(1 DOWNTO 0);
	pieza_valida : OUT std_logic
	);
END clasificador_rf2;

-- Design Ports Information
-- pulso_captura	=>  Location: PIN_V4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tamano_out	=>  Location: PIN_W1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- color_out[0]	=>  Location: PIN_N7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- color_out[1]	=>  Location: PIN_M8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pieza_valida	=>  Location: PIN_Y1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- presencia_real	=>  Location: PIN_Y2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_tamano	=>  Location: PIN_AA2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_color[0]	=>  Location: PIN_T3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_color[1]	=>  Location: PIN_N8,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF clasificador_rf2 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_presencia_real : std_logic;
SIGNAL ww_sw_tamano : std_logic;
SIGNAL ww_sw_color : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_pulso_captura : std_logic;
SIGNAL ww_tamano_out : std_logic;
SIGNAL ww_color_out : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_pieza_valida : std_logic;
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \pulso_captura~output_o\ : std_logic;
SIGNAL \tamano_out~output_o\ : std_logic;
SIGNAL \color_out[0]~output_o\ : std_logic;
SIGNAL \color_out[1]~output_o\ : std_logic;
SIGNAL \pieza_valida~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \presencia_real~input_o\ : std_logic;
SIGNAL \paso1~feeder_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \paso1~q\ : std_logic;
SIGNAL \paso2~q\ : std_logic;
SIGNAL \presencia_digital~0_combout\ : std_logic;
SIGNAL \sw_tamano~input_o\ : std_logic;
SIGNAL \tamano_out~reg0feeder_combout\ : std_logic;
SIGNAL \tamano_out~reg0_q\ : std_logic;
SIGNAL \sw_color[0]~input_o\ : std_logic;
SIGNAL \color_out[0]~reg0feeder_combout\ : std_logic;
SIGNAL \color_out[0]~reg0_q\ : std_logic;
SIGNAL \sw_color[1]~input_o\ : std_logic;
SIGNAL \color_out[1]~reg0feeder_combout\ : std_logic;
SIGNAL \color_out[1]~reg0_q\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \pieza_valida~reg0_q\ : std_logic;

BEGIN

ww_clk <= clk;
ww_rst <= rst;
ww_presencia_real <= presencia_real;
ww_sw_tamano <= sw_tamano;
ww_sw_color <= sw_color;
pulso_captura <= ww_pulso_captura;
tamano_out <= ww_tamano_out;
color_out <= ww_color_out;
pieza_valida <= ww_pieza_valida;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);

-- Location: IOOBUF_X0_Y5_N23
\pulso_captura~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \presencia_digital~0_combout\,
	devoe => ww_devoe,
	o => \pulso_captura~output_o\);

-- Location: IOOBUF_X0_Y7_N23
\tamano_out~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tamano_out~reg0_q\,
	devoe => ww_devoe,
	o => \tamano_out~output_o\);

-- Location: IOOBUF_X0_Y6_N23
\color_out[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \color_out[0]~reg0_q\,
	devoe => ww_devoe,
	o => \color_out[0]~output_o\);

-- Location: IOOBUF_X0_Y7_N2
\color_out[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \color_out[1]~reg0_q\,
	devoe => ww_devoe,
	o => \color_out[1]~output_o\);

-- Location: IOOBUF_X0_Y6_N9
\pieza_valida~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pieza_valida~reg0_q\,
	devoe => ww_devoe,
	o => \pieza_valida~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\clk~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G4
\clk~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y6_N1
\presencia_real~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_presencia_real,
	o => \presencia_real~input_o\);

-- Location: LCCOMB_X1_Y6_N12
\paso1~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \paso1~feeder_combout\ = \presencia_real~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \presencia_real~input_o\,
	combout => \paso1~feeder_combout\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: FF_X1_Y6_N13
paso1 : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \paso1~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \paso1~q\);

-- Location: FF_X1_Y6_N31
paso2 : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \paso1~q\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \paso2~q\);

-- Location: LCCOMB_X1_Y6_N30
\presencia_digital~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \presencia_digital~0_combout\ = (!\paso2~q\ & \paso1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \paso2~q\,
	datad => \paso1~q\,
	combout => \presencia_digital~0_combout\);

-- Location: IOIBUF_X0_Y5_N8
\sw_tamano~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_tamano,
	o => \sw_tamano~input_o\);

-- Location: LCCOMB_X1_Y6_N20
\tamano_out~reg0feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \tamano_out~reg0feeder_combout\ = \sw_tamano~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \sw_tamano~input_o\,
	combout => \tamano_out~reg0feeder_combout\);

-- Location: FF_X1_Y6_N21
\tamano_out~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \tamano_out~reg0feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \presencia_digital~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \tamano_out~reg0_q\);

-- Location: IOIBUF_X0_Y6_N15
\sw_color[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_color(0),
	o => \sw_color[0]~input_o\);

-- Location: LCCOMB_X1_Y6_N14
\color_out[0]~reg0feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \color_out[0]~reg0feeder_combout\ = \sw_color[0]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \sw_color[0]~input_o\,
	combout => \color_out[0]~reg0feeder_combout\);

-- Location: FF_X1_Y6_N15
\color_out[0]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \color_out[0]~reg0feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \presencia_digital~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \color_out[0]~reg0_q\);

-- Location: IOIBUF_X0_Y7_N8
\sw_color[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sw_color(1),
	o => \sw_color[1]~input_o\);

-- Location: LCCOMB_X1_Y6_N8
\color_out[1]~reg0feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \color_out[1]~reg0feeder_combout\ = \sw_color[1]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \sw_color[1]~input_o\,
	combout => \color_out[1]~reg0feeder_combout\);

-- Location: FF_X1_Y6_N9
\color_out[1]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \color_out[1]~reg0feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \presencia_digital~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \color_out[1]~reg0_q\);

-- Location: LCCOMB_X1_Y6_N26
\Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (\sw_color[0]~input_o\) # (\sw_color[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sw_color[0]~input_o\,
	datad => \sw_color[1]~input_o\,
	combout => \Equal0~0_combout\);

-- Location: FF_X1_Y6_N27
\pieza_valida~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Equal0~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \presencia_digital~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pieza_valida~reg0_q\);

ww_pulso_captura <= \pulso_captura~output_o\;

ww_tamano_out <= \tamano_out~output_o\;

ww_color_out(0) <= \color_out[0]~output_o\;

ww_color_out(1) <= \color_out[1]~output_o\;

ww_pieza_valida <= \pieza_valida~output_o\;
END structure;


