library ieee;
use ieee.std_logic_1164.all;



entity clasificador_rf2 is

	port
	(
		clk               : in std_logic;
		rst               : in std_logic;
		presencia_real    : in std_logic;                      
		sw_tamano         : in std_logic;                      -- 0: pequeña, 1: grande
		sw_color          : in std_logic_vector(1 downto 0);   -- 00: NI, 01: rojo, 10: verde, 11: azul
		pulso_captura     : out std_logic;                     
		tamano_out        : out std_logic;
		color_out         : out std_logic_vector(1 downto 0);
		pieza_valida      : out std_logic                      -- 1 para r/v/a, 0 para NI/rechazo
	);
	
end clasificador_rf2;



architecture arch_clasificador of clasificador_rf2 is


	signal paso1, paso2       : std_logic := '0';
	signal presencia_digital  : std_logic := '0';

	
begin

	process(clk, rst)
	
	begin
		if (rst = '0') then
			paso1 <= '0';
			paso2 <= '0';
		elsif (clk'event and clk = '1') then
			paso1 <= presencia_real;
			paso2 <= paso1;
		end if;
		
	end process;


	presencia_digital <= paso1 and (not paso2);
	pulso_captura     <= presencia_digital;


	process(clk, rst)
	
	begin
		if (rst = '0') then
			tamano_out   <= '0';
			color_out    <= "00";
			pieza_valida <= '0';
		elsif (clk'event and clk = '1') then
			if (presencia_digital = '1') then
				tamano_out <= sw_tamano;
				color_out  <= sw_color;

				if (sw_color = "00") then
					pieza_valida <= '0'; -- no identificado / descarte
				else
					pieza_valida <= '1'; -- categoria valida
				end if;
			end if;
		end if;
		
	end process;

end arch_clasificador;