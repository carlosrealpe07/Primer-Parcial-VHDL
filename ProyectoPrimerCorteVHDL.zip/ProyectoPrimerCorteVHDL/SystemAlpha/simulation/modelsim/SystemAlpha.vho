-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/14/2026 11:52:17"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	SystemAlpha IS
    PORT (
	clk_int : IN std_logic;
	rst : IN std_logic;
	btn_r : IN std_logic;
	btn_v : IN std_logic;
	btn_a : IN std_logic;
	disp_r : OUT std_logic_vector(6 DOWNTO 0);
	disp_v : OUT std_logic_vector(6 DOWNTO 0);
	disp_a : OUT std_logic_vector(6 DOWNTO 0);
	disp_f : OUT std_logic_vector(6 DOWNTO 0)
	);
END SystemAlpha;

-- Design Ports Information
-- disp_r[0]	=>  Location: PIN_F13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_r[1]	=>  Location: PIN_F12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_r[2]	=>  Location: PIN_G12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_r[3]	=>  Location: PIN_H13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_r[4]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_r[5]	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_r[6]	=>  Location: PIN_E11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[0]	=>  Location: PIN_A15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[1]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[2]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[3]	=>  Location: PIN_A14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[4]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[5]	=>  Location: PIN_B13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_v[6]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[0]	=>  Location: PIN_F14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[1]	=>  Location: PIN_B17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[2]	=>  Location: PIN_A17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[3]	=>  Location: PIN_E15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[4]	=>  Location: PIN_B16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[5]	=>  Location: PIN_A16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_a[6]	=>  Location: PIN_D15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[0]	=>  Location: PIN_G15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[1]	=>  Location: PIN_D19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[2]	=>  Location: PIN_C19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[3]	=>  Location: PIN_B19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[4]	=>  Location: PIN_A19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[5]	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- disp_f[6]	=>  Location: PIN_B18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_int	=>  Location: PIN_G21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_J6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_r	=>  Location: PIN_H2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_v	=>  Location: PIN_G3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- btn_a	=>  Location: PIN_F1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF SystemAlpha IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_int : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_btn_r : std_logic;
SIGNAL ww_btn_v : std_logic;
SIGNAL ww_btn_a : std_logic;
SIGNAL ww_disp_r : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_disp_v : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_disp_a : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_disp_f : std_logic_vector(6 DOWNTO 0);
SIGNAL \div_frecuencia|estado~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk_int~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \disp_r[0]~output_o\ : std_logic;
SIGNAL \disp_r[1]~output_o\ : std_logic;
SIGNAL \disp_r[2]~output_o\ : std_logic;
SIGNAL \disp_r[3]~output_o\ : std_logic;
SIGNAL \disp_r[4]~output_o\ : std_logic;
SIGNAL \disp_r[5]~output_o\ : std_logic;
SIGNAL \disp_r[6]~output_o\ : std_logic;
SIGNAL \disp_v[0]~output_o\ : std_logic;
SIGNAL \disp_v[1]~output_o\ : std_logic;
SIGNAL \disp_v[2]~output_o\ : std_logic;
SIGNAL \disp_v[3]~output_o\ : std_logic;
SIGNAL \disp_v[4]~output_o\ : std_logic;
SIGNAL \disp_v[5]~output_o\ : std_logic;
SIGNAL \disp_v[6]~output_o\ : std_logic;
SIGNAL \disp_a[0]~output_o\ : std_logic;
SIGNAL \disp_a[1]~output_o\ : std_logic;
SIGNAL \disp_a[2]~output_o\ : std_logic;
SIGNAL \disp_a[3]~output_o\ : std_logic;
SIGNAL \disp_a[4]~output_o\ : std_logic;
SIGNAL \disp_a[5]~output_o\ : std_logic;
SIGNAL \disp_a[6]~output_o\ : std_logic;
SIGNAL \disp_f[0]~output_o\ : std_logic;
SIGNAL \disp_f[1]~output_o\ : std_logic;
SIGNAL \disp_f[2]~output_o\ : std_logic;
SIGNAL \disp_f[3]~output_o\ : std_logic;
SIGNAL \disp_f[4]~output_o\ : std_logic;
SIGNAL \disp_f[5]~output_o\ : std_logic;
SIGNAL \disp_f[6]~output_o\ : std_logic;
SIGNAL \clk_int~input_o\ : std_logic;
SIGNAL \clk_int~inputclkctrl_outclk\ : std_logic;
SIGNAL \cnt_rojo|cnt[0]~3_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \btn_r~input_o\ : std_logic;
SIGNAL \ff_rojo|d_sync1~0_combout\ : std_logic;
SIGNAL \ff_rojo|d_sync1~q\ : std_logic;
SIGNAL \ff_rojo|d_sync2~q\ : std_logic;
SIGNAL \ff_rojo|q~combout\ : std_logic;
SIGNAL \cnt_rojo|cnt[2]~1_combout\ : std_logic;
SIGNAL \cnt_rojo|cnt~2_combout\ : std_logic;
SIGNAL \cnt_rojo|cnt~0_combout\ : std_logic;
SIGNAL \reg_rojo|q[1]~feeder_combout\ : std_logic;
SIGNAL \reg_rojo|q[0]~feeder_combout\ : std_logic;
SIGNAL \reg_rojo|q[2]~feeder_combout\ : std_logic;
SIGNAL \deco_rojo|Mux6~0_combout\ : std_logic;
SIGNAL \deco_rojo|Mux5~0_combout\ : std_logic;
SIGNAL \deco_rojo|Mux4~0_combout\ : std_logic;
SIGNAL \deco_rojo|Mux3~0_combout\ : std_logic;
SIGNAL \deco_rojo|Mux2~0_combout\ : std_logic;
SIGNAL \deco_rojo|Mux1~0_combout\ : std_logic;
SIGNAL \deco_rojo|Mux0~0_combout\ : std_logic;
SIGNAL \cnt_verde|cnt[0]~3_combout\ : std_logic;
SIGNAL \btn_v~input_o\ : std_logic;
SIGNAL \ff_verde|d_sync1~0_combout\ : std_logic;
SIGNAL \ff_verde|d_sync1~q\ : std_logic;
SIGNAL \ff_verde|d_sync2~q\ : std_logic;
SIGNAL \ff_verde|q~combout\ : std_logic;
SIGNAL \cnt_verde|cnt[2]~1_combout\ : std_logic;
SIGNAL \cnt_verde|cnt~2_combout\ : std_logic;
SIGNAL \cnt_verde|cnt~0_combout\ : std_logic;
SIGNAL \reg_verde|q[1]~feeder_combout\ : std_logic;
SIGNAL \reg_verde|q[2]~feeder_combout\ : std_logic;
SIGNAL \reg_verde|q[0]~feeder_combout\ : std_logic;
SIGNAL \deco_verde|Mux6~0_combout\ : std_logic;
SIGNAL \deco_verde|Mux5~0_combout\ : std_logic;
SIGNAL \deco_verde|Mux4~0_combout\ : std_logic;
SIGNAL \deco_verde|Mux3~0_combout\ : std_logic;
SIGNAL \deco_verde|Mux2~0_combout\ : std_logic;
SIGNAL \deco_verde|Mux1~0_combout\ : std_logic;
SIGNAL \deco_verde|Mux0~0_combout\ : std_logic;
SIGNAL \cnt_azul|cnt[0]~3_combout\ : std_logic;
SIGNAL \btn_a~input_o\ : std_logic;
SIGNAL \ff_azul|d_sync1~0_combout\ : std_logic;
SIGNAL \ff_azul|d_sync1~q\ : std_logic;
SIGNAL \ff_azul|d_sync2~q\ : std_logic;
SIGNAL \ff_azul|q~combout\ : std_logic;
SIGNAL \cnt_azul|cnt~2_combout\ : std_logic;
SIGNAL \cnt_azul|cnt~0_combout\ : std_logic;
SIGNAL \cnt_azul|cnt[2]~1_combout\ : std_logic;
SIGNAL \reg_azul|q[2]~feeder_combout\ : std_logic;
SIGNAL \reg_azul|q[1]~feeder_combout\ : std_logic;
SIGNAL \reg_azul|q[0]~feeder_combout\ : std_logic;
SIGNAL \deco_azul|Mux6~0_combout\ : std_logic;
SIGNAL \deco_azul|Mux5~0_combout\ : std_logic;
SIGNAL \deco_azul|Mux4~0_combout\ : std_logic;
SIGNAL \deco_azul|Mux3~0_combout\ : std_logic;
SIGNAL \deco_azul|Mux2~0_combout\ : std_logic;
SIGNAL \deco_azul|Mux1~0_combout\ : std_logic;
SIGNAL \deco_azul|Mux0~0_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~0_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~2_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~1\ : std_logic;
SIGNAL \div_frecuencia|Add0~2_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~3\ : std_logic;
SIGNAL \div_frecuencia|Add0~4_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~5\ : std_logic;
SIGNAL \div_frecuencia|Add0~6_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~7\ : std_logic;
SIGNAL \div_frecuencia|Add0~8_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~9\ : std_logic;
SIGNAL \div_frecuencia|Add0~10_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~11\ : std_logic;
SIGNAL \div_frecuencia|Add0~12_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~1_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~13\ : std_logic;
SIGNAL \div_frecuencia|Add0~14_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~15\ : std_logic;
SIGNAL \div_frecuencia|Add0~16_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~17\ : std_logic;
SIGNAL \div_frecuencia|Add0~18_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~19\ : std_logic;
SIGNAL \div_frecuencia|Add0~20_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~21\ : std_logic;
SIGNAL \div_frecuencia|Add0~22_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~0_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~23\ : std_logic;
SIGNAL \div_frecuencia|Add0~24_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~3_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~25\ : std_logic;
SIGNAL \div_frecuencia|Add0~26_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~4_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~27\ : std_logic;
SIGNAL \div_frecuencia|Add0~28_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~5_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~29\ : std_logic;
SIGNAL \div_frecuencia|Add0~30_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~31\ : std_logic;
SIGNAL \div_frecuencia|Add0~32_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~6_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~33\ : std_logic;
SIGNAL \div_frecuencia|Add0~34_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~35\ : std_logic;
SIGNAL \div_frecuencia|Add0~36_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~7_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~37\ : std_logic;
SIGNAL \div_frecuencia|Add0~38_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~8_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~5_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~39\ : std_logic;
SIGNAL \div_frecuencia|Add0~40_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~10_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~41\ : std_logic;
SIGNAL \div_frecuencia|Add0~42_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~11_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~43\ : std_logic;
SIGNAL \div_frecuencia|Add0~44_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~12_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~45\ : std_logic;
SIGNAL \div_frecuencia|Add0~46_combout\ : std_logic;
SIGNAL \div_frecuencia|Add0~47\ : std_logic;
SIGNAL \div_frecuencia|Add0~48_combout\ : std_logic;
SIGNAL \div_frecuencia|conteo~9_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~6_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~3_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~1_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~0_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~2_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~4_combout\ : std_logic;
SIGNAL \div_frecuencia|Equal0~7_combout\ : std_logic;
SIGNAL \div_frecuencia|estado~0_combout\ : std_logic;
SIGNAL \div_frecuencia|estado~feeder_combout\ : std_logic;
SIGNAL \div_frecuencia|estado~q\ : std_logic;
SIGNAL \div_frecuencia|estado~clkctrl_outclk\ : std_logic;
SIGNAL \cnt_frecuencia|cnt[0]~3_combout\ : std_logic;
SIGNAL \cnt_frecuencia|cnt[2]~1_combout\ : std_logic;
SIGNAL \cnt_frecuencia|cnt~2_combout\ : std_logic;
SIGNAL \cnt_frecuencia|cnt~0_combout\ : std_logic;
SIGNAL \reg_frecuencia|q[1]~feeder_combout\ : std_logic;
SIGNAL \reg_frecuencia|q[2]~feeder_combout\ : std_logic;
SIGNAL \reg_frecuencia|q[3]~feeder_combout\ : std_logic;
SIGNAL \reg_frecuencia|q[0]~feeder_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux6~0_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux5~0_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux4~0_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux3~0_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux2~0_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux1~0_combout\ : std_logic;
SIGNAL \deco_frecuencia|Mux0~0_combout\ : std_logic;
SIGNAL \cnt_rojo|cnt\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \div_frecuencia|conteo\ : std_logic_vector(24 DOWNTO 0);
SIGNAL \reg_azul|q\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \reg_verde|q\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \cnt_azul|cnt\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \reg_rojo|q\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \reg_frecuencia|q\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \cnt_frecuencia|cnt\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \cnt_verde|cnt\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \deco_frecuencia|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \deco_azul|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \deco_verde|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \deco_rojo|ALT_INV_Mux6~0_combout\ : std_logic;

BEGIN

ww_clk_int <= clk_int;
ww_rst <= rst;
ww_btn_r <= btn_r;
ww_btn_v <= btn_v;
ww_btn_a <= btn_a;
disp_r <= ww_disp_r;
disp_v <= ww_disp_v;
disp_a <= ww_disp_a;
disp_f <= ww_disp_f;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\div_frecuencia|estado~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \div_frecuencia|estado~q\);

\clk_int~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk_int~input_o\);
\deco_frecuencia|ALT_INV_Mux6~0_combout\ <= NOT \deco_frecuencia|Mux6~0_combout\;
\deco_azul|ALT_INV_Mux6~0_combout\ <= NOT \deco_azul|Mux6~0_combout\;
\deco_verde|ALT_INV_Mux6~0_combout\ <= NOT \deco_verde|Mux6~0_combout\;
\deco_rojo|ALT_INV_Mux6~0_combout\ <= NOT \deco_rojo|Mux6~0_combout\;

-- Location: IOOBUF_X26_Y29_N16
\disp_r[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[0]~output_o\);

-- Location: IOOBUF_X28_Y29_N23
\disp_r[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[1]~output_o\);

-- Location: IOOBUF_X26_Y29_N9
\disp_r[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[2]~output_o\);

-- Location: IOOBUF_X28_Y29_N30
\disp_r[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[3]~output_o\);

-- Location: IOOBUF_X26_Y29_N2
\disp_r[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[4]~output_o\);

-- Location: IOOBUF_X21_Y29_N30
\disp_r[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[5]~output_o\);

-- Location: IOOBUF_X21_Y29_N23
\disp_r[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_rojo|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \disp_r[6]~output_o\);

-- Location: IOOBUF_X26_Y29_N23
\disp_v[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[0]~output_o\);

-- Location: IOOBUF_X28_Y29_N16
\disp_v[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[1]~output_o\);

-- Location: IOOBUF_X23_Y29_N30
\disp_v[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[2]~output_o\);

-- Location: IOOBUF_X23_Y29_N23
\disp_v[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[3]~output_o\);

-- Location: IOOBUF_X23_Y29_N2
\disp_v[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[4]~output_o\);

-- Location: IOOBUF_X21_Y29_N9
\disp_v[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[5]~output_o\);

-- Location: IOOBUF_X21_Y29_N2
\disp_v[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_verde|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \disp_v[6]~output_o\);

-- Location: IOOBUF_X37_Y29_N2
\disp_a[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[0]~output_o\);

-- Location: IOOBUF_X30_Y29_N23
\disp_a[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[1]~output_o\);

-- Location: IOOBUF_X30_Y29_N16
\disp_a[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[2]~output_o\);

-- Location: IOOBUF_X30_Y29_N2
\disp_a[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[3]~output_o\);

-- Location: IOOBUF_X28_Y29_N2
\disp_a[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[4]~output_o\);

-- Location: IOOBUF_X30_Y29_N30
\disp_a[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[5]~output_o\);

-- Location: IOOBUF_X32_Y29_N30
\disp_a[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_azul|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \disp_a[6]~output_o\);

-- Location: IOOBUF_X39_Y29_N30
\disp_f[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[0]~output_o\);

-- Location: IOOBUF_X37_Y29_N30
\disp_f[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[1]~output_o\);

-- Location: IOOBUF_X37_Y29_N23
\disp_f[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[2]~output_o\);

-- Location: IOOBUF_X32_Y29_N2
\disp_f[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[3]~output_o\);

-- Location: IOOBUF_X32_Y29_N9
\disp_f[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[4]~output_o\);

-- Location: IOOBUF_X39_Y29_N16
\disp_f[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[5]~output_o\);

-- Location: IOOBUF_X32_Y29_N23
\disp_f[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \deco_frecuencia|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \disp_f[6]~output_o\);

-- Location: IOIBUF_X41_Y15_N1
\clk_int~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_int,
	o => \clk_int~input_o\);

-- Location: CLKCTRL_G9
\clk_int~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk_int~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk_int~inputclkctrl_outclk\);

-- Location: LCCOMB_X27_Y28_N22
\cnt_rojo|cnt[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_rojo|cnt[0]~3_combout\ = !\cnt_rojo|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_rojo|cnt\(0),
	combout => \cnt_rojo|cnt[0]~3_combout\);

-- Location: IOIBUF_X0_Y24_N1
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: IOIBUF_X0_Y21_N8
\btn_r~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_r,
	o => \btn_r~input_o\);

-- Location: LCCOMB_X27_Y28_N16
\ff_rojo|d_sync1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \ff_rojo|d_sync1~0_combout\ = !\btn_r~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \btn_r~input_o\,
	combout => \ff_rojo|d_sync1~0_combout\);

-- Location: FF_X27_Y28_N17
\ff_rojo|d_sync1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \ff_rojo|d_sync1~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ff_rojo|d_sync1~q\);

-- Location: FF_X27_Y28_N19
\ff_rojo|d_sync2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \ff_rojo|d_sync1~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ff_rojo|d_sync2~q\);

-- Location: LCCOMB_X27_Y28_N18
\ff_rojo|q\ : cycloneiii_lcell_comb
-- Equation(s):
-- \ff_rojo|q~combout\ = (!\ff_rojo|d_sync2~q\ & \ff_rojo|d_sync1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \ff_rojo|d_sync2~q\,
	datad => \ff_rojo|d_sync1~q\,
	combout => \ff_rojo|q~combout\);

-- Location: FF_X27_Y28_N23
\cnt_rojo|cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_rojo|cnt[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \ff_rojo|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_rojo|cnt\(0));

-- Location: LCCOMB_X27_Y28_N28
\cnt_rojo|cnt[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_rojo|cnt[2]~1_combout\ = \cnt_rojo|cnt\(2) $ (((\cnt_rojo|cnt\(0) & (\cnt_rojo|cnt\(1) & \ff_rojo|q~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_rojo|cnt\(0),
	datab => \cnt_rojo|cnt\(1),
	datac => \cnt_rojo|cnt\(2),
	datad => \ff_rojo|q~combout\,
	combout => \cnt_rojo|cnt[2]~1_combout\);

-- Location: FF_X27_Y28_N29
\cnt_rojo|cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_rojo|cnt[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_rojo|cnt\(2));

-- Location: LCCOMB_X27_Y28_N4
\cnt_rojo|cnt~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_rojo|cnt~2_combout\ = (\cnt_rojo|cnt\(0) & ((\cnt_rojo|cnt\(1) & (\cnt_rojo|cnt\(3) $ (\cnt_rojo|cnt\(2)))) # (!\cnt_rojo|cnt\(1) & (\cnt_rojo|cnt\(3) & \cnt_rojo|cnt\(2))))) # (!\cnt_rojo|cnt\(0) & (((\cnt_rojo|cnt\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_rojo|cnt\(0),
	datab => \cnt_rojo|cnt\(1),
	datac => \cnt_rojo|cnt\(3),
	datad => \cnt_rojo|cnt\(2),
	combout => \cnt_rojo|cnt~2_combout\);

-- Location: FF_X27_Y28_N5
\cnt_rojo|cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_rojo|cnt~2_combout\,
	clrn => \rst~input_o\,
	ena => \ff_rojo|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_rojo|cnt\(3));

-- Location: LCCOMB_X27_Y28_N20
\cnt_rojo|cnt~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_rojo|cnt~0_combout\ = (\cnt_rojo|cnt\(0) & (!\cnt_rojo|cnt\(1) & ((\cnt_rojo|cnt\(2)) # (!\cnt_rojo|cnt\(3))))) # (!\cnt_rojo|cnt\(0) & (((\cnt_rojo|cnt\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_rojo|cnt\(0),
	datab => \cnt_rojo|cnt\(3),
	datac => \cnt_rojo|cnt\(1),
	datad => \cnt_rojo|cnt\(2),
	combout => \cnt_rojo|cnt~0_combout\);

-- Location: FF_X27_Y28_N21
\cnt_rojo|cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_rojo|cnt~0_combout\,
	clrn => \rst~input_o\,
	ena => \ff_rojo|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_rojo|cnt\(1));

-- Location: LCCOMB_X27_Y28_N26
\reg_rojo|q[1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_rojo|q[1]~feeder_combout\ = \cnt_rojo|cnt\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_rojo|cnt\(1),
	combout => \reg_rojo|q[1]~feeder_combout\);

-- Location: FF_X27_Y28_N27
\reg_rojo|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_rojo|q[1]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_rojo|q\(1));

-- Location: FF_X27_Y28_N25
\reg_rojo|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \cnt_rojo|cnt\(3),
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_rojo|q\(3));

-- Location: LCCOMB_X27_Y28_N2
\reg_rojo|q[0]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_rojo|q[0]~feeder_combout\ = \cnt_rojo|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_rojo|cnt\(0),
	combout => \reg_rojo|q[0]~feeder_combout\);

-- Location: FF_X27_Y28_N3
\reg_rojo|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_rojo|q[0]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_rojo|q\(0));

-- Location: LCCOMB_X27_Y28_N30
\reg_rojo|q[2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_rojo|q[2]~feeder_combout\ = \cnt_rojo|cnt\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_rojo|cnt\(2),
	combout => \reg_rojo|q[2]~feeder_combout\);

-- Location: FF_X27_Y28_N31
\reg_rojo|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_rojo|q[2]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_rojo|q\(2));

-- Location: LCCOMB_X27_Y28_N12
\deco_rojo|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux6~0_combout\ = (\reg_rojo|q\(0) & ((\reg_rojo|q\(3)) # (\reg_rojo|q\(1) $ (\reg_rojo|q\(2))))) # (!\reg_rojo|q\(0) & ((\reg_rojo|q\(1)) # (\reg_rojo|q\(3) $ (\reg_rojo|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(3),
	datac => \reg_rojo|q\(0),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux6~0_combout\);

-- Location: LCCOMB_X27_Y28_N14
\deco_rojo|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux5~0_combout\ = (\reg_rojo|q\(1) & (!\reg_rojo|q\(3) & ((\reg_rojo|q\(0)) # (!\reg_rojo|q\(2))))) # (!\reg_rojo|q\(1) & (\reg_rojo|q\(0) & (\reg_rojo|q\(3) $ (!\reg_rojo|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(3),
	datac => \reg_rojo|q\(0),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux5~0_combout\);

-- Location: LCCOMB_X27_Y28_N10
\deco_rojo|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux4~0_combout\ = (\reg_rojo|q\(1) & (!\reg_rojo|q\(3) & (\reg_rojo|q\(0)))) # (!\reg_rojo|q\(1) & ((\reg_rojo|q\(2) & (!\reg_rojo|q\(3))) # (!\reg_rojo|q\(2) & ((\reg_rojo|q\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000101110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(3),
	datac => \reg_rojo|q\(0),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux4~0_combout\);

-- Location: LCCOMB_X27_Y28_N6
\deco_rojo|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux3~0_combout\ = (\reg_rojo|q\(1) & ((\reg_rojo|q\(0) & ((\reg_rojo|q\(2)))) # (!\reg_rojo|q\(0) & (\reg_rojo|q\(3) & !\reg_rojo|q\(2))))) # (!\reg_rojo|q\(1) & (!\reg_rojo|q\(3) & (\reg_rojo|q\(0) $ (\reg_rojo|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(3),
	datac => \reg_rojo|q\(0),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux3~0_combout\);

-- Location: LCCOMB_X27_Y28_N0
\deco_rojo|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux2~0_combout\ = (\reg_rojo|q\(3) & (\reg_rojo|q\(2) & ((\reg_rojo|q\(1)) # (!\reg_rojo|q\(0))))) # (!\reg_rojo|q\(3) & (\reg_rojo|q\(1) & (!\reg_rojo|q\(0) & !\reg_rojo|q\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(3),
	datac => \reg_rojo|q\(0),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux2~0_combout\);

-- Location: LCCOMB_X27_Y28_N8
\deco_rojo|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux1~0_combout\ = (\reg_rojo|q\(1) & ((\reg_rojo|q\(0) & (\reg_rojo|q\(3))) # (!\reg_rojo|q\(0) & ((\reg_rojo|q\(2)))))) # (!\reg_rojo|q\(1) & (\reg_rojo|q\(2) & (\reg_rojo|q\(3) $ (\reg_rojo|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001111010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(3),
	datac => \reg_rojo|q\(0),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux1~0_combout\);

-- Location: LCCOMB_X27_Y28_N24
\deco_rojo|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_rojo|Mux0~0_combout\ = (\reg_rojo|q\(3) & (\reg_rojo|q\(0) & (\reg_rojo|q\(1) $ (\reg_rojo|q\(2))))) # (!\reg_rojo|q\(3) & (!\reg_rojo|q\(1) & (\reg_rojo|q\(0) $ (\reg_rojo|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000110000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_rojo|q\(1),
	datab => \reg_rojo|q\(0),
	datac => \reg_rojo|q\(3),
	datad => \reg_rojo|q\(2),
	combout => \deco_rojo|Mux0~0_combout\);

-- Location: LCCOMB_X22_Y28_N20
\cnt_verde|cnt[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_verde|cnt[0]~3_combout\ = !\cnt_verde|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_verde|cnt\(0),
	combout => \cnt_verde|cnt[0]~3_combout\);

-- Location: IOIBUF_X0_Y23_N15
\btn_v~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_v,
	o => \btn_v~input_o\);

-- Location: LCCOMB_X22_Y28_N16
\ff_verde|d_sync1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \ff_verde|d_sync1~0_combout\ = !\btn_v~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \btn_v~input_o\,
	combout => \ff_verde|d_sync1~0_combout\);

-- Location: FF_X22_Y28_N17
\ff_verde|d_sync1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \ff_verde|d_sync1~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ff_verde|d_sync1~q\);

-- Location: FF_X22_Y28_N23
\ff_verde|d_sync2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \ff_verde|d_sync1~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ff_verde|d_sync2~q\);

-- Location: LCCOMB_X22_Y28_N22
\ff_verde|q\ : cycloneiii_lcell_comb
-- Equation(s):
-- \ff_verde|q~combout\ = (!\ff_verde|d_sync2~q\ & \ff_verde|d_sync1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \ff_verde|d_sync2~q\,
	datad => \ff_verde|d_sync1~q\,
	combout => \ff_verde|q~combout\);

-- Location: FF_X22_Y28_N21
\cnt_verde|cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_verde|cnt[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \ff_verde|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_verde|cnt\(0));

-- Location: LCCOMB_X22_Y28_N18
\cnt_verde|cnt[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_verde|cnt[2]~1_combout\ = \cnt_verde|cnt\(2) $ (((\cnt_verde|cnt\(1) & (\cnt_verde|cnt\(0) & \ff_verde|q~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_verde|cnt\(1),
	datab => \cnt_verde|cnt\(0),
	datac => \cnt_verde|cnt\(2),
	datad => \ff_verde|q~combout\,
	combout => \cnt_verde|cnt[2]~1_combout\);

-- Location: FF_X22_Y28_N19
\cnt_verde|cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_verde|cnt[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_verde|cnt\(2));

-- Location: LCCOMB_X22_Y28_N14
\cnt_verde|cnt~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_verde|cnt~2_combout\ = (\cnt_verde|cnt\(1) & (\cnt_verde|cnt\(3) $ (((\cnt_verde|cnt\(0) & \cnt_verde|cnt\(2)))))) # (!\cnt_verde|cnt\(1) & (\cnt_verde|cnt\(3) & ((\cnt_verde|cnt\(2)) # (!\cnt_verde|cnt\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_verde|cnt\(1),
	datab => \cnt_verde|cnt\(0),
	datac => \cnt_verde|cnt\(3),
	datad => \cnt_verde|cnt\(2),
	combout => \cnt_verde|cnt~2_combout\);

-- Location: FF_X22_Y28_N15
\cnt_verde|cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_verde|cnt~2_combout\,
	clrn => \rst~input_o\,
	ena => \ff_verde|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_verde|cnt\(3));

-- Location: LCCOMB_X22_Y28_N6
\cnt_verde|cnt~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_verde|cnt~0_combout\ = (\cnt_verde|cnt\(0) & (!\cnt_verde|cnt\(1) & ((\cnt_verde|cnt\(2)) # (!\cnt_verde|cnt\(3))))) # (!\cnt_verde|cnt\(0) & (((\cnt_verde|cnt\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_verde|cnt\(3),
	datab => \cnt_verde|cnt\(0),
	datac => \cnt_verde|cnt\(1),
	datad => \cnt_verde|cnt\(2),
	combout => \cnt_verde|cnt~0_combout\);

-- Location: FF_X22_Y28_N7
\cnt_verde|cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_verde|cnt~0_combout\,
	clrn => \rst~input_o\,
	ena => \ff_verde|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_verde|cnt\(1));

-- Location: LCCOMB_X22_Y28_N12
\reg_verde|q[1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_verde|q[1]~feeder_combout\ = \cnt_verde|cnt\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_verde|cnt\(1),
	combout => \reg_verde|q[1]~feeder_combout\);

-- Location: FF_X22_Y28_N13
\reg_verde|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_verde|q[1]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_verde|q\(1));

-- Location: FF_X22_Y28_N1
\reg_verde|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \cnt_verde|cnt\(3),
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_verde|q\(3));

-- Location: LCCOMB_X22_Y28_N28
\reg_verde|q[2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_verde|q[2]~feeder_combout\ = \cnt_verde|cnt\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_verde|cnt\(2),
	combout => \reg_verde|q[2]~feeder_combout\);

-- Location: FF_X22_Y28_N29
\reg_verde|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_verde|q[2]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_verde|q\(2));

-- Location: LCCOMB_X22_Y28_N24
\reg_verde|q[0]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_verde|q[0]~feeder_combout\ = \cnt_verde|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_verde|cnt\(0),
	combout => \reg_verde|q[0]~feeder_combout\);

-- Location: FF_X22_Y28_N25
\reg_verde|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_verde|q[0]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_verde|q\(0));

-- Location: LCCOMB_X22_Y28_N4
\deco_verde|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux6~0_combout\ = (\reg_verde|q\(0) & ((\reg_verde|q\(3)) # (\reg_verde|q\(1) $ (\reg_verde|q\(2))))) # (!\reg_verde|q\(0) & ((\reg_verde|q\(1)) # (\reg_verde|q\(3) $ (\reg_verde|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111010111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(3),
	datac => \reg_verde|q\(2),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux6~0_combout\);

-- Location: LCCOMB_X22_Y28_N30
\deco_verde|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux5~0_combout\ = (\reg_verde|q\(1) & (!\reg_verde|q\(3) & ((\reg_verde|q\(0)) # (!\reg_verde|q\(2))))) # (!\reg_verde|q\(1) & (\reg_verde|q\(0) & (\reg_verde|q\(3) $ (!\reg_verde|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(3),
	datac => \reg_verde|q\(2),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux5~0_combout\);

-- Location: LCCOMB_X22_Y28_N2
\deco_verde|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux4~0_combout\ = (\reg_verde|q\(1) & (!\reg_verde|q\(3) & ((\reg_verde|q\(0))))) # (!\reg_verde|q\(1) & ((\reg_verde|q\(2) & (!\reg_verde|q\(3))) # (!\reg_verde|q\(2) & ((\reg_verde|q\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011011100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(3),
	datac => \reg_verde|q\(2),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux4~0_combout\);

-- Location: LCCOMB_X22_Y28_N26
\deco_verde|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux3~0_combout\ = (\reg_verde|q\(1) & ((\reg_verde|q\(2) & ((\reg_verde|q\(0)))) # (!\reg_verde|q\(2) & (\reg_verde|q\(3) & !\reg_verde|q\(0))))) # (!\reg_verde|q\(1) & (!\reg_verde|q\(3) & (\reg_verde|q\(2) $ (\reg_verde|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(3),
	datac => \reg_verde|q\(2),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux3~0_combout\);

-- Location: LCCOMB_X22_Y28_N10
\deco_verde|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux2~0_combout\ = (\reg_verde|q\(3) & (\reg_verde|q\(2) & ((\reg_verde|q\(1)) # (!\reg_verde|q\(0))))) # (!\reg_verde|q\(3) & (\reg_verde|q\(1) & (!\reg_verde|q\(2) & !\reg_verde|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(3),
	datac => \reg_verde|q\(2),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux2~0_combout\);

-- Location: LCCOMB_X22_Y28_N8
\deco_verde|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux1~0_combout\ = (\reg_verde|q\(1) & ((\reg_verde|q\(0) & (\reg_verde|q\(3))) # (!\reg_verde|q\(0) & ((\reg_verde|q\(2)))))) # (!\reg_verde|q\(1) & (\reg_verde|q\(2) & (\reg_verde|q\(3) $ (\reg_verde|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(3),
	datac => \reg_verde|q\(2),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux1~0_combout\);

-- Location: LCCOMB_X22_Y28_N0
\deco_verde|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_verde|Mux0~0_combout\ = (\reg_verde|q\(2) & (!\reg_verde|q\(1) & (\reg_verde|q\(3) $ (!\reg_verde|q\(0))))) # (!\reg_verde|q\(2) & (\reg_verde|q\(0) & (\reg_verde|q\(1) $ (!\reg_verde|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_verde|q\(1),
	datab => \reg_verde|q\(2),
	datac => \reg_verde|q\(3),
	datad => \reg_verde|q\(0),
	combout => \deco_verde|Mux0~0_combout\);

-- Location: LCCOMB_X29_Y28_N20
\cnt_azul|cnt[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_azul|cnt[0]~3_combout\ = !\cnt_azul|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_azul|cnt\(0),
	combout => \cnt_azul|cnt[0]~3_combout\);

-- Location: IOIBUF_X0_Y23_N1
\btn_a~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_btn_a,
	o => \btn_a~input_o\);

-- Location: LCCOMB_X29_Y28_N2
\ff_azul|d_sync1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \ff_azul|d_sync1~0_combout\ = !\btn_a~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \btn_a~input_o\,
	combout => \ff_azul|d_sync1~0_combout\);

-- Location: FF_X29_Y28_N3
\ff_azul|d_sync1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \ff_azul|d_sync1~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ff_azul|d_sync1~q\);

-- Location: FF_X29_Y28_N11
\ff_azul|d_sync2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \ff_azul|d_sync1~q\,
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ff_azul|d_sync2~q\);

-- Location: LCCOMB_X29_Y28_N10
\ff_azul|q\ : cycloneiii_lcell_comb
-- Equation(s):
-- \ff_azul|q~combout\ = (!\ff_azul|d_sync2~q\ & \ff_azul|d_sync1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \ff_azul|d_sync2~q\,
	datad => \ff_azul|d_sync1~q\,
	combout => \ff_azul|q~combout\);

-- Location: FF_X29_Y28_N21
\cnt_azul|cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_azul|cnt[0]~3_combout\,
	clrn => \rst~input_o\,
	ena => \ff_azul|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_azul|cnt\(0));

-- Location: LCCOMB_X29_Y28_N26
\cnt_azul|cnt~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_azul|cnt~2_combout\ = (\cnt_azul|cnt\(1) & (\cnt_azul|cnt\(3) $ (((\cnt_azul|cnt\(0) & \cnt_azul|cnt\(2)))))) # (!\cnt_azul|cnt\(1) & (\cnt_azul|cnt\(3) & ((\cnt_azul|cnt\(2)) # (!\cnt_azul|cnt\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_azul|cnt\(1),
	datab => \cnt_azul|cnt\(0),
	datac => \cnt_azul|cnt\(3),
	datad => \cnt_azul|cnt\(2),
	combout => \cnt_azul|cnt~2_combout\);

-- Location: FF_X29_Y28_N27
\cnt_azul|cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_azul|cnt~2_combout\,
	clrn => \rst~input_o\,
	ena => \ff_azul|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_azul|cnt\(3));

-- Location: LCCOMB_X29_Y28_N12
\cnt_azul|cnt~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_azul|cnt~0_combout\ = (\cnt_azul|cnt\(0) & (!\cnt_azul|cnt\(1) & ((\cnt_azul|cnt\(2)) # (!\cnt_azul|cnt\(3))))) # (!\cnt_azul|cnt\(0) & (((\cnt_azul|cnt\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_azul|cnt\(3),
	datab => \cnt_azul|cnt\(0),
	datac => \cnt_azul|cnt\(1),
	datad => \cnt_azul|cnt\(2),
	combout => \cnt_azul|cnt~0_combout\);

-- Location: FF_X29_Y28_N13
\cnt_azul|cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_azul|cnt~0_combout\,
	clrn => \rst~input_o\,
	ena => \ff_azul|q~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_azul|cnt\(1));

-- Location: LCCOMB_X29_Y28_N28
\cnt_azul|cnt[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_azul|cnt[2]~1_combout\ = \cnt_azul|cnt\(2) $ (((\cnt_azul|cnt\(1) & (\cnt_azul|cnt\(0) & \ff_azul|q~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_azul|cnt\(1),
	datab => \cnt_azul|cnt\(0),
	datac => \cnt_azul|cnt\(2),
	datad => \ff_azul|q~combout\,
	combout => \cnt_azul|cnt[2]~1_combout\);

-- Location: FF_X29_Y28_N29
\cnt_azul|cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \cnt_azul|cnt[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_azul|cnt\(2));

-- Location: LCCOMB_X29_Y28_N22
\reg_azul|q[2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_azul|q[2]~feeder_combout\ = \cnt_azul|cnt\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_azul|cnt\(2),
	combout => \reg_azul|q[2]~feeder_combout\);

-- Location: FF_X29_Y28_N23
\reg_azul|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_azul|q[2]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_azul|q\(2));

-- Location: LCCOMB_X29_Y28_N16
\reg_azul|q[1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_azul|q[1]~feeder_combout\ = \cnt_azul|cnt\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_azul|cnt\(1),
	combout => \reg_azul|q[1]~feeder_combout\);

-- Location: FF_X29_Y28_N17
\reg_azul|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_azul|q[1]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_azul|q\(1));

-- Location: FF_X29_Y28_N31
\reg_azul|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \cnt_azul|cnt\(3),
	clrn => \rst~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_azul|q\(3));

-- Location: LCCOMB_X29_Y28_N0
\reg_azul|q[0]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_azul|q[0]~feeder_combout\ = \cnt_azul|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_azul|cnt\(0),
	combout => \reg_azul|q[0]~feeder_combout\);

-- Location: FF_X29_Y28_N1
\reg_azul|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \reg_azul|q[0]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_azul|q\(0));

-- Location: LCCOMB_X29_Y28_N6
\deco_azul|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux6~0_combout\ = (\reg_azul|q\(0) & ((\reg_azul|q\(3)) # (\reg_azul|q\(2) $ (\reg_azul|q\(1))))) # (!\reg_azul|q\(0) & ((\reg_azul|q\(1)) # (\reg_azul|q\(2) $ (\reg_azul|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011011011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux6~0_combout\);

-- Location: LCCOMB_X29_Y28_N8
\deco_azul|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux5~0_combout\ = (\reg_azul|q\(2) & (\reg_azul|q\(0) & (\reg_azul|q\(1) $ (\reg_azul|q\(3))))) # (!\reg_azul|q\(2) & (!\reg_azul|q\(3) & ((\reg_azul|q\(1)) # (\reg_azul|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux5~0_combout\);

-- Location: LCCOMB_X29_Y28_N14
\deco_azul|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux4~0_combout\ = (\reg_azul|q\(1) & (((!\reg_azul|q\(3) & \reg_azul|q\(0))))) # (!\reg_azul|q\(1) & ((\reg_azul|q\(2) & (!\reg_azul|q\(3))) # (!\reg_azul|q\(2) & ((\reg_azul|q\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux4~0_combout\);

-- Location: LCCOMB_X29_Y28_N4
\deco_azul|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux3~0_combout\ = (\reg_azul|q\(1) & ((\reg_azul|q\(2) & ((\reg_azul|q\(0)))) # (!\reg_azul|q\(2) & (\reg_azul|q\(3) & !\reg_azul|q\(0))))) # (!\reg_azul|q\(1) & (!\reg_azul|q\(3) & (\reg_azul|q\(2) $ (\reg_azul|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux3~0_combout\);

-- Location: LCCOMB_X29_Y28_N18
\deco_azul|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux2~0_combout\ = (\reg_azul|q\(2) & (\reg_azul|q\(3) & ((\reg_azul|q\(1)) # (!\reg_azul|q\(0))))) # (!\reg_azul|q\(2) & (\reg_azul|q\(1) & (!\reg_azul|q\(3) & !\reg_azul|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux2~0_combout\);

-- Location: LCCOMB_X29_Y28_N24
\deco_azul|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux1~0_combout\ = (\reg_azul|q\(1) & ((\reg_azul|q\(0) & ((\reg_azul|q\(3)))) # (!\reg_azul|q\(0) & (\reg_azul|q\(2))))) # (!\reg_azul|q\(1) & (\reg_azul|q\(2) & (\reg_azul|q\(3) $ (\reg_azul|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux1~0_combout\);

-- Location: LCCOMB_X29_Y28_N30
\deco_azul|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_azul|Mux0~0_combout\ = (\reg_azul|q\(2) & (!\reg_azul|q\(1) & (\reg_azul|q\(3) $ (!\reg_azul|q\(0))))) # (!\reg_azul|q\(2) & (\reg_azul|q\(0) & (\reg_azul|q\(1) $ (!\reg_azul|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_azul|q\(2),
	datab => \reg_azul|q\(1),
	datac => \reg_azul|q\(3),
	datad => \reg_azul|q\(0),
	combout => \deco_azul|Mux0~0_combout\);

-- Location: LCCOMB_X16_Y26_N8
\div_frecuencia|Add0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~0_combout\ = \div_frecuencia|conteo\(0) $ (VCC)
-- \div_frecuencia|Add0~1\ = CARRY(\div_frecuencia|conteo\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(0),
	datad => VCC,
	combout => \div_frecuencia|Add0~0_combout\,
	cout => \div_frecuencia|Add0~1\);

-- Location: LCCOMB_X17_Y25_N12
\div_frecuencia|conteo~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~2_combout\ = (\div_frecuencia|Add0~0_combout\ & !\div_frecuencia|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|Add0~0_combout\,
	datad => \div_frecuencia|Equal0~7_combout\,
	combout => \div_frecuencia|conteo~2_combout\);

-- Location: FF_X16_Y26_N9
\div_frecuencia|conteo[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	asdata => \div_frecuencia|conteo~2_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(0));

-- Location: LCCOMB_X16_Y26_N10
\div_frecuencia|Add0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~2_combout\ = (\div_frecuencia|conteo\(1) & (!\div_frecuencia|Add0~1\)) # (!\div_frecuencia|conteo\(1) & ((\div_frecuencia|Add0~1\) # (GND)))
-- \div_frecuencia|Add0~3\ = CARRY((!\div_frecuencia|Add0~1\) # (!\div_frecuencia|conteo\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(1),
	datad => VCC,
	cin => \div_frecuencia|Add0~1\,
	combout => \div_frecuencia|Add0~2_combout\,
	cout => \div_frecuencia|Add0~3\);

-- Location: FF_X16_Y26_N11
\div_frecuencia|conteo[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(1));

-- Location: LCCOMB_X16_Y26_N12
\div_frecuencia|Add0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~4_combout\ = (\div_frecuencia|conteo\(2) & (\div_frecuencia|Add0~3\ $ (GND))) # (!\div_frecuencia|conteo\(2) & (!\div_frecuencia|Add0~3\ & VCC))
-- \div_frecuencia|Add0~5\ = CARRY((\div_frecuencia|conteo\(2) & !\div_frecuencia|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(2),
	datad => VCC,
	cin => \div_frecuencia|Add0~3\,
	combout => \div_frecuencia|Add0~4_combout\,
	cout => \div_frecuencia|Add0~5\);

-- Location: FF_X16_Y26_N13
\div_frecuencia|conteo[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(2));

-- Location: LCCOMB_X16_Y26_N14
\div_frecuencia|Add0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~6_combout\ = (\div_frecuencia|conteo\(3) & (!\div_frecuencia|Add0~5\)) # (!\div_frecuencia|conteo\(3) & ((\div_frecuencia|Add0~5\) # (GND)))
-- \div_frecuencia|Add0~7\ = CARRY((!\div_frecuencia|Add0~5\) # (!\div_frecuencia|conteo\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(3),
	datad => VCC,
	cin => \div_frecuencia|Add0~5\,
	combout => \div_frecuencia|Add0~6_combout\,
	cout => \div_frecuencia|Add0~7\);

-- Location: FF_X16_Y26_N15
\div_frecuencia|conteo[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(3));

-- Location: LCCOMB_X16_Y26_N16
\div_frecuencia|Add0~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~8_combout\ = (\div_frecuencia|conteo\(4) & (\div_frecuencia|Add0~7\ $ (GND))) # (!\div_frecuencia|conteo\(4) & (!\div_frecuencia|Add0~7\ & VCC))
-- \div_frecuencia|Add0~9\ = CARRY((\div_frecuencia|conteo\(4) & !\div_frecuencia|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(4),
	datad => VCC,
	cin => \div_frecuencia|Add0~7\,
	combout => \div_frecuencia|Add0~8_combout\,
	cout => \div_frecuencia|Add0~9\);

-- Location: FF_X16_Y26_N17
\div_frecuencia|conteo[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(4));

-- Location: LCCOMB_X16_Y26_N18
\div_frecuencia|Add0~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~10_combout\ = (\div_frecuencia|conteo\(5) & (!\div_frecuencia|Add0~9\)) # (!\div_frecuencia|conteo\(5) & ((\div_frecuencia|Add0~9\) # (GND)))
-- \div_frecuencia|Add0~11\ = CARRY((!\div_frecuencia|Add0~9\) # (!\div_frecuencia|conteo\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(5),
	datad => VCC,
	cin => \div_frecuencia|Add0~9\,
	combout => \div_frecuencia|Add0~10_combout\,
	cout => \div_frecuencia|Add0~11\);

-- Location: FF_X16_Y26_N19
\div_frecuencia|conteo[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(5));

-- Location: LCCOMB_X16_Y26_N20
\div_frecuencia|Add0~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~12_combout\ = (\div_frecuencia|conteo\(6) & (\div_frecuencia|Add0~11\ $ (GND))) # (!\div_frecuencia|conteo\(6) & (!\div_frecuencia|Add0~11\ & VCC))
-- \div_frecuencia|Add0~13\ = CARRY((\div_frecuencia|conteo\(6) & !\div_frecuencia|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(6),
	datad => VCC,
	cin => \div_frecuencia|Add0~11\,
	combout => \div_frecuencia|Add0~12_combout\,
	cout => \div_frecuencia|Add0~13\);

-- Location: LCCOMB_X16_Y26_N4
\div_frecuencia|conteo~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~1_combout\ = (\div_frecuencia|Add0~12_combout\ & !\div_frecuencia|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Add0~12_combout\,
	datad => \div_frecuencia|Equal0~7_combout\,
	combout => \div_frecuencia|conteo~1_combout\);

-- Location: FF_X16_Y26_N5
\div_frecuencia|conteo[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(6));

-- Location: LCCOMB_X16_Y26_N22
\div_frecuencia|Add0~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~14_combout\ = (\div_frecuencia|conteo\(7) & (!\div_frecuencia|Add0~13\)) # (!\div_frecuencia|conteo\(7) & ((\div_frecuencia|Add0~13\) # (GND)))
-- \div_frecuencia|Add0~15\ = CARRY((!\div_frecuencia|Add0~13\) # (!\div_frecuencia|conteo\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(7),
	datad => VCC,
	cin => \div_frecuencia|Add0~13\,
	combout => \div_frecuencia|Add0~14_combout\,
	cout => \div_frecuencia|Add0~15\);

-- Location: FF_X16_Y26_N23
\div_frecuencia|conteo[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(7));

-- Location: LCCOMB_X16_Y26_N24
\div_frecuencia|Add0~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~16_combout\ = (\div_frecuencia|conteo\(8) & (\div_frecuencia|Add0~15\ $ (GND))) # (!\div_frecuencia|conteo\(8) & (!\div_frecuencia|Add0~15\ & VCC))
-- \div_frecuencia|Add0~17\ = CARRY((\div_frecuencia|conteo\(8) & !\div_frecuencia|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(8),
	datad => VCC,
	cin => \div_frecuencia|Add0~15\,
	combout => \div_frecuencia|Add0~16_combout\,
	cout => \div_frecuencia|Add0~17\);

-- Location: FF_X16_Y26_N25
\div_frecuencia|conteo[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(8));

-- Location: LCCOMB_X16_Y26_N26
\div_frecuencia|Add0~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~18_combout\ = (\div_frecuencia|conteo\(9) & (!\div_frecuencia|Add0~17\)) # (!\div_frecuencia|conteo\(9) & ((\div_frecuencia|Add0~17\) # (GND)))
-- \div_frecuencia|Add0~19\ = CARRY((!\div_frecuencia|Add0~17\) # (!\div_frecuencia|conteo\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(9),
	datad => VCC,
	cin => \div_frecuencia|Add0~17\,
	combout => \div_frecuencia|Add0~18_combout\,
	cout => \div_frecuencia|Add0~19\);

-- Location: FF_X16_Y26_N27
\div_frecuencia|conteo[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(9));

-- Location: LCCOMB_X16_Y26_N28
\div_frecuencia|Add0~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~20_combout\ = (\div_frecuencia|conteo\(10) & (\div_frecuencia|Add0~19\ $ (GND))) # (!\div_frecuencia|conteo\(10) & (!\div_frecuencia|Add0~19\ & VCC))
-- \div_frecuencia|Add0~21\ = CARRY((\div_frecuencia|conteo\(10) & !\div_frecuencia|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(10),
	datad => VCC,
	cin => \div_frecuencia|Add0~19\,
	combout => \div_frecuencia|Add0~20_combout\,
	cout => \div_frecuencia|Add0~21\);

-- Location: FF_X16_Y26_N29
\div_frecuencia|conteo[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(10));

-- Location: LCCOMB_X16_Y26_N30
\div_frecuencia|Add0~22\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~22_combout\ = (\div_frecuencia|conteo\(11) & (!\div_frecuencia|Add0~21\)) # (!\div_frecuencia|conteo\(11) & ((\div_frecuencia|Add0~21\) # (GND)))
-- \div_frecuencia|Add0~23\ = CARRY((!\div_frecuencia|Add0~21\) # (!\div_frecuencia|conteo\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(11),
	datad => VCC,
	cin => \div_frecuencia|Add0~21\,
	combout => \div_frecuencia|Add0~22_combout\,
	cout => \div_frecuencia|Add0~23\);

-- Location: LCCOMB_X16_Y26_N0
\div_frecuencia|conteo~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~0_combout\ = (\div_frecuencia|Add0~22_combout\ & !\div_frecuencia|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Add0~22_combout\,
	datad => \div_frecuencia|Equal0~7_combout\,
	combout => \div_frecuencia|conteo~0_combout\);

-- Location: FF_X16_Y26_N1
\div_frecuencia|conteo[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(11));

-- Location: LCCOMB_X16_Y25_N0
\div_frecuencia|Add0~24\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~24_combout\ = (\div_frecuencia|conteo\(12) & (\div_frecuencia|Add0~23\ $ (GND))) # (!\div_frecuencia|conteo\(12) & (!\div_frecuencia|Add0~23\ & VCC))
-- \div_frecuencia|Add0~25\ = CARRY((\div_frecuencia|conteo\(12) & !\div_frecuencia|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(12),
	datad => VCC,
	cin => \div_frecuencia|Add0~23\,
	combout => \div_frecuencia|Add0~24_combout\,
	cout => \div_frecuencia|Add0~25\);

-- Location: LCCOMB_X17_Y25_N2
\div_frecuencia|conteo~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~3_combout\ = (\div_frecuencia|Add0~24_combout\ & !\div_frecuencia|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Add0~24_combout\,
	datad => \div_frecuencia|Equal0~7_combout\,
	combout => \div_frecuencia|conteo~3_combout\);

-- Location: FF_X17_Y25_N3
\div_frecuencia|conteo[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(12));

-- Location: LCCOMB_X16_Y25_N2
\div_frecuencia|Add0~26\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~26_combout\ = (\div_frecuencia|conteo\(13) & (!\div_frecuencia|Add0~25\)) # (!\div_frecuencia|conteo\(13) & ((\div_frecuencia|Add0~25\) # (GND)))
-- \div_frecuencia|Add0~27\ = CARRY((!\div_frecuencia|Add0~25\) # (!\div_frecuencia|conteo\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(13),
	datad => VCC,
	cin => \div_frecuencia|Add0~25\,
	combout => \div_frecuencia|Add0~26_combout\,
	cout => \div_frecuencia|Add0~27\);

-- Location: LCCOMB_X16_Y25_N30
\div_frecuencia|conteo~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~4_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~26_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~26_combout\,
	combout => \div_frecuencia|conteo~4_combout\);

-- Location: FF_X16_Y25_N31
\div_frecuencia|conteo[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(13));

-- Location: LCCOMB_X16_Y25_N4
\div_frecuencia|Add0~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~28_combout\ = (\div_frecuencia|conteo\(14) & (\div_frecuencia|Add0~27\ $ (GND))) # (!\div_frecuencia|conteo\(14) & (!\div_frecuencia|Add0~27\ & VCC))
-- \div_frecuencia|Add0~29\ = CARRY((\div_frecuencia|conteo\(14) & !\div_frecuencia|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(14),
	datad => VCC,
	cin => \div_frecuencia|Add0~27\,
	combout => \div_frecuencia|Add0~28_combout\,
	cout => \div_frecuencia|Add0~29\);

-- Location: LCCOMB_X17_Y25_N20
\div_frecuencia|conteo~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~5_combout\ = (\div_frecuencia|Add0~28_combout\ & !\div_frecuencia|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Add0~28_combout\,
	datad => \div_frecuencia|Equal0~7_combout\,
	combout => \div_frecuencia|conteo~5_combout\);

-- Location: FF_X17_Y25_N21
\div_frecuencia|conteo[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(14));

-- Location: LCCOMB_X16_Y25_N6
\div_frecuencia|Add0~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~30_combout\ = (\div_frecuencia|conteo\(15) & (!\div_frecuencia|Add0~29\)) # (!\div_frecuencia|conteo\(15) & ((\div_frecuencia|Add0~29\) # (GND)))
-- \div_frecuencia|Add0~31\ = CARRY((!\div_frecuencia|Add0~29\) # (!\div_frecuencia|conteo\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(15),
	datad => VCC,
	cin => \div_frecuencia|Add0~29\,
	combout => \div_frecuencia|Add0~30_combout\,
	cout => \div_frecuencia|Add0~31\);

-- Location: FF_X16_Y25_N7
\div_frecuencia|conteo[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~30_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(15));

-- Location: LCCOMB_X16_Y25_N8
\div_frecuencia|Add0~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~32_combout\ = (\div_frecuencia|conteo\(16) & (\div_frecuencia|Add0~31\ $ (GND))) # (!\div_frecuencia|conteo\(16) & (!\div_frecuencia|Add0~31\ & VCC))
-- \div_frecuencia|Add0~33\ = CARRY((\div_frecuencia|conteo\(16) & !\div_frecuencia|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(16),
	datad => VCC,
	cin => \div_frecuencia|Add0~31\,
	combout => \div_frecuencia|Add0~32_combout\,
	cout => \div_frecuencia|Add0~33\);

-- Location: LCCOMB_X17_Y25_N4
\div_frecuencia|conteo~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~6_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~32_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~32_combout\,
	combout => \div_frecuencia|conteo~6_combout\);

-- Location: FF_X17_Y25_N5
\div_frecuencia|conteo[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(16));

-- Location: LCCOMB_X16_Y25_N10
\div_frecuencia|Add0~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~34_combout\ = (\div_frecuencia|conteo\(17) & (!\div_frecuencia|Add0~33\)) # (!\div_frecuencia|conteo\(17) & ((\div_frecuencia|Add0~33\) # (GND)))
-- \div_frecuencia|Add0~35\ = CARRY((!\div_frecuencia|Add0~33\) # (!\div_frecuencia|conteo\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(17),
	datad => VCC,
	cin => \div_frecuencia|Add0~33\,
	combout => \div_frecuencia|Add0~34_combout\,
	cout => \div_frecuencia|Add0~35\);

-- Location: FF_X16_Y25_N11
\div_frecuencia|conteo[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~34_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(17));

-- Location: LCCOMB_X16_Y25_N12
\div_frecuencia|Add0~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~36_combout\ = (\div_frecuencia|conteo\(18) & (\div_frecuencia|Add0~35\ $ (GND))) # (!\div_frecuencia|conteo\(18) & (!\div_frecuencia|Add0~35\ & VCC))
-- \div_frecuencia|Add0~37\ = CARRY((\div_frecuencia|conteo\(18) & !\div_frecuencia|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(18),
	datad => VCC,
	cin => \div_frecuencia|Add0~35\,
	combout => \div_frecuencia|Add0~36_combout\,
	cout => \div_frecuencia|Add0~37\);

-- Location: LCCOMB_X17_Y25_N8
\div_frecuencia|conteo~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~7_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~36_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~36_combout\,
	combout => \div_frecuencia|conteo~7_combout\);

-- Location: FF_X17_Y25_N9
\div_frecuencia|conteo[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(18));

-- Location: LCCOMB_X16_Y25_N14
\div_frecuencia|Add0~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~38_combout\ = (\div_frecuencia|conteo\(19) & (!\div_frecuencia|Add0~37\)) # (!\div_frecuencia|conteo\(19) & ((\div_frecuencia|Add0~37\) # (GND)))
-- \div_frecuencia|Add0~39\ = CARRY((!\div_frecuencia|Add0~37\) # (!\div_frecuencia|conteo\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(19),
	datad => VCC,
	cin => \div_frecuencia|Add0~37\,
	combout => \div_frecuencia|Add0~38_combout\,
	cout => \div_frecuencia|Add0~39\);

-- Location: LCCOMB_X17_Y25_N30
\div_frecuencia|conteo~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~8_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~38_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~38_combout\,
	combout => \div_frecuencia|conteo~8_combout\);

-- Location: FF_X17_Y25_N31
\div_frecuencia|conteo[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(19));

-- Location: LCCOMB_X17_Y25_N22
\div_frecuencia|Equal0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~5_combout\ = (\div_frecuencia|conteo\(19) & (\div_frecuencia|conteo\(16) & (\div_frecuencia|conteo\(18) & !\div_frecuencia|conteo\(17))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(19),
	datab => \div_frecuencia|conteo\(16),
	datac => \div_frecuencia|conteo\(18),
	datad => \div_frecuencia|conteo\(17),
	combout => \div_frecuencia|Equal0~5_combout\);

-- Location: LCCOMB_X16_Y25_N16
\div_frecuencia|Add0~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~40_combout\ = (\div_frecuencia|conteo\(20) & (\div_frecuencia|Add0~39\ $ (GND))) # (!\div_frecuencia|conteo\(20) & (!\div_frecuencia|Add0~39\ & VCC))
-- \div_frecuencia|Add0~41\ = CARRY((\div_frecuencia|conteo\(20) & !\div_frecuencia|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|conteo\(20),
	datad => VCC,
	cin => \div_frecuencia|Add0~39\,
	combout => \div_frecuencia|Add0~40_combout\,
	cout => \div_frecuencia|Add0~41\);

-- Location: LCCOMB_X16_Y25_N28
\div_frecuencia|conteo~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~10_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~40_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~40_combout\,
	combout => \div_frecuencia|conteo~10_combout\);

-- Location: FF_X16_Y25_N29
\div_frecuencia|conteo[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(20));

-- Location: LCCOMB_X16_Y25_N18
\div_frecuencia|Add0~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~42_combout\ = (\div_frecuencia|conteo\(21) & (!\div_frecuencia|Add0~41\)) # (!\div_frecuencia|conteo\(21) & ((\div_frecuencia|Add0~41\) # (GND)))
-- \div_frecuencia|Add0~43\ = CARRY((!\div_frecuencia|Add0~41\) # (!\div_frecuencia|conteo\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(21),
	datad => VCC,
	cin => \div_frecuencia|Add0~41\,
	combout => \div_frecuencia|Add0~42_combout\,
	cout => \div_frecuencia|Add0~43\);

-- Location: LCCOMB_X17_Y25_N6
\div_frecuencia|conteo~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~11_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~42_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~42_combout\,
	combout => \div_frecuencia|conteo~11_combout\);

-- Location: FF_X17_Y25_N7
\div_frecuencia|conteo[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(21));

-- Location: LCCOMB_X16_Y25_N20
\div_frecuencia|Add0~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~44_combout\ = (\div_frecuencia|conteo\(22) & (\div_frecuencia|Add0~43\ $ (GND))) # (!\div_frecuencia|conteo\(22) & (!\div_frecuencia|Add0~43\ & VCC))
-- \div_frecuencia|Add0~45\ = CARRY((\div_frecuencia|conteo\(22) & !\div_frecuencia|Add0~43\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(22),
	datad => VCC,
	cin => \div_frecuencia|Add0~43\,
	combout => \div_frecuencia|Add0~44_combout\,
	cout => \div_frecuencia|Add0~45\);

-- Location: LCCOMB_X16_Y25_N26
\div_frecuencia|conteo~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~12_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~44_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~44_combout\,
	combout => \div_frecuencia|conteo~12_combout\);

-- Location: FF_X16_Y25_N27
\div_frecuencia|conteo[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~12_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(22));

-- Location: LCCOMB_X16_Y25_N22
\div_frecuencia|Add0~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~46_combout\ = (\div_frecuencia|conteo\(23) & (!\div_frecuencia|Add0~45\)) # (!\div_frecuencia|conteo\(23) & ((\div_frecuencia|Add0~45\) # (GND)))
-- \div_frecuencia|Add0~47\ = CARRY((!\div_frecuencia|Add0~45\) # (!\div_frecuencia|conteo\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(23),
	datad => VCC,
	cin => \div_frecuencia|Add0~45\,
	combout => \div_frecuencia|Add0~46_combout\,
	cout => \div_frecuencia|Add0~47\);

-- Location: FF_X16_Y25_N23
\div_frecuencia|conteo[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|Add0~46_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(23));

-- Location: LCCOMB_X16_Y25_N24
\div_frecuencia|Add0~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Add0~48_combout\ = \div_frecuencia|Add0~47\ $ (!\div_frecuencia|conteo\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \div_frecuencia|conteo\(24),
	cin => \div_frecuencia|Add0~47\,
	combout => \div_frecuencia|Add0~48_combout\);

-- Location: LCCOMB_X17_Y25_N28
\div_frecuencia|conteo~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|conteo~9_combout\ = (!\div_frecuencia|Equal0~7_combout\ & \div_frecuencia|Add0~48_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|Equal0~7_combout\,
	datad => \div_frecuencia|Add0~48_combout\,
	combout => \div_frecuencia|conteo~9_combout\);

-- Location: FF_X17_Y25_N29
\div_frecuencia|conteo[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|conteo~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|conteo\(24));

-- Location: LCCOMB_X17_Y25_N14
\div_frecuencia|Equal0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~6_combout\ = (\div_frecuencia|conteo\(21) & (!\div_frecuencia|conteo\(23) & (\div_frecuencia|conteo\(22) & \div_frecuencia|conteo\(20))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(21),
	datab => \div_frecuencia|conteo\(23),
	datac => \div_frecuencia|conteo\(22),
	datad => \div_frecuencia|conteo\(20),
	combout => \div_frecuencia|Equal0~6_combout\);

-- Location: LCCOMB_X17_Y25_N26
\div_frecuencia|Equal0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~3_combout\ = (\div_frecuencia|conteo\(13) & (\div_frecuencia|conteo\(12) & (!\div_frecuencia|conteo\(15) & \div_frecuencia|conteo\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(13),
	datab => \div_frecuencia|conteo\(12),
	datac => \div_frecuencia|conteo\(15),
	datad => \div_frecuencia|conteo\(14),
	combout => \div_frecuencia|Equal0~3_combout\);

-- Location: LCCOMB_X16_Y26_N2
\div_frecuencia|Equal0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~1_combout\ = (!\div_frecuencia|conteo\(7) & (!\div_frecuencia|conteo\(4) & (\div_frecuencia|conteo\(6) & !\div_frecuencia|conteo\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(7),
	datab => \div_frecuencia|conteo\(4),
	datac => \div_frecuencia|conteo\(6),
	datad => \div_frecuencia|conteo\(5),
	combout => \div_frecuencia|Equal0~1_combout\);

-- Location: LCCOMB_X16_Y26_N6
\div_frecuencia|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~0_combout\ = (!\div_frecuencia|conteo\(9) & (!\div_frecuencia|conteo\(10) & (!\div_frecuencia|conteo\(8) & \div_frecuencia|conteo\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(9),
	datab => \div_frecuencia|conteo\(10),
	datac => \div_frecuencia|conteo\(8),
	datad => \div_frecuencia|conteo\(11),
	combout => \div_frecuencia|Equal0~0_combout\);

-- Location: LCCOMB_X17_Y25_N16
\div_frecuencia|Equal0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~2_combout\ = (!\div_frecuencia|conteo\(1) & (!\div_frecuencia|conteo\(3) & (!\div_frecuencia|conteo\(2) & !\div_frecuencia|conteo\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|conteo\(1),
	datab => \div_frecuencia|conteo\(3),
	datac => \div_frecuencia|conteo\(2),
	datad => \div_frecuencia|conteo\(0),
	combout => \div_frecuencia|Equal0~2_combout\);

-- Location: LCCOMB_X17_Y25_N18
\div_frecuencia|Equal0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~4_combout\ = (\div_frecuencia|Equal0~3_combout\ & (\div_frecuencia|Equal0~1_combout\ & (\div_frecuencia|Equal0~0_combout\ & \div_frecuencia|Equal0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|Equal0~3_combout\,
	datab => \div_frecuencia|Equal0~1_combout\,
	datac => \div_frecuencia|Equal0~0_combout\,
	datad => \div_frecuencia|Equal0~2_combout\,
	combout => \div_frecuencia|Equal0~4_combout\);

-- Location: LCCOMB_X17_Y25_N24
\div_frecuencia|Equal0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|Equal0~7_combout\ = (\div_frecuencia|Equal0~5_combout\ & (\div_frecuencia|conteo\(24) & (\div_frecuencia|Equal0~6_combout\ & \div_frecuencia|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|Equal0~5_combout\,
	datab => \div_frecuencia|conteo\(24),
	datac => \div_frecuencia|Equal0~6_combout\,
	datad => \div_frecuencia|Equal0~4_combout\,
	combout => \div_frecuencia|Equal0~7_combout\);

-- Location: LCCOMB_X17_Y25_N0
\div_frecuencia|estado~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|estado~0_combout\ = \div_frecuencia|estado~q\ $ (\div_frecuencia|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \div_frecuencia|estado~q\,
	datad => \div_frecuencia|Equal0~7_combout\,
	combout => \div_frecuencia|estado~0_combout\);

-- Location: LCCOMB_X17_Y25_N10
\div_frecuencia|estado~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \div_frecuencia|estado~feeder_combout\ = \div_frecuencia|estado~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \div_frecuencia|estado~0_combout\,
	combout => \div_frecuencia|estado~feeder_combout\);

-- Location: FF_X17_Y25_N11
\div_frecuencia|estado\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_int~inputclkctrl_outclk\,
	d => \div_frecuencia|estado~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \div_frecuencia|estado~q\);

-- Location: CLKCTRL_G13
\div_frecuencia|estado~clkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \div_frecuencia|estado~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \div_frecuencia|estado~clkctrl_outclk\);

-- Location: LCCOMB_X36_Y28_N6
\cnt_frecuencia|cnt[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_frecuencia|cnt[0]~3_combout\ = !\cnt_frecuencia|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_frecuencia|cnt\(0),
	combout => \cnt_frecuencia|cnt[0]~3_combout\);

-- Location: FF_X36_Y28_N7
\cnt_frecuencia|cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \cnt_frecuencia|cnt[0]~3_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_frecuencia|cnt\(0));

-- Location: LCCOMB_X36_Y28_N2
\cnt_frecuencia|cnt[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_frecuencia|cnt[2]~1_combout\ = \cnt_frecuencia|cnt\(2) $ (((\cnt_frecuencia|cnt\(0) & \cnt_frecuencia|cnt\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_frecuencia|cnt\(0),
	datac => \cnt_frecuencia|cnt\(2),
	datad => \cnt_frecuencia|cnt\(1),
	combout => \cnt_frecuencia|cnt[2]~1_combout\);

-- Location: FF_X36_Y28_N3
\cnt_frecuencia|cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \cnt_frecuencia|cnt[2]~1_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_frecuencia|cnt\(2));

-- Location: LCCOMB_X36_Y28_N24
\cnt_frecuencia|cnt~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_frecuencia|cnt~2_combout\ = (\cnt_frecuencia|cnt\(0) & ((\cnt_frecuencia|cnt\(1) & (\cnt_frecuencia|cnt\(3) $ (\cnt_frecuencia|cnt\(2)))) # (!\cnt_frecuencia|cnt\(1) & (\cnt_frecuencia|cnt\(3) & \cnt_frecuencia|cnt\(2))))) # (!\cnt_frecuencia|cnt\(0) 
-- & (((\cnt_frecuencia|cnt\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_frecuencia|cnt\(0),
	datab => \cnt_frecuencia|cnt\(1),
	datac => \cnt_frecuencia|cnt\(3),
	datad => \cnt_frecuencia|cnt\(2),
	combout => \cnt_frecuencia|cnt~2_combout\);

-- Location: FF_X36_Y28_N25
\cnt_frecuencia|cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \cnt_frecuencia|cnt~2_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_frecuencia|cnt\(3));

-- Location: LCCOMB_X36_Y28_N28
\cnt_frecuencia|cnt~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt_frecuencia|cnt~0_combout\ = (\cnt_frecuencia|cnt\(0) & (!\cnt_frecuencia|cnt\(1) & ((\cnt_frecuencia|cnt\(2)) # (!\cnt_frecuencia|cnt\(3))))) # (!\cnt_frecuencia|cnt\(0) & (((\cnt_frecuencia|cnt\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_frecuencia|cnt\(0),
	datab => \cnt_frecuencia|cnt\(2),
	datac => \cnt_frecuencia|cnt\(1),
	datad => \cnt_frecuencia|cnt\(3),
	combout => \cnt_frecuencia|cnt~0_combout\);

-- Location: FF_X36_Y28_N29
\cnt_frecuencia|cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \cnt_frecuencia|cnt~0_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_frecuencia|cnt\(1));

-- Location: LCCOMB_X36_Y28_N30
\reg_frecuencia|q[1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_frecuencia|q[1]~feeder_combout\ = \cnt_frecuencia|cnt\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_frecuencia|cnt\(1),
	combout => \reg_frecuencia|q[1]~feeder_combout\);

-- Location: FF_X36_Y28_N31
\reg_frecuencia|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \reg_frecuencia|q[1]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_frecuencia|q\(1));

-- Location: LCCOMB_X36_Y28_N8
\reg_frecuencia|q[2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_frecuencia|q[2]~feeder_combout\ = \cnt_frecuencia|cnt\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_frecuencia|cnt\(2),
	combout => \reg_frecuencia|q[2]~feeder_combout\);

-- Location: FF_X36_Y28_N9
\reg_frecuencia|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \reg_frecuencia|q[2]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_frecuencia|q\(2));

-- Location: LCCOMB_X36_Y28_N26
\reg_frecuencia|q[3]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_frecuencia|q[3]~feeder_combout\ = \cnt_frecuencia|cnt\(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_frecuencia|cnt\(3),
	combout => \reg_frecuencia|q[3]~feeder_combout\);

-- Location: FF_X36_Y28_N27
\reg_frecuencia|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \reg_frecuencia|q[3]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_frecuencia|q\(3));

-- Location: LCCOMB_X36_Y28_N20
\reg_frecuencia|q[0]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reg_frecuencia|q[0]~feeder_combout\ = \cnt_frecuencia|cnt\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \cnt_frecuencia|cnt\(0),
	combout => \reg_frecuencia|q[0]~feeder_combout\);

-- Location: FF_X36_Y28_N21
\reg_frecuencia|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \div_frecuencia|estado~clkctrl_outclk\,
	d => \reg_frecuencia|q[0]~feeder_combout\,
	clrn => \rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reg_frecuencia|q\(0));

-- Location: LCCOMB_X36_Y28_N12
\deco_frecuencia|Mux6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux6~0_combout\ = (\reg_frecuencia|q\(0) & ((\reg_frecuencia|q\(3)) # (\reg_frecuencia|q\(1) $ (\reg_frecuencia|q\(2))))) # (!\reg_frecuencia|q\(0) & ((\reg_frecuencia|q\(1)) # (\reg_frecuencia|q\(2) $ (\reg_frecuencia|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011010111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux6~0_combout\);

-- Location: LCCOMB_X36_Y28_N10
\deco_frecuencia|Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux5~0_combout\ = (\reg_frecuencia|q\(1) & (!\reg_frecuencia|q\(3) & ((\reg_frecuencia|q\(0)) # (!\reg_frecuencia|q\(2))))) # (!\reg_frecuencia|q\(1) & (\reg_frecuencia|q\(0) & (\reg_frecuencia|q\(2) $ (!\reg_frecuencia|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100101100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux5~0_combout\);

-- Location: LCCOMB_X36_Y28_N4
\deco_frecuencia|Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux4~0_combout\ = (\reg_frecuencia|q\(1) & (((!\reg_frecuencia|q\(3) & \reg_frecuencia|q\(0))))) # (!\reg_frecuencia|q\(1) & ((\reg_frecuencia|q\(2) & (!\reg_frecuencia|q\(3))) # (!\reg_frecuencia|q\(2) & ((\reg_frecuencia|q\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux4~0_combout\);

-- Location: LCCOMB_X36_Y28_N14
\deco_frecuencia|Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux3~0_combout\ = (\reg_frecuencia|q\(1) & ((\reg_frecuencia|q\(2) & ((\reg_frecuencia|q\(0)))) # (!\reg_frecuencia|q\(2) & (\reg_frecuencia|q\(3) & !\reg_frecuencia|q\(0))))) # (!\reg_frecuencia|q\(1) & (!\reg_frecuencia|q\(3) & 
-- (\reg_frecuencia|q\(2) $ (\reg_frecuencia|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100100100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux3~0_combout\);

-- Location: LCCOMB_X36_Y28_N16
\deco_frecuencia|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux2~0_combout\ = (\reg_frecuencia|q\(2) & (\reg_frecuencia|q\(3) & ((\reg_frecuencia|q\(1)) # (!\reg_frecuencia|q\(0))))) # (!\reg_frecuencia|q\(2) & (\reg_frecuencia|q\(1) & (!\reg_frecuencia|q\(3) & !\reg_frecuencia|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux2~0_combout\);

-- Location: LCCOMB_X36_Y28_N18
\deco_frecuencia|Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux1~0_combout\ = (\reg_frecuencia|q\(1) & ((\reg_frecuencia|q\(0) & ((\reg_frecuencia|q\(3)))) # (!\reg_frecuencia|q\(0) & (\reg_frecuencia|q\(2))))) # (!\reg_frecuencia|q\(1) & (\reg_frecuencia|q\(2) & (\reg_frecuencia|q\(3) $ 
-- (\reg_frecuencia|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux1~0_combout\);

-- Location: LCCOMB_X36_Y28_N0
\deco_frecuencia|Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \deco_frecuencia|Mux0~0_combout\ = (\reg_frecuencia|q\(2) & (!\reg_frecuencia|q\(1) & (\reg_frecuencia|q\(3) $ (!\reg_frecuencia|q\(0))))) # (!\reg_frecuencia|q\(2) & (\reg_frecuencia|q\(0) & (\reg_frecuencia|q\(1) $ (!\reg_frecuencia|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reg_frecuencia|q\(1),
	datab => \reg_frecuencia|q\(2),
	datac => \reg_frecuencia|q\(3),
	datad => \reg_frecuencia|q\(0),
	combout => \deco_frecuencia|Mux0~0_combout\);

ww_disp_r(0) <= \disp_r[0]~output_o\;

ww_disp_r(1) <= \disp_r[1]~output_o\;

ww_disp_r(2) <= \disp_r[2]~output_o\;

ww_disp_r(3) <= \disp_r[3]~output_o\;

ww_disp_r(4) <= \disp_r[4]~output_o\;

ww_disp_r(5) <= \disp_r[5]~output_o\;

ww_disp_r(6) <= \disp_r[6]~output_o\;

ww_disp_v(0) <= \disp_v[0]~output_o\;

ww_disp_v(1) <= \disp_v[1]~output_o\;

ww_disp_v(2) <= \disp_v[2]~output_o\;

ww_disp_v(3) <= \disp_v[3]~output_o\;

ww_disp_v(4) <= \disp_v[4]~output_o\;

ww_disp_v(5) <= \disp_v[5]~output_o\;

ww_disp_v(6) <= \disp_v[6]~output_o\;

ww_disp_a(0) <= \disp_a[0]~output_o\;

ww_disp_a(1) <= \disp_a[1]~output_o\;

ww_disp_a(2) <= \disp_a[2]~output_o\;

ww_disp_a(3) <= \disp_a[3]~output_o\;

ww_disp_a(4) <= \disp_a[4]~output_o\;

ww_disp_a(5) <= \disp_a[5]~output_o\;

ww_disp_a(6) <= \disp_a[6]~output_o\;

ww_disp_f(0) <= \disp_f[0]~output_o\;

ww_disp_f(1) <= \disp_f[1]~output_o\;

ww_disp_f(2) <= \disp_f[2]~output_o\;

ww_disp_f(3) <= \disp_f[3]~output_o\;

ww_disp_f(4) <= \disp_f[4]~output_o\;

ww_disp_f(5) <= \disp_f[5]~output_o\;

ww_disp_f(6) <= \disp_f[6]~output_o\;
END structure;


