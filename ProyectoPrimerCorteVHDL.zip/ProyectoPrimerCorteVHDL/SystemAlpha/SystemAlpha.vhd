library ieee;
use ieee.std_logic_1164.all;



entity SystemAlpha is

	port
	(
		clk_int            : in std_logic; --reloj de 50MHz de la fpga
		rst                : in std_logic;
		btn_r, btn_v, btn_a : in std_logic;
		disp_r             : out std_logic_vector(6 downto 0);
		disp_v             : out std_logic_vector(6 downto 0);
		disp_a             : out std_logic_vector(6 downto 0);
		disp_f             : out std_logic_vector(6 downto 0)  --display de la frecuencia
	);
	
end SystemAlpha;



architecture arch_SystemAlpha of SystemAlpha is



	component D_FF
		port
		(
			Clock, Reset, Preset, D, EN : in std_logic;
			Q, Qn                       : out std_logic
		);
	end component;

	
	
	component Contador
		port
		(
			clk    : in std_logic;
			reset  : in std_logic;
			enable : in std_logic;
			count  : out std_logic_vector(3 downto 0)
		);
	end component;

	
	
	component registro4bits
		port
		(
			clk : in std_logic;
			rst : in std_logic;
			d   : in std_logic_vector(3 downto 0);
			q   : out std_logic_vector(3 downto 0)
		);
	end component;

	
	
	component deco7seg_4bits
		port
		(
			a : in std_logic_vector(3 downto 0);
			d : out std_logic_vector(6 downto 0)
		);
	end component;

	
	
	component divisor
		port
		(
			clk_50mhz : in std_logic;
			clk_1hz   : out std_logic
		);
	end component;

	
	
	-- senales color rojo
	signal q_ff_r   : std_logic;
	signal cnt_r    : std_logic_vector(3 downto 0);
	signal reg_r    : std_logic_vector(3 downto 0);

	
	
	-- senales color verde
	signal q_ff_v   : std_logic;
	signal cnt_v    : std_logic_vector(3 downto 0);
	signal reg_v    : std_logic_vector(3 downto 0);

	
	
	-- senales color azul
	signal q_ff_a   : std_logic;
	signal cnt_a    : std_logic_vector(3 downto 0);
	signal reg_a    : std_logic_vector(3 downto 0);

	
	
	-- senales canal frecuencia 
	signal clk_1hz  : std_logic;
	signal cnt_f    : std_logic_vector(3 downto 0);
	signal reg_f    : std_logic_vector(3 downto 0);

	
begin


	-- color rojo
	ff_rojo : D_FF
	port map
	(
		Clock  => clk_int,
		Reset  => rst,
		Preset => '1',
		D      => btn_r,
		EN     => '1',
		Q      => q_ff_r,
		Qn     => open
	);

	cnt_rojo : Contador
	port map
	(
		clk    => clk_int,
		reset  => rst,
		enable => q_ff_r,
		count  => cnt_r
	);

	reg_rojo : registro4bits
	port map
	(
		clk => clk_int,
		rst => rst,
		d   => cnt_r,
		q   => reg_r
	);

	deco_rojo : deco7seg_4bits
	port map
	(
		a => reg_r,
		d => disp_r
	);

	
	
	-- color verde
	ff_verde : D_FF
	port map
	(
		Clock  => clk_int,
		Reset  => rst,
		Preset => '1',
		D      => btn_v,
		EN     => '1',
		Q      => q_ff_v,
		Qn     => open
	);

	cnt_verde : Contador
	port map
	(
		clk    => clk_int,
		reset  => rst,
		enable => q_ff_v,
		count  => cnt_v
	);

	reg_verde : registro4bits
	port map
	(
		clk => clk_int,
		rst => rst,
		d   => cnt_v,
		q   => reg_v
	);

	deco_verde : deco7seg_4bits
	port map
	(
		a => reg_v,
		d => disp_v
	);

	
	
	-- color azul
	ff_azul : D_FF
	port map
	(
		Clock  => clk_int,
		Reset  => rst,
		Preset => '1',
		D      => btn_a,
		EN     => '1',
		Q      => q_ff_a,
		Qn     => open
	);

	cnt_azul : Contador
	port map
	(
		clk    => clk_int,
		reset  => rst,
		enable => q_ff_a,
		count  => cnt_a
	);

	reg_azul : registro4bits
	port map
	(
		clk => clk_int,
		rst => rst,
		d   => cnt_a,
		q   => reg_a
	);

	deco_azul : deco7seg_4bits
	port map
	(
		a => reg_a,
		d => disp_a
	);

	
	
	-- canal frecuencia 
	div_frecuencia : divisor
	port map
	(
		clk_50mhz => clk_int,
		clk_1hz   => clk_1hz
	);

	cnt_frecuencia : Contador
	port map
	(
		clk    => clk_1hz, -- alimentado por el reloj lento de 1 Hz
		reset  => rst,
		enable => '1',     -- siempre prendido pa que cuente solo
		count  => cnt_f
	);

	reg_frecuencia : registro4bits
	port map
	(
		clk => clk_1hz,    -- sincronizado con el reloj lento
		rst => rst,
		d   => cnt_f,
		q   => reg_f
	);

	deco_frecuencia : deco7seg_4bits
	port map
	(
		a => reg_f,
		d => disp_f
	);

	
	
end arch_SystemAlpha;