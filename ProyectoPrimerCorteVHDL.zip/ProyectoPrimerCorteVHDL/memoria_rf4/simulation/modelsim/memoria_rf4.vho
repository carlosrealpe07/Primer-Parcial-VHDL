-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "09/16/2026 15:48:23"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	memoria_rf4 IS
    PORT (
	clk_rtc : IN std_logic;
	clk_sistema : IN std_logic;
	rst : IN std_logic;
	guardar_dato : IN std_logic;
	color_pieza : IN std_logic_vector(1 DOWNTO 0);
	tamano_pieza : IN std_logic;
	modo_consulta : IN std_logic;
	sel_memoria : IN std_logic_vector(1 DOWNTO 0);
	salida_tiempo : OUT std_logic_vector(3 DOWNTO 0);
	salida_color : OUT std_logic_vector(1 DOWNTO 0);
	salida_tamano : OUT std_logic
	);
END memoria_rf4;

-- Design Ports Information
-- salida_tiempo[0]	=>  Location: PIN_H18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- salida_tiempo[1]	=>  Location: PIN_J21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- salida_tiempo[2]	=>  Location: PIN_H21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- salida_tiempo[3]	=>  Location: PIN_K16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- salida_color[0]	=>  Location: PIN_K17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- salida_color[1]	=>  Location: PIN_H19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- salida_tamano	=>  Location: PIN_H22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel_memoria[1]	=>  Location: PIN_J18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel_memoria[0]	=>  Location: PIN_K18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- modo_consulta	=>  Location: PIN_E21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- color_pieza[0]	=>  Location: PIN_F22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- color_pieza[1]	=>  Location: PIN_F21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tamano_pieza	=>  Location: PIN_H20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_sistema	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_T2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- guardar_dato	=>  Location: PIN_E22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_rtc	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF memoria_rf4 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_rtc : std_logic;
SIGNAL ww_clk_sistema : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_guardar_dato : std_logic;
SIGNAL ww_color_pieza : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_tamano_pieza : std_logic;
SIGNAL ww_modo_consulta : std_logic;
SIGNAL ww_sel_memoria : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_salida_tiempo : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_salida_color : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_salida_tamano : std_logic;
SIGNAL \clk_sistema~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk_rtc~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \salida_tiempo[0]~output_o\ : std_logic;
SIGNAL \salida_tiempo[1]~output_o\ : std_logic;
SIGNAL \salida_tiempo[2]~output_o\ : std_logic;
SIGNAL \salida_tiempo[3]~output_o\ : std_logic;
SIGNAL \salida_color[0]~output_o\ : std_logic;
SIGNAL \salida_color[1]~output_o\ : std_logic;
SIGNAL \salida_tamano~output_o\ : std_logic;
SIGNAL \modo_consulta~input_o\ : std_logic;
SIGNAL \clk_sistema~input_o\ : std_logic;
SIGNAL \clk_sistema~inputclkctrl_outclk\ : std_logic;
SIGNAL \clk_rtc~input_o\ : std_logic;
SIGNAL \clk_rtc~inputclkctrl_outclk\ : std_logic;
SIGNAL \seg_actual[0]~3_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \guardar_dato~input_o\ : std_logic;
SIGNAL \indice_escritura[0]~1_combout\ : std_logic;
SIGNAL \indice_escritura[1]~0_combout\ : std_logic;
SIGNAL \Decoder0~0_combout\ : std_logic;
SIGNAL \registros[2][3]~q\ : std_logic;
SIGNAL \sel_memoria[0]~input_o\ : std_logic;
SIGNAL \Decoder0~1_combout\ : std_logic;
SIGNAL \registros[1][3]~q\ : std_logic;
SIGNAL \Decoder0~2_combout\ : std_logic;
SIGNAL \registros[0][3]~q\ : std_logic;
SIGNAL \sel_memoria[1]~input_o\ : std_logic;
SIGNAL \trama_seleccionada~0_combout\ : std_logic;
SIGNAL \Decoder0~3_combout\ : std_logic;
SIGNAL \registros[3][3]~q\ : std_logic;
SIGNAL \trama_seleccionada~1_combout\ : std_logic;
SIGNAL \trama_seleccionada~2_combout\ : std_logic;
SIGNAL \seg_actual[1]~0_combout\ : std_logic;
SIGNAL \registros[2][4]~feeder_combout\ : std_logic;
SIGNAL \registros[2][4]~q\ : std_logic;
SIGNAL \registros[0][4]~q\ : std_logic;
SIGNAL \trama_seleccionada~3_combout\ : std_logic;
SIGNAL \registros[3][4]~q\ : std_logic;
SIGNAL \registros[1][4]~feeder_combout\ : std_logic;
SIGNAL \registros[1][4]~q\ : std_logic;
SIGNAL \trama_seleccionada~4_combout\ : std_logic;
SIGNAL \trama_seleccionada~5_combout\ : std_logic;
SIGNAL \seg_actual[2]~1_combout\ : std_logic;
SIGNAL \registros[2][5]~feeder_combout\ : std_logic;
SIGNAL \registros[2][5]~q\ : std_logic;
SIGNAL \registros[1][5]~feeder_combout\ : std_logic;
SIGNAL \registros[1][5]~q\ : std_logic;
SIGNAL \registros[0][5]~q\ : std_logic;
SIGNAL \trama_seleccionada~6_combout\ : std_logic;
SIGNAL \registros[3][5]~q\ : std_logic;
SIGNAL \trama_seleccionada~7_combout\ : std_logic;
SIGNAL \trama_seleccionada~8_combout\ : std_logic;
SIGNAL \seg_actual[3]~2_combout\ : std_logic;
SIGNAL \registros[2][6]~feeder_combout\ : std_logic;
SIGNAL \registros[2][6]~q\ : std_logic;
SIGNAL \registros[0][6]~q\ : std_logic;
SIGNAL \trama_seleccionada~9_combout\ : std_logic;
SIGNAL \registros[3][6]~q\ : std_logic;
SIGNAL \registros[1][6]~feeder_combout\ : std_logic;
SIGNAL \registros[1][6]~q\ : std_logic;
SIGNAL \trama_seleccionada~10_combout\ : std_logic;
SIGNAL \trama_seleccionada~11_combout\ : std_logic;
SIGNAL \color_pieza[0]~input_o\ : std_logic;
SIGNAL \registros[2][1]~feeder_combout\ : std_logic;
SIGNAL \registros[2][1]~q\ : std_logic;
SIGNAL \registros[1][1]~feeder_combout\ : std_logic;
SIGNAL \registros[1][1]~q\ : std_logic;
SIGNAL \registros[0][1]~q\ : std_logic;
SIGNAL \trama_seleccionada~12_combout\ : std_logic;
SIGNAL \registros[3][1]~q\ : std_logic;
SIGNAL \trama_seleccionada~13_combout\ : std_logic;
SIGNAL \trama_seleccionada~14_combout\ : std_logic;
SIGNAL \color_pieza[1]~input_o\ : std_logic;
SIGNAL \registros[1][2]~feeder_combout\ : std_logic;
SIGNAL \registros[1][2]~q\ : std_logic;
SIGNAL \registros[2][2]~feeder_combout\ : std_logic;
SIGNAL \registros[2][2]~q\ : std_logic;
SIGNAL \registros[0][2]~q\ : std_logic;
SIGNAL \trama_seleccionada~15_combout\ : std_logic;
SIGNAL \registros[3][2]~q\ : std_logic;
SIGNAL \trama_seleccionada~16_combout\ : std_logic;
SIGNAL \trama_seleccionada~17_combout\ : std_logic;
SIGNAL \tamano_pieza~input_o\ : std_logic;
SIGNAL \registros[1][0]~q\ : std_logic;
SIGNAL \registros[0][0]~q\ : std_logic;
SIGNAL \trama_seleccionada~18_combout\ : std_logic;
SIGNAL \registros[2][0]~q\ : std_logic;
SIGNAL \registros[3][0]~q\ : std_logic;
SIGNAL \trama_seleccionada~19_combout\ : std_logic;
SIGNAL \trama_seleccionada~20_combout\ : std_logic;
SIGNAL seg_actual : std_logic_vector(3 DOWNTO 0);
SIGNAL indice_escritura : std_logic_vector(1 DOWNTO 0);

BEGIN

ww_clk_rtc <= clk_rtc;
ww_clk_sistema <= clk_sistema;
ww_rst <= rst;
ww_guardar_dato <= guardar_dato;
ww_color_pieza <= color_pieza;
ww_tamano_pieza <= tamano_pieza;
ww_modo_consulta <= modo_consulta;
ww_sel_memoria <= sel_memoria;
salida_tiempo <= ww_salida_tiempo;
salida_color <= ww_salida_color;
salida_tamano <= ww_salida_tamano;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk_sistema~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk_sistema~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);

\clk_rtc~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk_rtc~input_o\);

-- Location: IOOBUF_X41_Y23_N2
\salida_tiempo[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~2_combout\,
	devoe => ww_devoe,
	o => \salida_tiempo[0]~output_o\);

-- Location: IOOBUF_X41_Y20_N23
\salida_tiempo[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~5_combout\,
	devoe => ww_devoe,
	o => \salida_tiempo[1]~output_o\);

-- Location: IOOBUF_X41_Y21_N23
\salida_tiempo[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~8_combout\,
	devoe => ww_devoe,
	o => \salida_tiempo[2]~output_o\);

-- Location: IOOBUF_X41_Y20_N9
\salida_tiempo[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~11_combout\,
	devoe => ww_devoe,
	o => \salida_tiempo[3]~output_o\);

-- Location: IOOBUF_X41_Y21_N16
\salida_color[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~14_combout\,
	devoe => ww_devoe,
	o => \salida_color[0]~output_o\);

-- Location: IOOBUF_X41_Y23_N23
\salida_color[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~17_combout\,
	devoe => ww_devoe,
	o => \salida_color[1]~output_o\);

-- Location: IOOBUF_X41_Y20_N2
\salida_tamano~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \trama_seleccionada~20_combout\,
	devoe => ww_devoe,
	o => \salida_tamano~output_o\);

-- Location: IOIBUF_X41_Y23_N8
\modo_consulta~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_modo_consulta,
	o => \modo_consulta~input_o\);

-- Location: IOIBUF_X0_Y14_N1
\clk_sistema~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_sistema,
	o => \clk_sistema~input_o\);

-- Location: CLKCTRL_G4
\clk_sistema~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk_sistema~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk_sistema~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y14_N8
\clk_rtc~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_rtc,
	o => \clk_rtc~input_o\);

-- Location: CLKCTRL_G2
\clk_rtc~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk_rtc~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk_rtc~inputclkctrl_outclk\);

-- Location: LCCOMB_X40_Y22_N6
\seg_actual[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \seg_actual[0]~3_combout\ = !seg_actual(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => seg_actual(0),
	combout => \seg_actual[0]~3_combout\);

-- Location: IOIBUF_X0_Y14_N15
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G3
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: FF_X40_Y22_N7
\seg_actual[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_rtc~inputclkctrl_outclk\,
	d => \seg_actual[0]~3_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => seg_actual(0));

-- Location: IOIBUF_X41_Y23_N15
\guardar_dato~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_guardar_dato,
	o => \guardar_dato~input_o\);

-- Location: LCCOMB_X39_Y22_N0
\indice_escritura[0]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \indice_escritura[0]~1_combout\ = indice_escritura(0) $ (\guardar_dato~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => indice_escritura(0),
	datad => \guardar_dato~input_o\,
	combout => \indice_escritura[0]~1_combout\);

-- Location: FF_X39_Y22_N1
\indice_escritura[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \indice_escritura[0]~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => indice_escritura(0));

-- Location: LCCOMB_X39_Y22_N18
\indice_escritura[1]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \indice_escritura[1]~0_combout\ = indice_escritura(1) $ (((\guardar_dato~input_o\ & indice_escritura(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \guardar_dato~input_o\,
	datac => indice_escritura(1),
	datad => indice_escritura(0),
	combout => \indice_escritura[1]~0_combout\);

-- Location: FF_X39_Y22_N19
\indice_escritura[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \indice_escritura[1]~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => indice_escritura(1));

-- Location: LCCOMB_X39_Y22_N16
\Decoder0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Decoder0~0_combout\ = (\guardar_dato~input_o\ & (!indice_escritura(0) & indice_escritura(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \guardar_dato~input_o\,
	datab => indice_escritura(0),
	datad => indice_escritura(1),
	combout => \Decoder0~0_combout\);

-- Location: FF_X39_Y22_N17
\registros[2][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(0),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][3]~q\);

-- Location: IOIBUF_X41_Y21_N8
\sel_memoria[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel_memoria(0),
	o => \sel_memoria[0]~input_o\);

-- Location: LCCOMB_X40_Y22_N28
\Decoder0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Decoder0~1_combout\ = (indice_escritura(0) & (\guardar_dato~input_o\ & !indice_escritura(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => indice_escritura(0),
	datab => \guardar_dato~input_o\,
	datad => indice_escritura(1),
	combout => \Decoder0~1_combout\);

-- Location: FF_X40_Y22_N29
\registros[1][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(0),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][3]~q\);

-- Location: LCCOMB_X38_Y22_N4
\Decoder0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Decoder0~2_combout\ = (\guardar_dato~input_o\ & (!indice_escritura(0) & !indice_escritura(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \guardar_dato~input_o\,
	datac => indice_escritura(0),
	datad => indice_escritura(1),
	combout => \Decoder0~2_combout\);

-- Location: FF_X38_Y22_N29
\registros[0][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(0),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][3]~q\);

-- Location: IOIBUF_X41_Y21_N1
\sel_memoria[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sel_memoria(1),
	o => \sel_memoria[1]~input_o\);

-- Location: LCCOMB_X38_Y22_N28
\trama_seleccionada~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~0_combout\ = (\sel_memoria[0]~input_o\ & ((\registros[1][3]~q\) # ((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & (((\registros[0][3]~q\ & !\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \registros[1][3]~q\,
	datac => \registros[0][3]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~0_combout\);

-- Location: LCCOMB_X38_Y22_N22
\Decoder0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Decoder0~3_combout\ = (\guardar_dato~input_o\ & (indice_escritura(0) & indice_escritura(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \guardar_dato~input_o\,
	datac => indice_escritura(0),
	datad => indice_escritura(1),
	combout => \Decoder0~3_combout\);

-- Location: FF_X38_Y22_N7
\registros[3][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(0),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][3]~q\);

-- Location: LCCOMB_X38_Y22_N6
\trama_seleccionada~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~1_combout\ = (\trama_seleccionada~0_combout\ & (((\registros[3][3]~q\) # (!\sel_memoria[1]~input_o\)))) # (!\trama_seleccionada~0_combout\ & (\registros[2][3]~q\ & ((\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \registros[2][3]~q\,
	datab => \trama_seleccionada~0_combout\,
	datac => \registros[3][3]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~1_combout\);

-- Location: LCCOMB_X40_Y22_N8
\trama_seleccionada~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~2_combout\ = (\modo_consulta~input_o\ & (\trama_seleccionada~1_combout\)) # (!\modo_consulta~input_o\ & ((seg_actual(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_consulta~input_o\,
	datab => \trama_seleccionada~1_combout\,
	datac => seg_actual(0),
	combout => \trama_seleccionada~2_combout\);

-- Location: LCCOMB_X40_Y22_N24
\seg_actual[1]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \seg_actual[1]~0_combout\ = seg_actual(1) $ (seg_actual(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => seg_actual(1),
	datad => seg_actual(0),
	combout => \seg_actual[1]~0_combout\);

-- Location: FF_X40_Y22_N25
\seg_actual[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_rtc~inputclkctrl_outclk\,
	d => \seg_actual[1]~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => seg_actual(1));

-- Location: LCCOMB_X39_Y22_N22
\registros[2][4]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[2][4]~feeder_combout\ = seg_actual(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => seg_actual(1),
	combout => \registros[2][4]~feeder_combout\);

-- Location: FF_X39_Y22_N23
\registros[2][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[2][4]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][4]~q\);

-- Location: FF_X38_Y22_N9
\registros[0][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(1),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][4]~q\);

-- Location: LCCOMB_X38_Y22_N8
\trama_seleccionada~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~3_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\ & (\registros[2][4]~q\)) # (!\sel_memoria[1]~input_o\ & ((\registros[0][4]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \registros[2][4]~q\,
	datac => \registros[0][4]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~3_combout\);

-- Location: FF_X38_Y22_N11
\registros[3][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(1),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][4]~q\);

-- Location: LCCOMB_X40_Y22_N18
\registros[1][4]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[1][4]~feeder_combout\ = seg_actual(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => seg_actual(1),
	combout => \registros[1][4]~feeder_combout\);

-- Location: FF_X40_Y22_N19
\registros[1][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[1][4]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][4]~q\);

-- Location: LCCOMB_X38_Y22_N10
\trama_seleccionada~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~4_combout\ = (\sel_memoria[0]~input_o\ & ((\trama_seleccionada~3_combout\ & (\registros[3][4]~q\)) # (!\trama_seleccionada~3_combout\ & ((\registros[1][4]~q\))))) # (!\sel_memoria[0]~input_o\ & (\trama_seleccionada~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \trama_seleccionada~3_combout\,
	datac => \registros[3][4]~q\,
	datad => \registros[1][4]~q\,
	combout => \trama_seleccionada~4_combout\);

-- Location: LCCOMB_X39_Y22_N8
\trama_seleccionada~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~5_combout\ = (\modo_consulta~input_o\ & (\trama_seleccionada~4_combout\)) # (!\modo_consulta~input_o\ & ((seg_actual(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \trama_seleccionada~4_combout\,
	datac => \modo_consulta~input_o\,
	datad => seg_actual(1),
	combout => \trama_seleccionada~5_combout\);

-- Location: LCCOMB_X40_Y22_N0
\seg_actual[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \seg_actual[2]~1_combout\ = seg_actual(2) $ (((seg_actual(0) & seg_actual(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => seg_actual(0),
	datac => seg_actual(2),
	datad => seg_actual(1),
	combout => \seg_actual[2]~1_combout\);

-- Location: FF_X40_Y22_N1
\seg_actual[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_rtc~inputclkctrl_outclk\,
	d => \seg_actual[2]~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => seg_actual(2));

-- Location: LCCOMB_X39_Y22_N6
\registros[2][5]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[2][5]~feeder_combout\ = seg_actual(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => seg_actual(2),
	combout => \registros[2][5]~feeder_combout\);

-- Location: FF_X39_Y22_N7
\registros[2][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[2][5]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][5]~q\);

-- Location: LCCOMB_X40_Y22_N14
\registros[1][5]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[1][5]~feeder_combout\ = seg_actual(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => seg_actual(2),
	combout => \registros[1][5]~feeder_combout\);

-- Location: FF_X40_Y22_N15
\registros[1][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[1][5]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][5]~q\);

-- Location: FF_X38_Y22_N25
\registros[0][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(2),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][5]~q\);

-- Location: LCCOMB_X38_Y22_N24
\trama_seleccionada~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~6_combout\ = (\sel_memoria[1]~input_o\ & (((\sel_memoria[0]~input_o\)))) # (!\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\ & (\registros[1][5]~q\)) # (!\sel_memoria[0]~input_o\ & ((\registros[0][5]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \registros[1][5]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \registros[0][5]~q\,
	datad => \sel_memoria[0]~input_o\,
	combout => \trama_seleccionada~6_combout\);

-- Location: FF_X38_Y22_N19
\registros[3][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(2),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][5]~q\);

-- Location: LCCOMB_X38_Y22_N18
\trama_seleccionada~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~7_combout\ = (\trama_seleccionada~6_combout\ & (((\registros[3][5]~q\) # (!\sel_memoria[1]~input_o\)))) # (!\trama_seleccionada~6_combout\ & (\registros[2][5]~q\ & ((\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \registros[2][5]~q\,
	datab => \trama_seleccionada~6_combout\,
	datac => \registros[3][5]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~7_combout\);

-- Location: LCCOMB_X40_Y22_N30
\trama_seleccionada~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~8_combout\ = (\modo_consulta~input_o\ & (\trama_seleccionada~7_combout\)) # (!\modo_consulta~input_o\ & ((seg_actual(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_consulta~input_o\,
	datac => \trama_seleccionada~7_combout\,
	datad => seg_actual(2),
	combout => \trama_seleccionada~8_combout\);

-- Location: LCCOMB_X40_Y22_N2
\seg_actual[3]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \seg_actual[3]~2_combout\ = seg_actual(3) $ (((seg_actual(0) & (seg_actual(2) & seg_actual(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => seg_actual(0),
	datab => seg_actual(2),
	datac => seg_actual(3),
	datad => seg_actual(1),
	combout => \seg_actual[3]~2_combout\);

-- Location: FF_X40_Y22_N3
\seg_actual[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_rtc~inputclkctrl_outclk\,
	d => \seg_actual[3]~2_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => seg_actual(3));

-- Location: LCCOMB_X39_Y22_N20
\registros[2][6]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[2][6]~feeder_combout\ = seg_actual(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => seg_actual(3),
	combout => \registros[2][6]~feeder_combout\);

-- Location: FF_X39_Y22_N21
\registros[2][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[2][6]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][6]~q\);

-- Location: FF_X38_Y22_N17
\registros[0][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(3),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][6]~q\);

-- Location: LCCOMB_X38_Y22_N16
\trama_seleccionada~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~9_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\ & (\registros[2][6]~q\)) # (!\sel_memoria[1]~input_o\ & ((\registros[0][6]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \registros[2][6]~q\,
	datac => \registros[0][6]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~9_combout\);

-- Location: FF_X38_Y22_N15
\registros[3][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => seg_actual(3),
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][6]~q\);

-- Location: LCCOMB_X40_Y22_N20
\registros[1][6]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[1][6]~feeder_combout\ = seg_actual(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => seg_actual(3),
	combout => \registros[1][6]~feeder_combout\);

-- Location: FF_X40_Y22_N21
\registros[1][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[1][6]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][6]~q\);

-- Location: LCCOMB_X38_Y22_N14
\trama_seleccionada~10\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~10_combout\ = (\sel_memoria[0]~input_o\ & ((\trama_seleccionada~9_combout\ & (\registros[3][6]~q\)) # (!\trama_seleccionada~9_combout\ & ((\registros[1][6]~q\))))) # (!\sel_memoria[0]~input_o\ & (\trama_seleccionada~9_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \trama_seleccionada~9_combout\,
	datac => \registros[3][6]~q\,
	datad => \registros[1][6]~q\,
	combout => \trama_seleccionada~10_combout\);

-- Location: LCCOMB_X39_Y22_N14
\trama_seleccionada~11\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~11_combout\ = (\modo_consulta~input_o\ & ((\trama_seleccionada~10_combout\))) # (!\modo_consulta~input_o\ & (seg_actual(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => seg_actual(3),
	datac => \modo_consulta~input_o\,
	datad => \trama_seleccionada~10_combout\,
	combout => \trama_seleccionada~11_combout\);

-- Location: IOIBUF_X41_Y22_N22
\color_pieza[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_color_pieza(0),
	o => \color_pieza[0]~input_o\);

-- Location: LCCOMB_X39_Y22_N4
\registros[2][1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[2][1]~feeder_combout\ = \color_pieza[0]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \color_pieza[0]~input_o\,
	combout => \registros[2][1]~feeder_combout\);

-- Location: FF_X39_Y22_N5
\registros[2][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[2][1]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][1]~q\);

-- Location: LCCOMB_X40_Y22_N12
\registros[1][1]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[1][1]~feeder_combout\ = \color_pieza[0]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \color_pieza[0]~input_o\,
	combout => \registros[1][1]~feeder_combout\);

-- Location: FF_X40_Y22_N13
\registros[1][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[1][1]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][1]~q\);

-- Location: FF_X38_Y22_N21
\registros[0][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \color_pieza[0]~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][1]~q\);

-- Location: LCCOMB_X38_Y22_N20
\trama_seleccionada~12\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~12_combout\ = (\sel_memoria[0]~input_o\ & ((\registros[1][1]~q\) # ((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & (((\registros[0][1]~q\ & !\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \registros[1][1]~q\,
	datac => \registros[0][1]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~12_combout\);

-- Location: FF_X38_Y22_N27
\registros[3][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \color_pieza[0]~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][1]~q\);

-- Location: LCCOMB_X38_Y22_N26
\trama_seleccionada~13\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~13_combout\ = (\trama_seleccionada~12_combout\ & (((\registros[3][1]~q\) # (!\sel_memoria[1]~input_o\)))) # (!\trama_seleccionada~12_combout\ & (\registros[2][1]~q\ & ((\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \registros[2][1]~q\,
	datab => \trama_seleccionada~12_combout\,
	datac => \registros[3][1]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~13_combout\);

-- Location: LCCOMB_X39_Y22_N30
\trama_seleccionada~14\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~14_combout\ = (\modo_consulta~input_o\ & (\trama_seleccionada~13_combout\)) # (!\modo_consulta~input_o\ & ((\color_pieza[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \trama_seleccionada~13_combout\,
	datac => \modo_consulta~input_o\,
	datad => \color_pieza[0]~input_o\,
	combout => \trama_seleccionada~14_combout\);

-- Location: IOIBUF_X41_Y22_N15
\color_pieza[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_color_pieza(1),
	o => \color_pieza[1]~input_o\);

-- Location: LCCOMB_X40_Y22_N10
\registros[1][2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[1][2]~feeder_combout\ = \color_pieza[1]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \color_pieza[1]~input_o\,
	combout => \registros[1][2]~feeder_combout\);

-- Location: FF_X40_Y22_N11
\registros[1][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[1][2]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][2]~q\);

-- Location: LCCOMB_X39_Y22_N28
\registros[2][2]~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registros[2][2]~feeder_combout\ = \color_pieza[1]~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \color_pieza[1]~input_o\,
	combout => \registros[2][2]~feeder_combout\);

-- Location: FF_X39_Y22_N29
\registros[2][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	d => \registros[2][2]~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][2]~q\);

-- Location: FF_X38_Y22_N1
\registros[0][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \color_pieza[1]~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][2]~q\);

-- Location: LCCOMB_X38_Y22_N0
\trama_seleccionada~15\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~15_combout\ = (\sel_memoria[0]~input_o\ & (((\sel_memoria[1]~input_o\)))) # (!\sel_memoria[0]~input_o\ & ((\sel_memoria[1]~input_o\ & (\registros[2][2]~q\)) # (!\sel_memoria[1]~input_o\ & ((\registros[0][2]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sel_memoria[0]~input_o\,
	datab => \registros[2][2]~q\,
	datac => \registros[0][2]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~15_combout\);

-- Location: FF_X38_Y22_N3
\registros[3][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \color_pieza[1]~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][2]~q\);

-- Location: LCCOMB_X38_Y22_N2
\trama_seleccionada~16\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~16_combout\ = (\trama_seleccionada~15_combout\ & (((\registros[3][2]~q\) # (!\sel_memoria[0]~input_o\)))) # (!\trama_seleccionada~15_combout\ & (\registros[1][2]~q\ & ((\sel_memoria[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \registros[1][2]~q\,
	datab => \trama_seleccionada~15_combout\,
	datac => \registros[3][2]~q\,
	datad => \sel_memoria[0]~input_o\,
	combout => \trama_seleccionada~16_combout\);

-- Location: LCCOMB_X39_Y22_N26
\trama_seleccionada~17\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~17_combout\ = (\modo_consulta~input_o\ & (\trama_seleccionada~16_combout\)) # (!\modo_consulta~input_o\ & ((\color_pieza[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \trama_seleccionada~16_combout\,
	datac => \modo_consulta~input_o\,
	datad => \color_pieza[1]~input_o\,
	combout => \trama_seleccionada~17_combout\);

-- Location: IOIBUF_X41_Y22_N1
\tamano_pieza~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tamano_pieza,
	o => \tamano_pieza~input_o\);

-- Location: FF_X40_Y22_N17
\registros[1][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \tamano_pieza~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[1][0]~q\);

-- Location: FF_X38_Y22_N13
\registros[0][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \tamano_pieza~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[0][0]~q\);

-- Location: LCCOMB_X38_Y22_N12
\trama_seleccionada~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~18_combout\ = (\sel_memoria[1]~input_o\ & (((\sel_memoria[0]~input_o\)))) # (!\sel_memoria[1]~input_o\ & ((\sel_memoria[0]~input_o\ & (\registros[1][0]~q\)) # (!\sel_memoria[0]~input_o\ & ((\registros[0][0]~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \registros[1][0]~q\,
	datab => \sel_memoria[1]~input_o\,
	datac => \registros[0][0]~q\,
	datad => \sel_memoria[0]~input_o\,
	combout => \trama_seleccionada~18_combout\);

-- Location: FF_X39_Y22_N25
\registros[2][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \tamano_pieza~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[2][0]~q\);

-- Location: FF_X38_Y22_N31
\registros[3][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sistema~inputclkctrl_outclk\,
	asdata => \tamano_pieza~input_o\,
	clrn => \rst~inputclkctrl_outclk\,
	sload => VCC,
	ena => \Decoder0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \registros[3][0]~q\);

-- Location: LCCOMB_X38_Y22_N30
\trama_seleccionada~19\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~19_combout\ = (\trama_seleccionada~18_combout\ & (((\registros[3][0]~q\) # (!\sel_memoria[1]~input_o\)))) # (!\trama_seleccionada~18_combout\ & (\registros[2][0]~q\ & ((\sel_memoria[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \trama_seleccionada~18_combout\,
	datab => \registros[2][0]~q\,
	datac => \registros[3][0]~q\,
	datad => \sel_memoria[1]~input_o\,
	combout => \trama_seleccionada~19_combout\);

-- Location: LCCOMB_X40_Y22_N26
\trama_seleccionada~20\ : cycloneiii_lcell_comb
-- Equation(s):
-- \trama_seleccionada~20_combout\ = (\modo_consulta~input_o\ & ((\trama_seleccionada~19_combout\))) # (!\modo_consulta~input_o\ & (\tamano_pieza~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \modo_consulta~input_o\,
	datab => \tamano_pieza~input_o\,
	datad => \trama_seleccionada~19_combout\,
	combout => \trama_seleccionada~20_combout\);

ww_salida_tiempo(0) <= \salida_tiempo[0]~output_o\;

ww_salida_tiempo(1) <= \salida_tiempo[1]~output_o\;

ww_salida_tiempo(2) <= \salida_tiempo[2]~output_o\;

ww_salida_tiempo(3) <= \salida_tiempo[3]~output_o\;

ww_salida_color(0) <= \salida_color[0]~output_o\;

ww_salida_color(1) <= \salida_color[1]~output_o\;

ww_salida_tamano <= \salida_tamano~output_o\;
END structure;


