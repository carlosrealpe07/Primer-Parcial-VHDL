library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;



entity memoria_rf4 is

	port
	
	(
		clk_sistema   : in std_logic;
		rst           : in std_logic;
		guardar_dato  : in std_logic;
		color_pieza   : in std_logic_vector(1 downto 0);
		tamano_pieza  : in std_logic; 
		in_t_cen      : in std_logic_vector(3 downto 0);
		in_t_dec      : in std_logic_vector(3 downto 0);
		in_t_uni      : in std_logic_vector(3 downto 0);
		modo_consulta : in std_logic;
		sel_memoria   : in std_logic_vector(1 downto 0);
		
		salida_color  : out std_logic_vector(1 downto 0);
		salida_tamano : out std_logic;
		salida_cen    : out std_logic_vector(3 downto 0);
		salida_dec    : out std_logic_vector(3 downto 0);
		salida_uni    : out std_logic_vector(3 downto 0)
	);
	
end memoria_rf4;



architecture arch_memoria of memoria_rf4 is

	
	subtype trama_pieza is std_logic_vector(14 downto 0);
	type banco_registros is array (0 to 3) of trama_pieza;

	signal registros : banco_registros := (others => (others => '0'));
	signal trama_actual : trama_pieza;
	signal trama_seleccionada : trama_pieza;

begin

	trama_actual <= color_pieza & tamano_pieza & in_t_cen & in_t_dec & in_t_uni;

	
	process(clk_sistema, rst)
	
	begin
	
		if (rst = '0') then
			registros <= (others => (others => '0'));
		elsif (clk_sistema'event and clk_sistema = '1') then
			if (guardar_dato = '1') then
				-- registro de desplazamiento (empuja el historial hacia abajo)
				registros(3) <= registros(2);
				registros(2) <= registros(1);
				registros(1) <= registros(0);
				registros(0) <= trama_actual; 
			end if;
		end if;
		
	end process;

	
	process(modo_consulta, sel_memoria, registros, trama_actual)
	
	begin
	
		if (modo_consulta = '0') then
			trama_seleccionada <= trama_actual;
		else
			trama_seleccionada <= registros(to_integer(unsigned(sel_memoria)));
		end if;
		
	end process;

	
	salida_color  <= trama_seleccionada(14 downto 13);
	salida_tamano <= trama_seleccionada(12);
	salida_cen    <= trama_seleccionada(11 downto 8);
	salida_dec    <= trama_seleccionada(7 downto 4);
	salida_uni    <= trama_seleccionada(3 downto 0);

	
end arch_memoria;